import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Initialize GoogleGenAI server-side with telemetry User-Agent header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Bengali Family AI Assistant Endpoint
// Everyone in the family can ask questions, get advice, recipes, letter drafting, child study tips, etc.
app.post('/api/family-ai', async (req, res) => {
  try {
    const { message, memberName, memberRole, memberAge, topic } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'বার্তা বা প্রশ্ন প্রদান করা আবশ্যক।' });
    }

    const systemInstruction = `You are "দাস পরিবার ডিজিটাল সহায়ক" (DAS FAMILY AI Assistant), a warm, loving, and deeply knowledgeable Bengali family guide and digital companion.
You are built specifically for the members of the Das Family (দাস পরিবার).

Context of current user asking:
- Name: ${memberName || 'পারিবারিক সদস্য (Family Member)'}
- Role in Family: ${memberRole || 'সদস্য'}
- Age: ${memberAge ? `${memberAge} বছর` : 'উদ্বৃত্ত নয়'}
- Topic category: ${topic || 'সাধারণ পারিবারিক সহায়তা'}

Your capabilities:
1. বরিষ্ঠদের যত্ন ও সুস্বাস্থ্য পরামর্শ (Elderly care, light wellness, digestion precautions, daily walks, stretching - always general wellness, NEVER prescribe medicine doses or medical treatments; recommend consulting Dr. Debabrata Sen or family physician).
2. বাঙালির ঐতিহ্যবাহী রান্না ও উৎসবের রেসিপি (Authentic Bengali cuisine, daily menus, puja bhog, festive sweets like Sandesh, Payesh, Patishapta, Shukto, Kosha Mangsho).
3. পারিবারিক চিঠি ও আনুষ্ঠানিক দরখাস্ত (Drafting polite Bengali invitation cards, congratulations, school leave applications, bank correspondence in both elegant Bengali and English).
4. শিশু ও কিশোরদের পড়াশোনা ও অনুপ্রেরণা (Fun educational quiz, science facts, exam routine tips, inspirational Bengali bedtime stories like Upendrakishore or Sukumar Ray).
5. পারিবারিক বাজেট ও গৃহস্থালী পরিচালনা (Smart household budget, savings tips, grocery checklist, festival expense tracking, emergency document security).
6. জরুরি সময় পরামর্শ (First-aid emergency guidance, calming steps during distress, reminding to use the app's SOS Emergency broadcast).

Tone & Persona:
- Speak in warm, respectful, natural Bengali (বাংলা) by default. Use English phrases where helpful for technical or educational terms.
- For elders (grandfather/grandmother), address with deep respect ("শ্রদ্ধেয় দাদু", "নমস্কার", "আপনার কুশল কামনা করি").
- For children (Rohit, Ananya), speak affectionately with gentle encouragement ("স্নেহের", "খুব সুন্দর প্রশ্ন").
- For adults (Milon, Sunita), speak as a trusted family advisor.
- Keep formatting clean with cheerful emojis (✿, 🌿, 📖, 🍲), bullet points, and practical takeaways.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: message,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || 'দুঃখিত, কোনো উত্তর প্রস্তুত করা সম্ভব হয়নি। অনুগ্রহ করে আবার প্রশ্নটি করুন।';
    return res.json({ reply, success: true });
  } catch (error: any) {
    console.error('Family AI Generation error:', error);
    return res.status(500).json({
      error: 'এআই সহায়ক বর্তমানে উপলব্ধ নয়। অনুগ্রহ করে কিছুক্ষণ পর চেষ্টা করুন।',
      details: error?.message || 'Server error',
      success: false,
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', app: 'DAS FAMILY Vault', time: new Date().toISOString() });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DAS FAMILY Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
