/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Heart, 
  FileText, 
  Image as ImageIcon, 
  Cloud, 
  CheckCircle,
  AlertCircle,
  Sparkles,
  Smartphone
} from 'lucide-react';
import { 
  VaultState, 
  FamilyMember, 
  Language, 
  VitalLog, 
  MedicalRecord, 
  DocumentItem, 
  PhotoFolder, 
  PhotoItem,
  EmergencyAlert
} from './types';
import { loadVaultData, saveVaultData } from './utils/storage';
import { getTranslation } from './utils/translations';
import { DriveSyncService } from './services/driveSync';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { MembersView } from './components/MembersView';
import { HealthSafeView } from './components/HealthSafeView';
import { DocumentsView } from './components/DocumentsView';
import { PhotoVaultView } from './components/PhotoVaultView';
import { DriveBackupView } from './components/DriveBackupView';
import { EmergencyBroadcastModal } from './components/EmergencyBroadcastModal';
import { ActiveEmergencyBanner } from './components/ActiveEmergencyBanner';
import { LoginModal } from './components/LoginModal';
import { LoginScreen } from './components/LoginScreen';
import { MyProfileModal } from './components/MyProfileModal';
import { AdminMasterView } from './components/AdminMasterView';
import { FamilyAIAssistant } from './components/FamilyAIAssistant';
import { PlayStoreView } from './components/PlayStoreView';
import { KolkaCorner } from './components/KolkaMotifs';

export default function App() {
  const [state, setState] = useState<VaultState>(loadVaultData);
  const [currentLang, setCurrentLang] = useState<Language>('bn'); // default Bengali/English as requested by user ("APP ER NAM DAU DAS FAMILY")
  
  // STRICT REQUIREMENT: Only registered persons are visible in the app
  const registeredMembers = state.members.filter((m) => m.isRegistered !== false);

  // Authentication Gateway State
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    const savedId = localStorage.getItem('das_family_active_user_id');
    return !!savedId && !!state.members.find(m => m.id === savedId && m.isRegistered !== false);
  });

  const [currentMember, setCurrentMember] = useState<FamilyMember>(() => {
    const savedId = localStorage.getItem('das_family_active_user_id');
    const matched = savedId ? state.members.find(m => m.id === savedId && m.isRegistered !== false) : null;
    return matched || registeredMembers.find(m => m.id === state.familyHeadId) || registeredMembers[0] || state.members[0];
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'members' | 'ai' | 'health' | 'documents' | 'photos' | 'drive' | 'playstore' | 'admin'>('playstore');

  // Modal dialog states
  const [showSOSModal, setShowSOSModal] = useState(false);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [editingTargetMember, setEditingTargetMember] = useState<FamilyMember | null>(null);

  // Toast notifications
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' } | null>(null);

  const t = getTranslation(currentLang);

  const showToast = (text: string, type: 'success' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Sync state changes to storage
  useEffect(() => {
    saveVaultData(state);
  }, [state]);

  // Handlers for Member Management
  const handleSelectMember = (member: FamilyMember) => {
    setCurrentMember(member);
    showToast(`Logged in as ${member.name} (${member.relationship})`);
  };

  const handleAddNewMember = (newMember: FamilyMember) => {
    setState((prev) => ({
      ...prev,
      members: [...prev.members, newMember],
    }));
    showToast(`Added ${newMember.name} to DAS FAMILY`);
  };

  const handleUpdateMember = (updatedMember: FamilyMember) => {
    setState((prev) => ({
      ...prev,
      members: prev.members.map((m) => (m.id === updatedMember.id ? updatedMember : m)),
    }));
    if (currentMember.id === updatedMember.id) {
      setCurrentMember(updatedMember);
    }
    showToast(`Profile updated for ${updatedMember.name}`);
  };

  const handleDeleteMember = (memberId: string) => {
    setState((prev) => ({
      ...prev,
      members: prev.members.filter((m) => m.id !== memberId),
    }));
    showToast('Member removed from family vault');
  };

  // Handlers for Emergency Phone Broadcast
  const handleBroadcastAlert = (alert: EmergencyAlert) => {
    setState((prev) => ({
      ...prev,
      activeAlert: alert,
      alertHistory: [alert, ...(prev.alertHistory || [])],
    }));
    showToast('🚨 Emergency alert signaled to all family phones!');
  };

  const handleResolveAlert = () => {
    setState((prev) => ({
      ...prev,
      activeAlert: null,
    }));
    showToast('Emergency alert marked as resolved ✓');
  };

  const handleAddVitalLog = (log: VitalLog) => {
    setState((prev) => ({
      ...prev,
      vitals: [log, ...prev.vitals],
    }));
    showToast('Vitals recorded successfully');
  };

  const handleDeleteVitalLog = (id: string) => {
    setState((prev) => ({
      ...prev,
      vitals: prev.vitals.filter((v) => v.id !== id),
    }));
  };

  const handleAddMedicalRecord = (rec: MedicalRecord) => {
    setState((prev) => ({
      ...prev,
      medicalRecords: [rec, ...prev.medicalRecords],
    }));
    showToast(`Medical record saved: ${rec.title}`);
  };

  const handleDeleteMedicalRecord = (id: string) => {
    setState((prev) => ({
      ...prev,
      medicalRecords: prev.medicalRecords.filter((r) => r.id !== id),
    }));
  };

  // Handlers for Documents
  const handleAddDocument = (doc: DocumentItem) => {
    setState((prev) => ({
      ...prev,
      documents: [doc, ...prev.documents],
    }));
    showToast(`Document secured: ${doc.title}`);
  };

  const handleDeleteDocument = (id: string) => {
    setState((prev) => ({
      ...prev,
      documents: prev.documents.filter((d) => d.id !== id),
    }));
    showToast('Document removed');
  };

  const handleToggleDocumentLock = (id: string) => {
    setState((prev) => ({
      ...prev,
      documents: prev.documents.map((d) => (d.id === id ? { ...d, isLocked: !d.isLocked } : d)),
    }));
  };

  // Handlers for Photos
  const handleAddFolder = (folder: PhotoFolder) => {
    setState((prev) => ({
      ...prev,
      photoFolders: [...prev.photoFolders, folder],
    }));
    showToast(`Created album: ${folder.name}`);
  };

  const handleAddPhoto = (photo: PhotoItem) => {
    setState((prev) => ({
      ...prev,
      photos: [photo, ...prev.photos],
    }));
    showToast(`Photo saved: ${photo.title}`);
  };

  const handleDeletePhoto = (id: string) => {
    setState((prev) => ({
      ...prev,
      photos: prev.photos.filter((p) => p.id !== id),
    }));
    showToast('Photo deleted');
  };

  const handleDeleteFolder = (folderId: string) => {
    setState((prev) => ({
      ...prev,
      photoFolders: prev.photoFolders.filter((f) => f.id !== folderId),
      photos: prev.photos.filter((p) => p.folderId !== folderId),
    }));
    showToast('Album folder deleted');
  };

  // Handlers for Drive Cloud Sync
  const handleTriggerBackup = async () => {
    setState((prev) => ({
      ...prev,
      driveSync: { ...prev.driveSync, isSyncing: true },
    }));

    const result = await DriveSyncService.uploadVaultBackup(state);

    setState((prev) => ({
      ...prev,
      driveSync: {
        ...prev.driveSync,
        isSyncing: false,
        lastSyncTime: result.timestamp,
        syncedFilesCount: prev.documents.length + prev.photos.length + 5,
      },
    }));

    showToast(result.message);
  };

  const handleRestoreState = (restored: VaultState) => {
    setState(restored);
    if (restored.members.length > 0) {
      setCurrentMember(restored.members[0]);
    }
    showToast('Das Family Vault restored from backup archive!');
  };

  const handleToggleAutoSync = (enabled: boolean) => {
    setState((prev) => ({
      ...prev,
      driveSync: { ...prev.driveSync, autoSyncEnabled: enabled },
    }));
    showToast(enabled ? 'Automatic Google Drive sync enabled' : 'Automatic sync paused');
  };

  const handleUpdateFrequency = (freq: 'realtime' | 'daily' | 'weekly') => {
    setState((prev) => ({
      ...prev,
      driveSync: { ...prev.driveSync, syncFrequency: freq },
    }));
    showToast(`Sync frequency set to ${freq}`);
  };

  if (!isAuthenticated) {
    return (
      <>
        {/* Active Family Emergency Pulsating Banner */}
        {state.activeAlert && (
          <ActiveEmergencyBanner
            alert={state.activeAlert}
            onOpenSOS={() => setShowSOSModal(true)}
            onResolve={handleResolveAlert}
          />
        )}

        {/* Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-2xl bg-white border-2 border-rose-300 text-rose-950 text-xs sm:text-sm font-bold shadow-2xl shadow-rose-950/20 animate-bounce">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{toastMessage.text}</span>
          </div>
        )}

        <LoginScreen
          members={registeredMembers}
          onLoginSuccess={(member) => {
            setCurrentMember(member);
            setIsAuthenticated(true);
            showToast(`${member.name} হিসেবে লগইন সফল! দাস পরিবার ভল্টে স্বাগতম।`);
          }}
          onAddNewMember={handleAddNewMember}
          onOpenSOS={() => setShowSOSModal(true)}
          currentLang={currentLang}
          onLanguageChange={setCurrentLang}
        />

        {/* Emergency Phone Broadcast Alert Modal accessible from Login Screen */}
        <EmergencyBroadcastModal
          isOpen={showSOSModal}
          onClose={() => setShowSOSModal(false)}
          currentMember={currentMember}
          allMembers={registeredMembers}
          currentLang={currentLang}
          onBroadcastAlert={handleBroadcastAlert}
          onResolveAlert={handleResolveAlert}
          activeAlert={state.activeAlert}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#faf8f7] text-slate-900 flex flex-col selection:bg-rose-900 selection:text-white font-sans antialiased relative overflow-x-hidden">
      
      {/* Background Decorative Bengali Kolka Watermark Accents */}
      <div className="fixed -top-10 -left-10 pointer-events-none opacity-10 z-0">
        <KolkaCorner className="w-64 h-64" color="#881337" />
      </div>
      <div className="fixed -bottom-10 -right-10 pointer-events-none opacity-10 z-0 rotate-180">
        <KolkaCorner className="w-72 h-72" color="#881337" />
      </div>

      {/* Active Family Emergency Pulsating Banner */}
      {state.activeAlert && (
        <ActiveEmergencyBanner
          alert={state.activeAlert}
          onOpenSOS={() => setShowSOSModal(true)}
          onResolve={handleResolveAlert}
        />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-2xl bg-white border-2 border-rose-300 text-rose-950 text-xs sm:text-sm font-bold shadow-2xl shadow-rose-950/20 animate-bounce">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{toastMessage.text}</span>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        currentMember={currentMember}
        onOpenMemberSwitcher={() => setShowLoginModal(true)}
        onOpenMyProfile={() => {
          setEditingTargetMember(currentMember);
          setShowProfileModal(true);
        }}
        onOpenSOS={() => setShowSOSModal(true)}
        onOpenDriveModal={() => setActiveTab('drive')}
        onOpenAI={() => setActiveTab('ai')}
        onOpenPlayStore={() => setActiveTab('playstore')}
        onLogout={() => {
          localStorage.removeItem('das_family_active_user_id');
          setIsAuthenticated(false);
          showToast('দাস পরিবার ভল্ট থেকে লগআউট সম্পন্ন হয়েছে', 'info');
        }}
        currentLang={currentLang}
        onLanguageChange={setCurrentLang}
        driveSync={state.driveSync}
      />

      {/* Navigation Tabs Bar with White Background and Deep Crimson Red Theme */}
      <nav className="bg-white/95 border-b-2 border-rose-200 sticky top-16 sm:top-20 z-30 backdrop-blur-md shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center space-x-1 sm:space-x-2 overflow-x-auto py-2.5 no-scrollbar">
            
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'dashboard'
                  ? 'bg-rose-900 text-white shadow-md shadow-rose-900/25 ring-2 ring-rose-900/20'
                  : 'text-rose-950 hover:bg-rose-50 border border-transparent hover:border-rose-200'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              {t.dashboard}
            </button>

            <button
              onClick={() => setActiveTab('members')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'members'
                  ? 'bg-rose-900 text-white shadow-md shadow-rose-900/25 ring-2 ring-rose-900/20'
                  : 'text-rose-950 hover:bg-rose-50 border border-transparent hover:border-rose-200'
              }`}
            >
              <Users className="w-4 h-4" />
              {t.members} ({registeredMembers.length})
            </button>

            {/* AI Assistant Navigation Tab (For Everyone in Family) */}
            <button
              onClick={() => setActiveTab('ai')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all border-2 ${
                activeTab === 'ai'
                  ? 'bg-rose-900 text-amber-200 border-rose-800 shadow-md shadow-rose-900/25 ring-2 ring-rose-900/20 font-black'
                  : 'bg-rose-50/70 text-rose-950 hover:bg-rose-100 border-rose-200'
              }`}
            >
              <Sparkles className="w-4 h-4 text-amber-500 animate-spin-slow" />
              <span>এআই সহায়ক</span>
              <span className="text-[10px] bg-rose-100 text-rose-900 px-1.5 py-0.2 rounded font-black">AI</span>
            </button>

            <button
              onClick={() => setActiveTab('health')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'health'
                  ? 'bg-rose-900 text-white shadow-md shadow-rose-900/25 ring-2 ring-rose-900/20'
                  : 'text-rose-950 hover:bg-rose-50 border border-transparent hover:border-rose-200'
              }`}
            >
              <Heart className="w-4 h-4 text-rose-500" />
              {t.healthSafe}
            </button>

            <button
              onClick={() => setActiveTab('documents')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'documents'
                  ? 'bg-rose-900 text-white shadow-md shadow-rose-900/25 ring-2 ring-rose-900/20'
                  : 'text-rose-950 hover:bg-rose-50 border border-transparent hover:border-rose-200'
              }`}
            >
              <FileText className="w-4 h-4 text-rose-700" />
              {t.documents} ({state.documents.length})
            </button>

            <button
              onClick={() => setActiveTab('photos')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'photos'
                  ? 'bg-rose-900 text-white shadow-md shadow-rose-900/25 ring-2 ring-rose-900/20'
                  : 'text-rose-950 hover:bg-rose-50 border border-transparent hover:border-rose-200'
              }`}
            >
              <ImageIcon className="w-4 h-4 text-rose-600" />
              {t.photos} ({state.photos.length})
            </button>

            <button
              onClick={() => setActiveTab('drive')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                activeTab === 'drive'
                  ? 'bg-rose-900 text-white shadow-md shadow-rose-900/25 ring-2 ring-rose-900/20'
                  : 'text-rose-950 hover:bg-rose-50 border border-transparent hover:border-rose-200'
              }`}
            >
              <Cloud className="w-4 h-4 text-rose-700" />
              {t.driveBackup}
            </button>

            {/* Google Play Store & Mobile App Center Tab */}
            <button
              onClick={() => setActiveTab('playstore')}
              className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs sm:text-sm font-black whitespace-nowrap transition-all border-2 ${
                activeTab === 'playstore'
                  ? 'bg-emerald-700 text-white border-emerald-600 shadow-md shadow-emerald-900/25 ring-2 ring-emerald-700/20'
                  : 'bg-emerald-50/80 text-emerald-950 hover:bg-emerald-100 border-emerald-300'
              }`}
            >
              <Smartphone className="w-4 h-4 text-emerald-600" />
              <span className={activeTab === 'playstore' ? 'text-white' : 'text-emerald-950'}>
                গুগল প্লে স্টোর
              </span>
              <span className="text-[10px] bg-white text-emerald-900 px-1.5 py-0.2 rounded font-black">
                APK/AAB
              </span>
            </button>

            {/* Admin Master Panel Tab */}
            {currentMember.role === 'admin' && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all border-2 ${
                  activeTab === 'admin'
                    ? 'bg-rose-950 text-amber-300 border-rose-800 shadow-lg shadow-rose-950/25 ring-2 ring-rose-900/30 font-black'
                    : 'bg-rose-50 border-rose-300 text-rose-900 hover:bg-rose-100 font-bold'
                }`}
              >
                <span>👑</span>
                <span>{t.adminPanel}</span>
              </button>
            )}
          </div>
        </div>
      </nav>

      {/* Main Container Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            state={state}
            currentMember={currentMember}
            currentLang={currentLang}
            onNavigateTab={(tab) => setActiveTab(tab as any)}
            onOpenSOS={() => setShowSOSModal(true)}
            onOpenDriveModal={() => setActiveTab('drive')}
            onTriggerBackup={handleTriggerBackup}
          />
        )}

        {activeTab === 'members' && (
          <MembersView
            members={registeredMembers}
            currentMember={currentMember}
            currentLang={currentLang}
            onSelectMember={handleSelectMember}
            onUpdateMember={handleUpdateMember}
            onAddNewMember={handleAddNewMember}
            onDeleteMember={handleDeleteMember}
          />
        )}

        {/* DAS FAMILY AI ASSISTANT (EVERYONE IN FAMILY CAN USE) */}
        {activeTab === 'ai' && (
          <FamilyAIAssistant
            currentMember={currentMember}
            allMembers={registeredMembers}
            currentLang={currentLang}
            onOpenSOS={() => setShowSOSModal(true)}
          />
        )}

        {activeTab === 'health' && (
          <HealthSafeView
            state={state}
            currentLang={currentLang}
            onAddVitalLog={handleAddVitalLog}
            onDeleteVitalLog={handleDeleteVitalLog}
            onAddMedicalRecord={handleAddMedicalRecord}
            onDeleteMedicalRecord={handleDeleteMedicalRecord}
            onOpenSOS={() => setShowSOSModal(true)}
          />
        )}

        {activeTab === 'documents' && (
          <DocumentsView
            state={state}
            currentMember={currentMember}
            currentLang={currentLang}
            onAddDocument={handleAddDocument}
            onDeleteDocument={handleDeleteDocument}
            onToggleLock={handleToggleDocumentLock}
          />
        )}

        {activeTab === 'photos' && (
          <PhotoVaultView
            state={state}
            currentLang={currentLang}
            onAddFolder={handleAddFolder}
            onAddPhoto={handleAddPhoto}
            onDeletePhoto={handleDeletePhoto}
            onDeleteFolder={handleDeleteFolder}
          />
        )}

        {activeTab === 'drive' && (
          <DriveBackupView
            state={state}
            currentLang={currentLang}
            onTriggerBackup={handleTriggerBackup}
            onRestoreState={handleRestoreState}
            onToggleAutoSync={handleToggleAutoSync}
            onUpdateFrequency={handleUpdateFrequency}
          />
        )}

        {activeTab === 'playstore' && (
          <PlayStoreView onShowToast={showToast} />
        )}

        {activeTab === 'admin' && (
          <AdminMasterView
            state={state}
            currentMember={currentMember}
            currentLang={currentLang}
            onSelectMember={handleSelectMember}
            onUpdateMember={handleUpdateMember}
            onAddNewMember={handleAddNewMember}
            onOpenEditModal={(m) => {
              setEditingTargetMember(m);
              setShowProfileModal(true);
            }}
          />
        )}
      </main>

      {/* Footer in Kolka White & Deep Red */}
      <footer className="bg-white border-t-2 border-rose-200 text-xs text-rose-950 py-6 text-center shadow-inner relative z-10">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="font-bold text-rose-950 flex items-center gap-1.5 justify-center">
            <span className="text-rose-700">✿</span> দাস পরিবার ভল্ট (DAS FAMILY VAULT) • সুরক্ষিত পারিবারিক স্বাস্থ্য ও ডিজিটাল ভল্ট
          </p>
          <p className="text-[11px] text-slate-600">
            গুগল ড্রাইভ ব্যাকআপ সিঙ্ক: <span className="font-mono text-rose-900 font-bold">milon8727@gmail.com</span>
          </p>
        </div>
      </footer>

      {/* Personal Profile & Info Editor Modal */}
      {showProfileModal && (
        <MyProfileModal
          isOpen={showProfileModal}
          onClose={() => {
            setShowProfileModal(false);
            setEditingTargetMember(null);
          }}
          member={editingTargetMember || currentMember}
          onSaveProfile={(updated) => {
            handleUpdateMember(updated);
          }}
          currentLang={currentLang}
        />
      )}

      {/* Emergency Phone Broadcast Alert Modal */}
      <EmergencyBroadcastModal
        isOpen={showSOSModal}
        onClose={() => setShowSOSModal(false)}
        currentMember={currentMember}
        allMembers={registeredMembers}
        currentLang={currentLang}
        onBroadcastAlert={handleBroadcastAlert}
        onResolveAlert={handleResolveAlert}
        activeAlert={state.activeAlert}
      />

      {/* Login & Member Switcher Modal */}
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        members={registeredMembers}
        onSelectMember={(m) => {
          handleSelectMember(m);
          localStorage.setItem('das_family_active_user_id', m.id);
        }}
        onAddNewMember={handleAddNewMember}
        currentLang={currentLang}
      />
    </div>
  );
}
