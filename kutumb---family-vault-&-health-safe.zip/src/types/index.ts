export type Language = 'en' | 'hi' | 'bn';

export type UserRole = 'admin' | 'member' | 'child_or_elder';

export interface FamilyMember {
  id: string;
  name: string;
  relationship: 'head' | 'spouse' | 'son' | 'daughter' | 'father' | 'mother' | 'grandfather' | 'grandmother' | 'other';
  avatarUrl?: string;
  avatarBg?: string;
  gender: 'male' | 'female' | 'other';
  dob: string;
  age?: number;
  phone: string;
  email: string;
  loginId: string;
  password?: string;
  pin: string;
  role: UserRole;
  bloodGroup: string;
  allergies: string[];
  chronicConditions: string[];
  emergencyContactName: string;
  emergencyContactPhone: string;
  insurancePolicyNo?: string;
  primaryDoctorName?: string;
  primaryDoctorPhone?: string;
  notes?: string;
  // Registration security - only registered persons are shown in the app
  isRegistered: boolean;
  registeredAt?: string;
  registrationId?: string;
}

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  category?: string;
  readAloud?: boolean;
}

export interface Medication {
  id: string;
  memberId: string;
  name: string;
  dosage: string;
  frequency: string;
  timing: 'before_food' | 'after_food' | 'with_food' | 'as_needed';
  startDate: string;
  endDate?: string;
  prescribedBy: string;
  active: boolean;
  notes?: string;
}

export interface VitalLog {
  id: string;
  memberId: string;
  date: string;
  time?: string;
  bpSystolic?: number;
  bpDiastolic?: number;
  bloodSugar?: number;
  bloodSugarType?: 'fasting' | 'post_prandial' | 'random';
  weight?: number; // kg
  pulse?: number; // bpm
  spo2?: number; // %
  notes?: string;
}

export interface MedicalRecord {
  id: string;
  memberId: string;
  title: string;
  type: 'prescription' | 'lab_report' | 'vaccination' | 'hospital_summary' | 'imaging' | 'dental' | 'doctor_visit' | 'other';
  date: string;
  doctorOrHospital: string;
  diagnosisOrNotes: string;
  fileUrl?: string;
  fileName?: string;
  fileType?: string;
}

export type DocumentCategory = 
  | 'identity' 
  | 'insurance' 
  | 'property' 
  | 'financial' 
  | 'education' 
  | 'medical' 
  | 'vehicle' 
  | 'other';

export interface DocumentItem {
  id: string;
  memberId: string; // 'all' for shared family document
  title: string;
  category: DocumentCategory;
  documentNumber?: string;
  issueDate?: string;
  expiryDate?: string;
  isLocked: boolean;
  tags: string[];
  notes?: string;
  fileData?: string; // base64 / blob URL / mock URL
  fileName: string;
  fileSize?: string;
  fileType: string;
  createdAt: string;
}

export interface PhotoFolder {
  id: string;
  name: string;
  description?: string;
  iconName?: string;
  color?: string;
  createdAt: string;
}

export interface PhotoItem {
  id: string;
  folderId: string;
  memberId?: string;
  title: string;
  url: string;
  date: string;
  taggedMemberIds: string[];
  caption?: string;
  fileSize?: string;
}

export interface EmergencyAlert {
  id: string;
  triggeredByMemberId: string;
  triggeredByName: string;
  timestamp: string;
  latitude?: number;
  longitude?: number;
  locationName?: string;
  googleMapsUrl?: string;
  status: 'active' | 'resolved';
  alertMessage: string;
  notifiedPhoneNumbers: string[];
}

export interface DriveSyncState {
  isConnected: boolean;
  accountEmail: string | null;
  lastSyncTime: string | null;
  autoSyncEnabled: boolean;
  syncFrequency: 'realtime' | 'daily' | 'weekly';
  folderName: string;
  syncedFilesCount: number;
  isSyncing: boolean;
}

export interface VaultState {
  familyName: string;
  familyHeadId: string;
  members: FamilyMember[];
  vitals: VitalLog[];
  medicalRecords: MedicalRecord[];
  documents: DocumentItem[];
  photoFolders: PhotoFolder[];
  photos: PhotoItem[];
  driveSync: DriveSyncState;
  activeAlert?: EmergencyAlert | null;
  alertHistory?: EmergencyAlert[];
}
