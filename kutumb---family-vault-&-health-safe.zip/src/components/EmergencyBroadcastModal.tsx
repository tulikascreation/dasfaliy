import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  X, 
  Phone, 
  MapPin, 
  Volume2, 
  VolumeX, 
  MessageSquare, 
  Share2, 
  Check, 
  ShieldAlert, 
  Radio, 
  Users, 
  Clock, 
  ExternalLink,
  Flame,
  ArrowRight
} from 'lucide-react';
import { FamilyMember, Language, EmergencyAlert } from '../types';
import { getTranslation } from '../utils/translations';
import { playEmergencySiren, stopEmergencySiren } from '../utils/emergencyAudio';
import { KolkaCorner } from './KolkaMotifs';

interface EmergencyBroadcastModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentMember: FamilyMember;
  allMembers: FamilyMember[];
  currentLang: Language;
  onBroadcastAlert: (alert: EmergencyAlert) => void;
  onResolveAlert: () => void;
  activeAlert?: EmergencyAlert | null;
}

export const EmergencyBroadcastModal: React.FC<EmergencyBroadcastModalProps> = ({
  isOpen,
  onClose,
  currentMember,
  allMembers,
  currentLang,
  onBroadcastAlert,
  onResolveAlert,
  activeAlert,
}) => {
  const t = getTranslation(currentLang);
  const [sirenPlaying, setSirenPlaying] = useState(false);
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locationAddress, setLocationAddress] = useState<string>('Kolkata, West Bengal (Live GPS)');
  const [customMsg, setCustomMsg] = useState('জরুরি চিকিৎসা বা সাহায্য প্রয়োজন! অনুগ্রহ করে অবিলম্বে যোগাযোগ করুন।');
  const [copiedLink, setCopiedLink] = useState(false);
  const [dispatchConfirmed, setDispatchConfirmed] = useState(false);

  // Fetch live GPS when opened
  useEffect(() => {
    if (isOpen) {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            setCoords({
              lat: pos.coords.latitude,
              lng: pos.coords.longitude,
            });
            setLocationAddress(`অক্ষাংশ: ${pos.coords.latitude.toFixed(4)}, দ্রাঘিমাংশ: ${pos.coords.longitude.toFixed(4)} (কলকাতা ও আশেপাশের এলাকা)`);
          },
          (err) => {
            console.warn('Geolocation error:', err);
            setCoords({ lat: 22.5804, lng: 88.4191 });
            setLocationAddress('সল্টলেক সেক্টর ১, কলকাতা ৭০০০৬৪');
          },
          { enableHighAccuracy: true, timeout: 6000 }
        );
      } else {
        setCoords({ lat: 22.5804, lng: 88.4191 });
        setLocationAddress('সল্টলেক সেক্টর ১, কলকাতা ৭০০০৬৪');
      }
    } else {
      stopEmergencySiren();
      setSirenPlaying(false);
    }

    return () => {
      stopEmergencySiren();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const googleMapsUrl = coords 
    ? `https://www.google.com/maps?q=${coords.lat},${coords.lng}`
    : 'https://www.google.com/maps?q=22.5804,88.4191';

  const emergencyPhoneList = allMembers.map((m) => m.phone).filter(Boolean);

  const emergencyMessage = `🚨 দাস পরিবার জরুরি এসওএস অ্যালার্ট (DAS FAMILY EMERGENCY ALERT)! 🚨\n\n` +
    `👤 প্রেরক: ${currentMember.name.toUpperCase()} (${currentMember.relationship.toUpperCase()})\n` +
    `🩸 রক্তের গ্রুপ: ${currentMember.bloodGroup}\n` +
    `⚠️ বার্তা: ${customMsg}\n` +
    `📍 লাইভ জিপিএস লোকেশন লিঙ্ক:\n${googleMapsUrl}\n\n` +
    `📞 জরুরি অভিভাবক: ${currentMember.emergencyContactName} (${currentMember.emergencyContactPhone})\n` +
    `👨‍⚕️ পারিবারিক ডাক্তার: ${currentMember.primaryDoctorName || 'ডা. অম্লান ব্যানার্জী'} (${currentMember.primaryDoctorPhone || '+91 94330 11223'})\n\n` +
    `🚑 অ্যাম্বুলেন্স: ১০৮ | জরুরি পুলিশ ও সহায়তা: ১১২`;

  const handleTriggerBroadcast = () => {
    // Start siren
    playEmergencySiren();
    setSirenPlaying(true);

    const alertItem: EmergencyAlert = {
      id: `alert-${Date.now()}`,
      triggeredByMemberId: currentMember.id,
      triggeredByName: currentMember.name,
      timestamp: new Date().toLocaleTimeString(),
      latitude: coords?.lat || 22.5804,
      longitude: coords?.lng || 88.4191,
      locationName: locationAddress,
      googleMapsUrl,
      status: 'active',
      alertMessage: customMsg,
      notifiedPhoneNumbers: emergencyPhoneList,
    };

    onBroadcastAlert(alertItem);
    setDispatchConfirmed(true);
  };

  const toggleSiren = () => {
    if (sirenPlaying) {
      stopEmergencySiren();
      setSirenPlaying(false);
    } else {
      playEmergencySiren();
      setSirenPlaying(true);
    }
  };

  const handleWhatsAppAll = () => {
    const encoded = encodeURIComponent(emergencyMessage);
    window.open(`https://api.whatsapp.com/send?text=${encoded}`, '_blank');
  };

  const handleSmsAll = () => {
    const phones = emergencyPhoneList.map((p) => p.replace(/\s+/g, '')).join(',');
    const encoded = encodeURIComponent(emergencyMessage);
    window.location.href = `sms:${phones}?body=${encoded}`;
  };

  const handleCopyAlert = () => {
    navigator.clipboard.writeText(emergencyMessage);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/70 backdrop-blur-md overflow-y-auto animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white border-4 border-rose-800 rounded-3xl shadow-2xl overflow-hidden my-6">
        
        {/* Urgent Header in Deep Crimson Red */}
        <div className="relative p-5 sm:p-6 bg-gradient-to-r from-red-600 via-rose-700 to-rose-900 text-white flex items-center justify-between overflow-hidden">
          <div className="absolute top-0 right-0 pointer-events-none opacity-20">
            <KolkaCorner className="w-36 h-36" color="#ffffff" />
          </div>

          <div className="relative z-10 flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-sm animate-pulse">
              <ShieldAlert className="w-8 h-8 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase font-black px-2.5 py-0.5 rounded-full bg-white text-rose-900 tracking-wider">
                  লাইভ এসওএস সম্প্রচার
                </span>
                <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-wide mt-0.5">
                দাস পরিবার জরুরি এসওএস স্টেশন
              </h2>
            </div>
          </div>

          <button
            onClick={() => {
              stopEmergencySiren();
              onClose();
            }}
            className="relative z-10 p-2 text-rose-100 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Big Alert Trigger / Siren Controller Bar */}
        <div className="bg-rose-50 p-4 sm:p-5 border-b-2 border-rose-200 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSiren}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-black text-xs transition-all ${
                sirenPlaying
                  ? 'bg-red-600 text-white animate-bounce shadow-lg shadow-red-600/40'
                  : 'bg-white text-rose-900 hover:bg-rose-100 border border-rose-300'
              }`}
            >
              {sirenPlaying ? <Volume2 className="w-4 h-4 text-white" /> : <VolumeX className="w-4 h-4 text-rose-700" />}
              {sirenPlaying ? 'সাইরেন বাজছে (বন্ধ করতে ট্যাপ করুন)' : 'জরুরি সাইরেন বাজান'}
            </button>

            <span className="text-xs text-slate-700">
              প্রেরক: <strong className="text-rose-950 font-bold">{currentMember.name}</strong> ({currentMember.bloodGroup})
            </span>
          </div>

          {activeAlert && (
            <button
              onClick={() => {
                stopEmergencySiren();
                onResolveAlert();
                onClose();
              }}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md transition-colors"
            >
              জরুরি অবস্থা সমাধান চিহ্নিত করুন ✓
            </button>
          )}
        </div>

        {/* Main Body with Clean White Background */}
        <div className="p-5 sm:p-6 space-y-5 max-h-[70vh] overflow-y-auto">
          
          {/* Giant SOS Broadcast Button */}
          {!dispatchConfirmed ? (
            <div className="text-center space-y-3 p-6 rounded-3xl bg-gradient-to-b from-rose-50 to-white border-2 border-rose-300 shadow-md">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-100 text-rose-900 text-xs font-bold border border-rose-200">
                <Radio className="w-3.5 h-3.5 text-rose-700 animate-pulse" />
                নিচের লাল বোতামে চাপ দিলে একই সাথে পরিবারের সবার ফোনে সতর্কবার্তা যাবে
              </div>

              <div>
                <button
                  onClick={handleTriggerBroadcast}
                  className="w-full py-5 px-6 rounded-2xl bg-gradient-to-r from-red-600 via-rose-700 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-lg sm:text-xl tracking-wider shadow-2xl shadow-red-700/30 ring-4 ring-rose-200 active:scale-95 transition-all flex items-center justify-center gap-3"
                >
                  <Flame className="w-7 h-7 text-amber-200 animate-bounce" />
                  🚨 সবার ফোনে তাৎক্ষণিক অ্যালার্ট পাঠান 🚨
                </button>
              </div>

              <p className="text-xs text-slate-600 max-w-md mx-auto">
                লাইভ জিপিএস ম্যাপ লোকেশন ও জরুরি মেডিকেল তথ্যসহ মিলন, সুনীতা, সুভাষ, রোহিত ও অনন্যার ফোনে বার্তা যাবে।
              </p>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center justify-between shadow-sm">
              <span className="flex items-center gap-2">
                <Check className="w-5 h-5 text-emerald-600 shrink-0" />
                জরুরি এসওএস অ্যালার্ট সফলভাবে সক্রিয় করা হয়েছে! সব ফোনে সংকেত পাঠানো হয়েছে।
              </span>
              <span className="text-[11px] font-mono text-emerald-700 font-bold">লাইভ অ্যালার্ট চলছে</span>
            </div>
          )}

          {/* Real-time Location Pin in White Card */}
          <div className="p-4 rounded-2xl bg-white border-2 border-rose-200 space-y-2 shadow-sm">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-950 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-red-600" />
                লাইভ জিপিএস লোকেশন সংযুক্ত
              </span>
              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noreferrer"
                className="text-xs text-rose-700 hover:text-rose-900 flex items-center gap-1 font-bold underline"
              >
                গুগল ম্যাপে দেখুন <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <p className="text-xs text-slate-700 font-mono bg-rose-50/60 p-3 rounded-xl border border-rose-200">
              📍 {locationAddress}
            </p>
          </div>

          {/* Quick Instant Dispatch Options to All Phones */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-rose-950 uppercase tracking-wider flex items-center gap-1.5">
              <Phone className="w-4 h-4 text-rose-700" />
              পরিবারের কাছে তাৎক্ষণিক বার্তা পাঠানোর মাধ্যম:
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* WhatsApp Broadcast */}
              <button
                onClick={handleWhatsAppAll}
                className="p-3.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 border-2 border-emerald-200 text-emerald-950 font-bold text-xs flex items-center justify-between transition-all shadow-sm"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center text-sm shadow">
                    💬
                  </div>
                  <div className="text-left">
                    <p className="font-black text-slate-900 text-xs">হোয়াটসঅ্যাপ অ্যালার্ট পাঠান</p>
                    <p className="text-[10px] text-emerald-800">জিপিএস ম্যাপ ও জরুরি বিবরণসহ</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-emerald-700" />
              </button>

              {/* SMS Broadcast */}
              <button
                onClick={handleSmsAll}
                className="p-3.5 rounded-2xl bg-rose-50 hover:bg-rose-100 border-2 border-rose-200 text-rose-950 font-bold text-xs flex items-center justify-between transition-all shadow-sm"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-rose-900 text-white flex items-center justify-center text-sm shadow">
                    📱
                  </div>
                  <div className="text-left">
                    <p className="font-black text-slate-900 text-xs">সবার ফোনে সরাসরি এসএমএস</p>
                    <p className="text-[10px] text-rose-800">মোবাইল নেটওয়ার্কের মাধ্যমে</p>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-rose-700" />
              </button>
            </div>
          </div>

          {/* Family Member Phone Directory with Click-to-Call */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-rose-950 uppercase tracking-wider flex items-center gap-1.5">
              <Users className="w-4 h-4 text-rose-800" />
              পরিবারের সদস্যদের জরুরি ফোন তালিকা (এক ক্লিকে কল):
            </h4>

            <div className="space-y-2">
              {allMembers.map((m) => (
                <div
                  key={m.id}
                  className="p-3 rounded-2xl bg-white border border-rose-200 flex items-center justify-between text-xs shadow-sm hover:border-rose-300 transition-colors"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-rose-900 flex items-center justify-center text-xs font-bold text-white shadow">
                      {m.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-bold text-rose-950 flex items-center gap-1.5">
                        {m.name}
                        <span className="text-[10px] text-rose-700 font-bold">({m.bloodGroup})</span>
                      </p>
                      <p className="text-[10px] text-slate-500 capitalize">{m.relationship} • {m.phone}</p>
                    </div>
                  </div>

                  <a
                    href={`tel:${m.phone.replace(/\s+/g, '')}`}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow transition-colors"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    সরাসরি কল
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Helplines */}
          <div className="pt-2 border-t border-rose-100 flex items-center justify-between gap-3 text-xs">
            <a
              href="tel:108"
              className="flex-1 py-2 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-950 border border-rose-200 font-bold text-center flex items-center justify-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-rose-700" /> অ্যাম্বুলেন্স: ১০৮
            </a>
            <a
              href="tel:1066"
              className="flex-1 py-2 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-950 border border-rose-200 font-bold text-center flex items-center justify-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-rose-700" /> অ্যাপোলো: ১০৬৬
            </a>
            <a
              href="tel:112"
              className="flex-1 py-2 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-950 border border-rose-200 font-bold text-center flex items-center justify-center gap-1.5"
            >
              <Phone className="w-3.5 h-3.5 text-rose-700" /> হেল্পলাইন: ১১২
            </a>
          </div>
        </div>

        {/* Footer in White & Rose */}
        <div className="p-4 bg-rose-50 border-t-2 border-rose-200 flex items-center justify-between">
          <button
            onClick={handleCopyAlert}
            className="text-xs font-bold text-rose-900 hover:text-rose-950 flex items-center gap-1.5"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5 text-rose-700" />}
            {copiedLink ? 'বার্তার বিবরণ কপি হয়েছে!' : 'এসওএস বার্তা কপি করুন'}
          </button>

          <button
            onClick={() => {
              stopEmergencySiren();
              onClose();
            }}
            className="px-5 py-2 rounded-xl bg-white border border-rose-200 hover:bg-rose-100 text-rose-950 font-bold text-xs shadow-sm transition-colors"
          >
            উইন্ডো বন্ধ করুন
          </button>
        </div>
      </div>
    </div>
  );
};
