import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  Volume2, 
  VolumeX, 
  Copy, 
  Check, 
  RefreshCw, 
  User, 
  BookOpen, 
  HeartHandshake, 
  Utensils, 
  FileText, 
  GraduationCap, 
  ShieldAlert, 
  Trash2,
  HelpCircle,
  Lightbulb
} from 'lucide-react';
import { FamilyMember, Language, AIChatMessage } from '../types';
import { KolkaCorner, KolkaDivider, KolkaBadge } from './KolkaMotifs';

interface FamilyAIAssistantProps {
  currentMember: FamilyMember;
  allMembers: FamilyMember[];
  currentLang: Language;
  onOpenSOS?: () => void;
}

interface PromptPreset {
  id: string;
  category: string;
  label: string;
  icon: string;
  prompt: string;
  audience: string;
}

const PRESET_PROMPTS: PromptPreset[] = [
  // For Elders / Grandparents
  {
    id: 'p1',
    category: 'elder_care',
    label: 'বরিষ্ঠদের দৈনন্দিন সুস্বাস্থ্য পরামর্শ',
    icon: '👵',
    audience: 'বরিষ্ঠ সদস্য',
    prompt: 'পরিবারের প্রবীণ সদস্যদের জন্য প্রাতঃকালীন স্বাস্থ্যবিধি, হালকা হাঁটাচলা এবং রক্তচাপ স্বাভাবিক রাখার সহজ ঘরোয়া সুঅভ্যাস সম্পর্কে বিস্তারিত বাংলা পরামর্শ দিন।',
  },
  {
    id: 'p2',
    category: 'elder_care',
    label: 'হালকা ও সহজপাচ্য বাঙালি খাদ্যতালিকা',
    icon: '🍵',
    audience: 'বরিষ্ঠ সদস্য',
    prompt: 'সুগার ও গ্যাস-অম্বল নিয়ন্ত্রণে রাখার জন্য বরিষ্ঠ সদস্যদের উপযোগী হালকা তেল-মশলাহীন ঘরোয়া বাঙালি দৈনিক খাদ্যতালিকার পরামর্শ দিন।',
  },
  // For Recipes / Cooking
  {
    id: 'p3',
    category: 'recipes',
    label: 'বাঙালির ঘরোয়া সুস্বাদু শুকতো রেসিপি',
    icon: '🍲',
    audience: 'সকলের জন্য',
    prompt: 'ঘরোয়া অনুষ্ঠানে পরিবেশনযোগ্য খাঁটি বাঙালি শুকতো রান্নার ধাপ, উপকরণ ও রাঁধুনী ফোড়নের বিশেষ টিপস সহজ বাংলায় লিখে দিন।',
  },
  {
    id: 'p4',
    category: 'recipes',
    label: 'পুজোর স্পেশাল পায়েস ও নাড়ুর রেসিপি',
    icon: '🥥',
    audience: 'সকলের জন্য',
    prompt: 'পারিবারিক উৎসব ও পুজো উপলক্ষে সুস্বাদু গোবিন্দভোগ চালের পায়েস এবং নারকেলের নাড়ু তৈরির সহজ পদ্ধতি ধাপে ধাপে জানান।',
  },
  // For Family Letters & Applications
  {
    id: 'p5',
    category: 'letters',
    label: 'পারিবারিক শুভাকাঙ্ক্ষী নিমন্ত্রণ পত্র',
    icon: '✉️',
    audience: 'গৃহকর্তা / বড়রা',
    prompt: 'দাস পরিবারের পক্ষ থেকে আত্মীয়-স্বজনদের পারিবারিক অনুষ্ঠানে আমন্ত্রণ জানিয়ে একটি মার্জিত ও ঐতিহ্যবাহী বাংলা নিমন্ত্রণ পত্রের খসড়া তৈরি করে দিন।',
  },
  {
    id: 'p6',
    category: 'letters',
    label: 'স্কুলে ছুটির জন্য আবেদন পত্র (বাংলা ও English)',
    icon: '📝',
    audience: 'ছাত্র / অভিভাবক',
    prompt: 'পরিবারের সন্তানের অসুস্থতার কারণে স্কুল প্রধান শিক্ষকের কাছে ৩ দিনের ছুটির একটি প্রাতিষ্ঠানিক দরখাস্ত বাংলা এবং ইংরেজিতে লিখুন।',
  },
  // For Kids & Students
  {
    id: 'p7',
    category: 'kids_study',
    label: 'শিশু ও কিশোরদের সাধারণ জ্ঞান কুইজ',
    icon: '🎒',
    audience: 'ছোটদের জন্য',
    prompt: 'ক্লাস ৩ থেকে ৮-এর ছাত্রছাত্রীদের জন্য বাংলার ভূগোল, বিজ্ঞান ও মহাকাশ সংক্রান্ত ৫টি চমৎকার শিক্ষণীয় কুইজ প্রশ্ন ও সহজ ব্যাখ্যা সহ উত্তর দিন।',
  },
  {
    id: 'p8',
    category: 'kids_study',
    label: 'সুকুমার রায় ধারার মজার শিক্ষণীয় গল্প',
    icon: '📖',
    audience: 'ছোটদের জন্য',
    prompt: 'ছোটদের আনন্দ দেওয়া এবং সততা ও একতার শিক্ষা দেওয়ার মতো একটি হাস্যকৌতুকপূর্ণ বাংলা ছড়া বা রূপকথার ছোট গল্প শোনান।',
  },
  // For Household & Safety
  {
    id: 'p9',
    category: 'budget_safety',
    label: 'পারিবারিক মাসিক বাজেট ও সঞ্চয় গাইড',
    icon: '💰',
    audience: 'গৃহস্থালী',
    prompt: 'মধ্যবিত্ত বাঙালি পরিবারের মাসিক খরচ নিয়ন্ত্রণ, মুদি বাজার ও স্বাস্থ্যসুরক্ষার জরুরি তহবিল গড়ার ৫টি বাস্তবসম্মত স্মার্ট টিপস দিন।',
  },
  {
    id: 'p10',
    category: 'budget_safety',
    label: 'জরুরি অবস্থায় করণীয় প্রাথমিক সতর্কতা',
    icon: '🛡️',
    audience: 'সকলের জন্য',
    prompt: 'হঠাৎ জ্বর, সামান্য পুড়ে যাওয়া বা মাথা ঘোরার মতো জরুরি পারিবারিক পরিস্থিতিতে প্রাথমিক ফার্স্ট-এইড সতর্কতা এবং শান্ত থাকার পদক্ষেপ কী কী?',
  },
];

export const FamilyAIAssistant: React.FC<FamilyAIAssistantProps> = ({
  currentMember,
  allMembers,
  currentLang,
  onOpenSOS,
}) => {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: `নমস্কার ${currentMember.name}! ✿\nআমি দাস পরিবারের নিজস্ব ডিজিটাল এআই সহায়ক (DAS FAMILY AI)।\n\nপরিবারের সবার সুবিধার জন্য আমি প্রস্তুত: বরিষ্ঠদের যত্নের নিয়ম, ঐতিহ্যবাহী বাঙালি রান্না, চিঠি বা দরখাস্ত ড্রাফটিং, ছোটদের পড়াশোনা ও বিজ্ঞান কুইজ, এবং পারিবারিক নিরাপত্তা গাইড।\n\nনিচের বোতামগুলো থেকে সরাসরি বেছে নিতে পারেন অথবা আপনার মনের প্রশ্নটি বাংলায় লিখুন!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  // Clean up speech on unmount
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Send query to server endpoint
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputPrompt).trim();
    if (!query || isLoading) return;

    const userMessage: AIChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!textToSend) setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/family-ai', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: query,
          memberName: currentMember.name,
          memberRole: currentMember.relationship,
          memberAge: currentMember.age,
          topic: activeCategory,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'এআই উত্তর দিতে ব্যর্থ হয়েছে');
      }

      const aiReply: AIChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'assistant',
        text: data.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiReply]);
    } catch (err: any) {
      console.error('AI chat failed:', err);
      const fallbackReply: AIChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: `দুঃখিত, সংযোগে সাময়িক সমস্যা হয়েছে (${err.message || 'Error'})। অনুগ্রহ করে আবার চেষ্টা করুন অথবা ইন্টারনেট সংযোগ যাচাই করুন।`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, fallbackReply]);
    } finally {
      setIsLoading(false);
    }
  };

  // Text-to-speech reading in Bengali / English
  const handleToggleSpeak = (msgId: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    setSpeakingId(msgId);

    const cleanText = text.replace(/[*#_~]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    // Pick Bengali voice if available, otherwise browser default
    const voices = window.speechSynthesis.getVoices();
    const bnVoice = voices.find((v) => v.lang.includes('bn') || v.lang.includes('IN'));
    if (bnVoice) {
      utterance.voice = bnVoice;
    }

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    window.speechSynthesis.speak(utterance);
  };

  const handleCopyText = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(msgId);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleClearHistory = () => {
    if (confirm('আপনি কি পূর্ববর্তী সমস্ত এআই আলোচনা মুছে ফেলতে চান?')) {
      if ('speechSynthesis' in window) window.speechSynthesis.cancel();
      setSpeakingId(null);
      setMessages([
        {
          id: 'welcome-new',
          sender: 'assistant',
          text: `নমস্কার ${currentMember.name}! নতুন আলোচনা শুরু হয়েছে। আপনার প্রশ্নটি লিখুন।`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }
  };

  const filteredPresets = activeCategory === 'all' 
    ? PRESET_PROMPTS 
    : PRESET_PROMPTS.filter(p => p.category === activeCategory);

  return (
    <div className="space-y-6">
      
      {/* Kolka Crimson Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-white border-2 border-rose-300 p-6 sm:p-7 shadow-xl shadow-rose-950/5">
        <div className="absolute top-0 right-0 pointer-events-none opacity-80 rotate-90">
          <KolkaCorner className="w-32 h-32 sm:w-40 sm:h-40" color="#991b1b" />
        </div>
        <div className="absolute bottom-0 left-0 pointer-events-none opacity-80 -rotate-90">
          <KolkaCorner className="w-28 h-28 sm:w-36 sm:h-36" color="#991b1b" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-900 text-xs font-black tracking-wide">
              <Sparkles className="w-4 h-4 text-rose-700 animate-spin-slow" />
              <span>দাস পরিবার এআই ডিজিটাল সহায়ক • সর্বজনীন ব্যবহার</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-rose-950 tracking-tight flex items-center gap-2">
              পারিবারিক এআই সহায়ক
              <span className="text-xs px-2.5 py-1 rounded-full bg-rose-900 text-amber-200 font-bold border border-rose-700">
                AI Assistant
              </span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-700 max-w-2xl leading-relaxed">
              পরিবারের ছোট থেকে বড় সবার জন্য: স্বাস্থ্যবিধি ও বরিষ্ঠ যত্ন, ঐতিহ্যবাহী রান্না, পারিবারিক চিঠি ও সরকারি আবেদন পত্র, শিশুদের পড়াশোনা ও বিজ্ঞান কুইজ।
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleClearHistory}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-white hover:bg-rose-50 border-2 border-rose-200 text-rose-900 text-xs font-bold transition-all shadow-sm"
              title="নতুন করে শুরু করুন"
            >
              <Trash2 className="w-4 h-4 text-rose-700" />
              <span>নতুন চ্যাট</span>
            </button>
            {onOpenSOS && (
              <button
                onClick={onOpenSOS}
                className="flex items-center gap-1.5 px-4 py-2 rounded-2xl bg-gradient-to-r from-red-600 to-rose-700 text-white text-xs font-black shadow-md hover:scale-105 transition-all"
              >
                <span>🚨 জরুরি SOS</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Quick Category Selector Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
        <button
          onClick={() => setActiveCategory('all')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border-2 ${
            activeCategory === 'all'
              ? 'bg-rose-900 text-white border-rose-900 shadow-md'
              : 'bg-white border-rose-200 text-rose-950 hover:bg-rose-50'
          }`}
        >
          <span>✿ সব বিভাগ</span>
        </button>
        <button
          onClick={() => setActiveCategory('elder_care')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border-2 ${
            activeCategory === 'elder_care'
              ? 'bg-rose-900 text-white border-rose-900 shadow-md'
              : 'bg-white border-rose-200 text-rose-950 hover:bg-rose-50'
          }`}
        >
          <span>👵 বরিষ্ঠ যত্ন ও স্বাস্থ্যবিধি</span>
        </button>
        <button
          onClick={() => setActiveCategory('recipes')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border-2 ${
            activeCategory === 'recipes'
              ? 'bg-rose-900 text-white border-rose-900 shadow-md'
              : 'bg-white border-rose-200 text-rose-950 hover:bg-rose-50'
          }`}
        >
          <span>🍲 বাঙালি রান্না ও রেসিপি</span>
        </button>
        <button
          onClick={() => setActiveCategory('letters')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border-2 ${
            activeCategory === 'letters'
              ? 'bg-rose-900 text-white border-rose-900 shadow-md'
              : 'bg-white border-rose-200 text-rose-950 hover:bg-rose-50'
          }`}
        >
          <span>✉️ পারিবারিক চিঠি ও দরখাস্ত</span>
        </button>
        <button
          onClick={() => setActiveCategory('kids_study')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border-2 ${
            activeCategory === 'kids_study'
              ? 'bg-rose-900 text-white border-rose-900 shadow-md'
              : 'bg-white border-rose-200 text-rose-950 hover:bg-rose-50'
          }`}
        >
          <span>🎒 ছোটদের পড়াশোনা ও গল্প</span>
        </button>
        <button
          onClick={() => setActiveCategory('budget_safety')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border-2 ${
            activeCategory === 'budget_safety'
              ? 'bg-rose-900 text-white border-rose-900 shadow-md'
              : 'bg-white border-rose-200 text-rose-950 hover:bg-rose-50'
          }`}
        >
          <span>💰 বাজেট ও সতর্কতা</span>
        </button>
      </div>

      {/* Preset 1-Click Prompt Chips */}
      <div className="bg-white border-2 border-rose-200 rounded-3xl p-4 sm:p-5 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-black text-rose-950 flex items-center gap-1.5">
            <Lightbulb className="w-4 h-4 text-amber-600" />
            <span>সরাসরি এক-ক্লিকে প্রশ্ন করুন (যেকোনো সদস্যের জন্য উপযোগী):</span>
          </p>
          <span className="text-[11px] text-rose-800 font-bold hidden sm:inline">
            ক্লিক করলেই উত্তর শুরু হবে
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {filteredPresets.map((preset) => (
            <button
              key={preset.id}
              onClick={() => handleSendMessage(preset.prompt)}
              disabled={isLoading}
              className="p-3 rounded-2xl bg-rose-50/60 hover:bg-rose-100/90 border border-rose-200 text-left transition-all hover:scale-[1.01] active:scale-[0.99] group disabled:opacity-50"
            >
              <div className="flex items-start gap-2.5">
                <span className="text-xl shrink-0 group-hover:scale-110 transition-transform">
                  {preset.icon}
                </span>
                <div className="min-w-0">
                  <p className="text-xs font-bold text-rose-950 group-hover:text-rose-900 truncate">
                    {preset.label}
                  </p>
                  <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                    {preset.audience} • {preset.prompt}
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat Stream Container */}
      <div className="bg-white border-2 border-rose-200 rounded-3xl shadow-lg flex flex-col h-[560px] overflow-hidden">
        
        {/* Chat Stream Header */}
        <div className="px-5 py-3.5 bg-rose-50/80 border-b-2 border-rose-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-rose-900 text-white flex items-center justify-center font-black text-sm shadow">
              ✿
            </div>
            <div>
              <h3 className="font-black text-xs sm:text-sm text-rose-950">
                দাস পরিবার এআই কথোপকথন
              </h3>
              <p className="text-[10px] text-slate-500">
                বর্তমান সদস্য: <span className="font-bold text-rose-900">{currentMember.name}</span> ({currentMember.relationship})
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-600">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-medium">অনলাইন সহায়ক</span>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50/40">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            const isSpeaking = speakingId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-[92%] sm:max-w-[85%] ${
                  isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Avatar Icon */}
                <div
                  className={`w-9 h-9 rounded-2xl flex items-center justify-center font-black text-xs shrink-0 shadow-sm border ${
                    isUser
                      ? 'bg-rose-900 text-white border-rose-700'
                      : 'bg-white text-rose-900 border-rose-200 shadow'
                  }`}
                >
                  {isUser ? currentMember.name.charAt(0) : '✿'}
                </div>

                {/* Message Bubble */}
                <div
                  className={`rounded-3xl p-4 sm:p-5 shadow-sm text-xs sm:text-sm leading-relaxed relative group ${
                    isUser
                      ? 'bg-rose-900 text-white rounded-tr-none'
                      : 'bg-white text-slate-800 border-2 border-rose-100 rounded-tl-none shadow-md'
                  }`}
                >
                  {/* Sender Header */}
                  <div className="flex items-center justify-between gap-3 mb-1.5 pb-1 border-b border-rose-200/30 text-[10px] opacity-80">
                    <span className="font-black">
                      {isUser ? currentMember.name : 'দাস পরিবার এআই'}
                    </span>
                    <span>{msg.timestamp}</span>
                  </div>

                  {/* Message Content (Formatted with whitespace) */}
                  <div className="whitespace-pre-wrap font-sans space-y-1">
                    {msg.text}
                  </div>

                  {/* Action Bar for AI replies (Listen, Copy) */}
                  {!isUser && (
                    <div className="mt-3 pt-2.5 border-t border-rose-100 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="text-[10px] text-rose-800 font-semibold">
                        দাস পরিবার ভল্ট গাইড
                      </span>
                      
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleToggleSpeak(msg.id, msg.text)}
                          className={`p-1.5 rounded-lg border transition-all flex items-center gap-1 ${
                            isSpeaking
                              ? 'bg-rose-900 text-white border-rose-900 animate-pulse'
                              : 'bg-rose-50 hover:bg-rose-100 text-rose-900 border-rose-200'
                          }`}
                          title={isSpeaking ? 'থামান' : 'উচ্চস্বরে শুনুন'}
                        >
                          {isSpeaking ? (
                            <>
                              <VolumeX className="w-3.5 h-3.5" />
                              <span className="text-[10px] font-bold">থামুন</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3.5 h-3.5" />
                              <span className="text-[10px] font-bold">শুনুন</span>
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => handleCopyText(msg.id, msg.text)}
                          className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200 transition-all flex items-center gap-1"
                          title="লেখা কপি করুন"
                        >
                          {copiedId === msg.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              <span className="text-[10px] text-emerald-700 font-bold">কপি হয়েছে</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span className="text-[10px] font-bold">কপি</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {/* Typing Indicator */}
          {isLoading && (
            <div className="flex gap-3 max-w-[80%]">
              <div className="w-9 h-9 rounded-2xl bg-white border-2 border-rose-200 text-rose-900 flex items-center justify-center font-black text-xs shrink-0 shadow">
                ✿
              </div>
              <div className="p-4 rounded-3xl rounded-tl-none bg-white border-2 border-rose-100 shadow-md flex items-center gap-2 text-rose-900 text-xs font-bold">
                <RefreshCw className="w-4 h-4 animate-spin text-rose-700" />
                <span>দাস পরিবার এআই চিন্তা করছে ও উত্তর প্রস্তুত করছে...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar Form */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="p-3 sm:p-4 bg-white border-t-2 border-rose-200 flex items-center gap-2"
        >
          <div className="relative flex-1">
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder="যেকোনো প্রশ্ন বাংলায় লিখুন (যেমন: 'সুগার রোগীর উপযোগী প্রাতরাশ' বা 'ছুটির আবেদন')..."
              disabled={isLoading}
              className="w-full pl-4 pr-10 py-3 bg-white border-2 border-rose-200 rounded-2xl text-slate-900 text-xs sm:text-sm focus:outline-none focus:border-rose-700 shadow-inner disabled:opacity-60"
            />
            {inputPrompt && (
              <button
                type="button"
                onClick={() => setInputPrompt('')}
                className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-rose-900 to-red-800 hover:from-rose-800 hover:to-red-700 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 flex items-center gap-2 shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">পাঠান</span>
          </button>
        </form>
      </div>

      {/* Safety Notice Footer */}
      <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-200 text-[11px] text-slate-600 flex items-start gap-2.5">
        <ShieldAlert className="w-4 h-4 text-rose-700 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold text-rose-950">পারিবারিক সুস্থতা ও সুরক্ষা নির্দেশিকা:</p>
          <p className="mt-0.5 leading-relaxed">
            এআই সহায়কের পরামর্শ সাধারণ জ্ঞান ও জীবনধারার জন্য। গুরুতর চিকিৎসাজনিত প্রয়োজনে পারিবারিক চিকিৎসক ডঃ দেবব্রত সেন অথবা নিকটস্থ হাসপাতালে যোগাযোগ করুন। আকস্মিক বিপদে উপরের লাল SOS বাটনে চাপ দিয়ে সবার ফোনে বার্তা পাঠান।
          </p>
        </div>
      </div>

    </div>
  );
};
