import React, { useState } from 'react';
import { X, Lock, Key, Mail, Phone, User, CheckCircle2, ShieldCheck, ArrowRight, UserPlus, Fingerprint, RefreshCw } from 'lucide-react';
import { FamilyMember, Language, UserRole } from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner } from './KolkaMotifs';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  members: FamilyMember[];
  onSelectMember: (member: FamilyMember) => void;
  onAddNewMember: (newMember: FamilyMember) => void;
  currentLang: Language;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  members,
  onSelectMember,
  onAddNewMember,
  currentLang,
}) => {
  const t = getTranslation(currentLang);
  const [activeTab, setActiveTab] = useState<'quick' | 'credentials' | 'google' | 'register'>('quick');

  // Credential form
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isBiometricScanning, setIsBiometricScanning] = useState(false);

  // New member form
  const [newName, setNewName] = useState('');
  const [newRel, setNewRel] = useState<FamilyMember['relationship']>('son');
  const [newRole, setNewRole] = useState<UserRole>('member');
  const [newBlood, setNewBlood] = useState('B+');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newLoginId, setNewLoginId] = useState('');
  const [newPassword, setNewPassword] = useState('das123');
  const [newDob, setNewDob] = useState('1995-01-01');

  if (!isOpen) return null;

  const registeredMembers = members.filter((m) => m.isRegistered !== false);

  const handleCredentialsLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const query = loginId.trim().toLowerCase();
    const found = registeredMembers.find(
      (m) =>
        m.loginId.toLowerCase() === query ||
        m.email.toLowerCase() === query ||
        m.phone.replace(/\D/g, '') === query.replace(/\D/g, '')
    );

    if (!found) {
      setErrorMessage('নিবন্ধিত সদস্য পাওয়া যায়নি। এডমিন আইডি (milon) অথবা নতুন নিবন্ধিত সদস্য আইডি দিয়ে লগইন করুন।');
      return;
    }

    if (password === (found.password || 'das123') || password === (found.pin || '1234') || password === 'das123' || password === '1234') {
      onSelectMember(found);
      onClose();
    } else {
      setErrorMessage('ভুল পাসওয়ার্ড বা পিন। সঠিক পাসওয়ার্ড লিখুন (ডিফল্ট: das123 বা PIN: 1234)');
    }
  };

  const handleGoogleSignIn = () => {
    const headMember = registeredMembers.find((m) => m.role === 'admin') || registeredMembers[0];
    onSelectMember(headMember);
    onClose();
  };

  const handleBiometricModalUnlock = () => {
    setIsBiometricScanning(true);
    setErrorMessage('');
    const query = loginId.trim().toLowerCase();
    const found = registeredMembers.find(
      (m) =>
        m.loginId.toLowerCase() === query ||
        m.email.toLowerCase() === query ||
        m.phone.replace(/\D/g, '') === query.replace(/\D/g, '')
    ) || registeredMembers.find((m) => m.role === 'admin') || registeredMembers[0];

    setTimeout(() => {
      setIsBiometricScanning(false);
      if (found) {
        onSelectMember(found);
        onClose();
      }
    }, 1100);
  };

  const handleCreateMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newLoginId.trim()) {
      setErrorMessage('অনুগ্রহ করে নাম এবং লগইন আইডি দিন।');
      return;
    }

    const birthYear = new Date(newDob).getFullYear();
    const calculatedAge = new Date().getFullYear() - (isNaN(birthYear) ? 1995 : birthYear);
    const newRegId = `DF-REG-${String(registeredMembers.length + 1).padStart(3, '0')}`;

    const created: FamilyMember = {
      id: `member-${Date.now()}`,
      name: newName.trim(),
      relationship: newRel,
      gender: 'other',
      dob: newDob,
      age: calculatedAge,
      phone: newPhone || '+91 98000 00000',
      email: newEmail || `${newLoginId.toLowerCase()}@dasfamily.org`,
      loginId: newLoginId.trim().toLowerCase(),
      password: newPassword || 'das123',
      pin: '1234',
      role: newRole,
      bloodGroup: newBlood,
      allergies: [],
      chronicConditions: [],
      emergencyContactName: 'Milon Das (Family Head)',
      emergencyContactPhone: '+91 98301 23456',
      avatarBg: 'bg-rose-900',
      notes: 'নতুন নিবন্ধিত পারিবারিক সদস্য যুক্ত হয়েছে।',
      isRegistered: true,
      registeredAt: new Date().toISOString().split('T')[0],
      registrationId: newRegId,
    };

    onAddNewMember(created);
    onSelectMember(created);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-lg bg-white border-2 border-rose-300 rounded-3xl shadow-2xl overflow-hidden my-6">
        
        {/* Header with Kolka Watermark */}
        <div className="relative p-5 sm:p-6 bg-gradient-to-r from-rose-900 to-red-800 text-white flex items-center justify-between overflow-hidden">
          <div className="absolute top-0 right-0 pointer-events-none opacity-20">
            <KolkaCorner className="w-28 h-28" color="#ffffff" />
          </div>

          <div className="relative z-10 flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-white/20 text-white shadow">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-white">
                লগইন ও প্রোফাইল নির্বাচন • DAS FAMILY
              </h3>
              <p className="text-xs text-rose-100">
                পারিবারিক তথ্য ও নথিপত্র অ্যাক্সেস করুন
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="relative z-10 p-2 text-rose-200 hover:text-white rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs Bar */}
        <div className="flex border-b-2 border-rose-100 bg-rose-50/50 p-1.5 text-xs font-bold overflow-x-auto gap-1">
          <button
            onClick={() => { setActiveTab('quick'); setErrorMessage(''); }}
            className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl transition-all ${
              activeTab === 'quick' ? 'bg-rose-900 text-white shadow' : 'text-slate-700 hover:bg-rose-100'
            }`}
          >
            সহজ নির্বাচন
          </button>
          <button
            onClick={() => { setActiveTab('credentials'); setErrorMessage(''); }}
            className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl transition-all ${
              activeTab === 'credentials' ? 'bg-rose-900 text-white shadow' : 'text-slate-700 hover:bg-rose-100'
            }`}
          >
            আইডি ও পাসওয়ার্ড
          </button>
          <button
            onClick={() => { setActiveTab('google'); setErrorMessage(''); }}
            className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl transition-all ${
              activeTab === 'google' ? 'bg-rose-900 text-white shadow' : 'text-slate-700 hover:bg-rose-100'
            }`}
          >
            গুগল সিঙ্ক
          </button>
          <button
            onClick={() => { setActiveTab('register'); setErrorMessage(''); }}
            className={`flex-1 min-w-[90px] py-2 px-2.5 rounded-xl transition-all ${
              activeTab === 'register' ? 'bg-rose-900 text-white shadow' : 'text-slate-700 hover:bg-rose-100'
            }`}
          >
            + নতুন সদস্য
          </button>
        </div>

        {errorMessage && (
          <div className="mx-5 mt-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs font-bold">
            ⚠️ {errorMessage}
          </div>
        )}

        {/* Tab 1: Quick Member Switcher */}
        {activeTab === 'quick' && (
          <div className="p-5 space-y-3">
            <p className="text-xs text-slate-600">
              ভল্ট আনলক করতে আপনার নামের প্রোফাইলটি বেছে নিন:
            </p>
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {registeredMembers.map((member) => (
                <button
                  key={member.id}
                  onClick={() => {
                    onSelectMember(member);
                    onClose();
                  }}
                  className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white hover:bg-rose-50 border-2 border-rose-100 hover:border-rose-300 transition-all text-left group shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-rose-900 text-white flex items-center justify-center font-black shadow">
                      {member.name.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-black text-sm text-rose-950 group-hover:text-rose-700 transition-colors flex items-center gap-2">
                        {member.name}
                        {member.role === 'admin' && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-900 font-bold border border-rose-200">
                            অ্যাডমিন
                          </span>
                        )}
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-900 font-bold border border-emerald-200">
                          নিবন্ধিত
                        </span>
                      </h4>
                      <p className="text-xs text-slate-500 capitalize">
                        {member.relationship} • রেজি: <span className="font-mono text-rose-900 font-semibold">{member.registrationId || 'DF-REG-001'}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-rose-900 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-200">
                      {member.bloodGroup}
                    </span>
                    <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-rose-900 group-hover:translate-x-1 transition-all" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: ID & Password */}
        {activeTab === 'credentials' && (
          <form onSubmit={handleCredentialsLogin} className="p-5 space-y-4">
            <div>
              <label className="block text-xs font-bold text-rose-950 mb-1.5">
                লগইন আইডি / ফোন / ইমেইল
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-3 w-4 h-4 text-rose-400" />
                <input
                  type="text"
                  required
                  value={loginId}
                  onChange={(e) => setLoginId(e.target.value)}
                  placeholder="যেমন: milon অথবা নিবন্ধিত সদস্য আইডি"
                  className="w-full pl-10 pr-4 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-rose-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-rose-950 mb-1.5">
                পাসওয়ার্ড বা ৪-সংখ্যার পিন (PIN)
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3 w-4 h-4 text-rose-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="পাসওয়ার্ড লিখুন (ডিফল্ট: das123 বা পিন: 1234)"
                  className="w-full pl-10 pr-4 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-rose-600"
                />
              </div>
              <p className="mt-1 text-[11px] text-slate-500">
                ডেমো লগইন: আইডি <code className="text-rose-900 font-bold">milon</code>, পাসওয়ার্ড <code className="text-rose-900 font-bold">das123</code> বা পিন <code className="text-rose-900 font-bold">1234</code>
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-sm shadow-md transition-all active:scale-[0.98]"
            >
              দাস পরিবার ভল্টে প্রবেশ করুন
            </button>

            <button
              type="button"
              disabled={isBiometricScanning}
              onClick={handleBiometricModalUnlock}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs border border-rose-300/40 shadow flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
            >
              {isBiometricScanning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-amber-300" />
                  <span>বায়োমেট্রিক স্ক্যান হচ্ছে...</span>
                </>
              ) : (
                <>
                  <Fingerprint className="w-4 h-4 text-amber-300 animate-pulse" />
                  <span>বায়োমেট্রিক এক-ট্যাপ প্রবেশ (Fingerprint / Face ID)</span>
                </>
              )}
            </button>
          </form>
        )}

        {/* Tab 3: Gmail Sync */}
        {activeTab === 'google' && (
          <div className="p-5 text-center space-y-4">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center">
              <Mail className="w-7 h-7 text-rose-800" />
            </div>
            <div>
              <h4 className="font-black text-base text-rose-950">
                গুগল অ্যাকাউন্ট ও জিমেইল সিঙ্ক্রোনাইজেশন
              </h4>
              <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto">
                গুগল অ্যাকাউন্টে লগইন করে স্বয়ংক্রিয়ভাবে সব ফাইল ও রিপোর্ট গুগল ড্রাইভে ব্যাকআপ রাখুন।
              </p>
            </div>

            <div className="bg-rose-50/60 p-3.5 rounded-2xl border border-rose-200 text-left text-xs space-y-1.5">
              <p className="text-slate-800 font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                স্বয়ংক্রিয় ক্লাউড গুগল ড্রাইভ ব্যাকআপ
              </p>
              <p className="text-slate-800 font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                নিবেদিত &quot;DAS FAMILY VAULT&quot; ফোল্ডার
              </p>
              <p className="text-slate-800 font-semibold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                সিঙ্ক অ্যাকাউন্ট: <span className="font-mono text-rose-900 font-bold">milon8727@gmail.com</span>
              </p>
            </div>

            <button
              onClick={handleGoogleSignIn}
              className="w-full py-3 px-4 rounded-xl bg-white hover:bg-slate-50 border-2 border-slate-200 text-slate-900 font-bold text-sm shadow-md flex items-center justify-center gap-3 transition-all active:scale-[0.98]"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              গুগল অ্যাকাউন্টে প্রবেশ করুন
            </button>
          </div>
        )}

        {/* Tab 4: Register New Member */}
        {activeTab === 'register' && (
          <form onSubmit={handleCreateMember} className="p-5 space-y-3 max-h-80 overflow-y-auto">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  পুরো নাম *
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="যেমন প্রিয়া দাস"
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  সম্পর্ক
                </label>
                <select
                  value={newRel}
                  onChange={(e) => setNewRel(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                >
                  <option value="spouse">স্ত্রী / স্বামী</option>
                  <option value="son">ছেলে</option>
                  <option value="daughter">মেয়ে</option>
                  <option value="father">বাবা</option>
                  <option value="mother">মা</option>
                  <option value="grandfather">দাদু</option>
                  <option value="grandmother">দিদিমা</option>
                  <option value="other">অন্য আত্মীয়</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  রক্তের গ্রুপ
                </label>
                <select
                  value={newBlood}
                  onChange={(e) => setNewBlood(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                >
                  <option value="A+">A+</option>
                  <option value="A-">A-</option>
                  <option value="B+">B+</option>
                  <option value="B-">B-</option>
                  <option value="O+">O+</option>
                  <option value="O-">O-</option>
                  <option value="AB+">AB+</option>
                  <option value="AB-">AB-</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  জন্ম তারিখ
                </label>
                <input
                  type="date"
                  value={newDob}
                  onChange={(e) => setNewDob(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  লগইন আইডি *
                </label>
                <input
                  type="text"
                  required
                  value={newLoginId}
                  onChange={(e) => setNewLoginId(e.target.value)}
                  placeholder="যেমন priya"
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  পাসওয়ার্ড *
                </label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="পাসওয়ার্ড"
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  মোবাইল নম্বর
                </label>
                <input
                  type="tel"
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="+91 98300..."
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-rose-950 mb-1">
                  অ্যাক্সেস রোল
                </label>
                <select
                  value={newRole}
                  onChange={(e) => setNewRole(e.target.value as UserRole)}
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                >
                  <option value="member">পারিবারিক সদস্য</option>
                  <option value="child_or_elder">শিশু / প্রবীণ</option>
                  <option value="admin">সহ-অ্যাডমিন</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow-md transition-all"
            >
              দাস পরিবারে সদস্য যুক্ত করুন
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
