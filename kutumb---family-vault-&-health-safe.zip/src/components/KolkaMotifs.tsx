import React from 'react';

/**
 * Traditional Bengali Kolka (আলপনা / কলকা) decorative SVGs
 * Deep crimson red (#991b1b, #881337) with ivory white and auspicious golden touches.
 */

export const KolkaCorner: React.FC<{ className?: string; color?: string }> = ({
  className = 'w-16 h-16',
  color = '#991b1b',
}) => (
  <svg
    viewBox="0 0 100 100"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    {/* Traditional Bengali Paisley / Kolka Flourish */}
    <path
      d="M10 90 C 10 40, 45 10, 85 10 C 95 10, 95 25, 80 30 C 60 38, 40 55, 38 75 C 36 88, 22 92, 10 90 Z"
      fill={color}
      fillOpacity="0.15"
      stroke={color}
      strokeWidth="2.5"
      strokeLinejoin="round"
    />
    <path
      d="M25 85 C 25 50, 48 30, 75 22 C 82 20, 82 28, 72 32 C 55 40, 42 55, 40 70"
      stroke={color}
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeDasharray="2 3"
    />
    {/* Kolka drops / Bindu pearls */}
    <circle cx="20" cy="80" r="3" fill={color} />
    <circle cx="30" cy="65" r="3.5" fill={color} />
    <circle cx="45" cy="50" r="3" fill={color} />
    <circle cx="62" cy="38" r="2.5" fill={color} />
    <circle cx="80" cy="25" r="3" fill={color} />
    {/* Inner decorative petal */}
    <path
      d="M20 88 Q 30 75 42 78 Q 35 88 20 88 Z"
      fill={color}
      fillOpacity="0.4"
    />
  </svg>
);

export const KolkaDivider: React.FC<{ className?: string; color?: string }> = ({
  className = 'w-full h-8',
  color = '#991b1b',
}) => (
  <div className={`flex items-center justify-center gap-3 overflow-hidden ${className}`}>
    <div className="h-[1.5px] flex-1 bg-gradient-to-r from-transparent via-rose-300 to-rose-700" />
    <svg width="120" height="24" viewBox="0 0 120 24" fill="none" className="shrink-0">
      <path
        d="M60 2 C 54 10, 42 12, 35 8 C 28 4, 20 12, 10 12"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M60 2 C 66 10, 78 12, 85 8 C 92 4, 100 12, 110 12"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      {/* Central Kolka Paisley Heart */}
      <circle cx="60" cy="12" r="5" fill={color} />
      <circle cx="60" cy="12" r="2.5" fill="#ffffff" />
      <circle cx="50" cy="12" r="2" fill={color} />
      <circle cx="70" cy="12" r="2" fill={color} />
      <circle cx="40" cy="10" r="1.5" fill={color} />
      <circle cx="80" cy="10" r="1.5" fill={color} />
    </svg>
    <div className="h-[1.5px] flex-1 bg-gradient-to-l from-transparent via-rose-300 to-rose-700" />
  </div>
);

export const KolkaBadge: React.FC<{ text: string; className?: string }> = ({
  text,
  className = '',
}) => (
  <span
    className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold tracking-wide border shadow-sm ${className}`}
    style={{
      backgroundColor: '#fff1f2',
      color: '#9f1239',
      borderColor: '#fecdd3',
    }}
  >
    <svg width="12" height="12" viewBox="0 0 24 24" fill="#9f1239">
      <path d="M12 2 C8 7 4 12 4 16 A 8 8 0 0 0 20 16 C 20 12 16 7 12 2 Z" />
    </svg>
    {text}
  </span>
);
