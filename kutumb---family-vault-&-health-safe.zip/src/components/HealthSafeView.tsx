import React, { useState } from 'react';
import { 
  Heart, 
  Activity, 
  FileSpreadsheet, 
  Plus, 
  Calendar, 
  Clock, 
  User, 
  Stethoscope, 
  AlertCircle, 
  Trash2, 
  CheckCircle2, 
  FileText,
  Upload,
  Download,
  AlertTriangle,
  Phone,
  ShieldAlert,
  Flame,
  Radio,
  X
} from 'lucide-react';
import { 
  VaultState, 
  FamilyMember, 
  Language, 
  VitalLog, 
  MedicalRecord 
} from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner, KolkaDivider } from './KolkaMotifs';

interface HealthSafeViewProps {
  state: VaultState;
  currentLang: Language;
  onAddVitalLog: (log: VitalLog) => void;
  onDeleteVitalLog: (id: string) => void;
  onAddMedicalRecord: (rec: MedicalRecord) => void;
  onDeleteMedicalRecord: (id: string) => void;
  onOpenSOS: () => void;
}

export const HealthSafeView: React.FC<HealthSafeViewProps> = ({
  state,
  currentLang,
  onAddVitalLog,
  onDeleteVitalLog,
  onAddMedicalRecord,
  onDeleteMedicalRecord,
  onOpenSOS,
}) => {
  const t = getTranslation(currentLang);
  const [selectedMemberId, setSelectedMemberId] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'vitals' | 'records' | 'emergency'>('vitals');

  // Modal controls
  const [showVitalModal, setShowVitalModal] = useState(false);
  const [showRecordModal, setShowRecordModal] = useState(false);

  // Vital form state
  const [vitalMemberId, setVitalMemberId] = useState(state.members[0]?.id || '');
  const [vitalDate, setVitalDate] = useState(new Date().toISOString().split('T')[0]);
  const [vitalTime, setVitalTime] = useState('08:00 AM');
  const [bpSys, setBpSys] = useState<number | ''>('');
  const [bpDia, setBpDia] = useState<number | ''>('');
  const [sugar, setSugar] = useState<number | ''>('');
  const [sugarType, setSugarType] = useState<VitalLog['bloodSugarType']>('fasting');
  const [pulse, setPulse] = useState<number | ''>('');
  const [spo2, setSpo2] = useState<number | ''>('');
  const [weight, setWeight] = useState<number | ''>('');
  const [vitalNotes, setVitalNotes] = useState('');

  // Medical Record form state
  const [recMemberId, setRecMemberId] = useState(state.members[0]?.id || '');
  const [recTitle, setRecTitle] = useState('');
  const [recType, setRecType] = useState<MedicalRecord['type']>('prescription');
  const [recDate, setRecDate] = useState(new Date().toISOString().split('T')[0]);
  const [recDoctor, setRecDoctor] = useState('');
  const [recNotes, setRecNotes] = useState('');
  const [recFileName, setRecFileName] = useState('');

  // Filters
  const filteredVitals = state.vitals.filter(
    (v) => selectedMemberId === 'all' || v.memberId === selectedMemberId
  );
  const filteredRecords = state.medicalRecords.filter(
    (r) => selectedMemberId === 'all' || r.memberId === selectedMemberId
  );

  const handleSaveVital = (e: React.FormEvent) => {
    e.preventDefault();
    const newVital: VitalLog = {
      id: `vit-${Date.now()}`,
      memberId: vitalMemberId,
      date: vitalDate,
      time: vitalTime,
      bpSystolic: bpSys ? Number(bpSys) : undefined,
      bpDiastolic: bpDia ? Number(bpDia) : undefined,
      bloodSugar: sugar ? Number(sugar) : undefined,
      bloodSugarType: sugarType,
      pulse: pulse ? Number(pulse) : undefined,
      spo2: spo2 ? Number(spo2) : undefined,
      weight: weight ? Number(weight) : undefined,
      notes: vitalNotes,
    };
    onAddVitalLog(newVital);
    setShowVitalModal(false);
    setBpSys('');
    setBpDia('');
    setSugar('');
    setVitalNotes('');
  };

  const handleSaveRecord = (e: React.FormEvent) => {
    e.preventDefault();
    if (!recTitle.trim()) return;
    const newRec: MedicalRecord = {
      id: `rec-${Date.now()}`,
      memberId: recMemberId,
      title: recTitle.trim(),
      type: recType,
      date: recDate,
      doctorOrHospital: recDoctor || 'Apollo / AMRI Clinic',
      diagnosisOrNotes: recNotes,
      fileName: recFileName || `${recTitle.replace(/\s+/g, '_')}.pdf`,
      fileType: 'application/pdf',
    };
    onAddMedicalRecord(newRec);
    setShowRecordModal(false);
    setRecTitle('');
    setRecNotes('');
    setRecDoctor('');
    setRecFileName('');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner with Kolka Ornamentation and Emergency Broadcast Trigger */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-white border-2 border-rose-200 p-6 rounded-3xl shadow-lg relative overflow-hidden">
        {/* Kolka Corner Filigree Top-Right */}
        <div className="absolute top-0 right-0 pointer-events-none opacity-40">
          <KolkaCorner className="w-32 h-32" color="#991b1b" />
        </div>

        <div className="relative z-10 space-y-2 max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-900 text-xs font-black">
            <span className="text-rose-700">✿</span> স্বাস্থ্য সুরক্ষা ও মেডিকেল ভল্ট
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-rose-950">
            পরিবারের স্বাস্থ্য ডাটা ও রিপোর্ট (DAS HEALTH SAFE)
          </h2>
          <p className="text-xs sm:text-sm text-slate-700">
            রক্তচাপ, সুগার পর্যবেক্ষণ, ডাক্তারের প্রেসক্রিপশন ও জরুরি চিকিৎসা নথিপত্র সম্পূর্ণ সুরক্ষিত।
          </p>
        </div>

        {/* Emergency Alert Button in Top Banner */}
        <div className="relative z-10 flex flex-wrap items-center gap-3">
          <button
            onClick={onOpenSOS}
            className="flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-gradient-to-r from-red-600 via-rose-700 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-xs sm:text-sm shadow-xl shadow-red-700/30 ring-2 ring-red-400 animate-pulse transition-all active:scale-95"
            title="প্রেস করলে পরিবারের সবার ফোনে একযোগে অ্যালার্ট ও সাইরেন বাজবে"
          >
            <Flame className="w-5 h-5 text-amber-200 animate-bounce" />
            🚨 সবার ফোনে অ্যালার্ট পাঠান
          </button>
        </div>
      </div>

      <KolkaDivider />

      {/* Member Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 max-w-full no-scrollbar">
        <span className="text-xs font-bold text-rose-950 shrink-0">ফিল্টার:</span>
        <button
          onClick={() => setSelectedMemberId('all')}
          className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            selectedMemberId === 'all'
              ? 'bg-rose-900 text-white shadow-md'
              : 'bg-white border border-rose-200 text-slate-700 hover:bg-rose-50'
          }`}
        >
          পরিবারের সবাই ({state.members.length})
        </button>
        {state.members.map((m) => (
          <button
            key={m.id}
            onClick={() => setSelectedMemberId(m.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
              selectedMemberId === m.id
                ? 'bg-rose-900 text-white shadow-md'
                : 'bg-white border border-rose-200 text-slate-700 hover:bg-rose-50'
            }`}
          >
            {m.name.split(' ')[0]} ({m.bloodGroup})
          </button>
        ))}
      </div>

      {/* Tabs navigation in White & Deep Red */}
      <div className="flex items-center justify-between border-b-2 border-rose-100 pb-3 flex-wrap gap-3">
        <div className="flex items-center gap-1.5 bg-white p-1 rounded-2xl border-2 border-rose-200 shadow-sm">
          <button
            onClick={() => setActiveTab('vitals')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'vitals'
                ? 'bg-rose-900 text-white shadow-md'
                : 'text-slate-700 hover:bg-rose-50'
            }`}
          >
            <Activity className="w-4 h-4" />
            রক্তচাপ ও সুগার লগ ({filteredVitals.length})
          </button>

          <button
            onClick={() => setActiveTab('records')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'records'
                ? 'bg-rose-900 text-white shadow-md'
                : 'text-slate-700 hover:bg-rose-50'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            প্রেসক্রিপশন ও রিপোর্ট ({filteredRecords.length})
          </button>

          <button
            onClick={() => setActiveTab('emergency')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'emergency'
                ? 'bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-md'
                : 'text-slate-700 hover:bg-rose-50'
            }`}
          >
            <ShieldAlert className="w-4 h-4 text-red-600" />
            জরুরি ডসিয়ার ও যোগাযোগ
          </button>
        </div>

        {/* Primary Tab Add Button */}
        <div>
          {activeTab === 'vitals' && (
            <button
              onClick={() => setShowVitalModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow-md transition-all active:scale-95"
            >
              <Plus className="w-4 h-4" />
              নতুন ভাইটাল ও সুগার যুক্ত করুন
            </button>
          )}
          {activeTab === 'records' && (
            <button
              onClick={() => setShowRecordModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow-md transition-all active:scale-95"
            >
              <Upload className="w-4 h-4" />
              প্রেসক্রিপশন ফাইল আপলোড
            </button>
          )}
        </div>
      </div>

      {/* TAB 1: VITALS LOG TABLE (Pure White Background with Rose/Crimson Borders) */}
      {activeTab === 'vitals' && (
        <div className="bg-white border-2 border-rose-200 rounded-3xl overflow-hidden shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-rose-50/80 text-rose-950 font-bold border-b-2 border-rose-200">
                <tr>
                  <th className="p-4">সদস্যের নাম</th>
                  <th className="p-4">তারিখ ও সময়</th>
                  <th className="p-4">রক্তচাপ (BP)</th>
                  <th className="p-4">ব্লাড সুগার</th>
                  <th className="p-4">পালস রেট</th>
                  <th className="p-4">ওজন ও SpO2</th>
                  <th className="p-4">নোট</th>
                  <th className="p-4 text-right">মুছুন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-rose-100">
                {filteredVitals.map((log) => {
                  const member = state.members.find((m) => m.id === log.memberId);
                  const isBpNormal =
                    log.bpSystolic && log.bpSystolic <= 125 && log.bpDiastolic && log.bpDiastolic <= 85;

                  return (
                    <tr key={log.id} className="hover:bg-rose-50/50 transition-colors">
                      <td className="p-4 font-bold text-rose-950 whitespace-nowrap">
                        {member?.name || 'Member'}
                      </td>
                      <td className="p-4 text-slate-700 whitespace-nowrap">
                        {log.date} {log.time && <span className="text-slate-500 font-mono">({log.time})</span>}
                      </td>
                      <td className="p-4">
                        {log.bpSystolic ? (
                          <span
                            className={`inline-flex items-center gap-1 font-mono font-bold px-2 py-0.5 rounded-lg border ${
                              isBpNormal
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                : 'bg-rose-50 text-rose-900 border-rose-300'
                            }`}
                          >
                            {log.bpSystolic}/{log.bpDiastolic} mmHg
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="p-4">
                        {log.bloodSugar ? (
                          <span className="font-mono font-bold text-amber-900 bg-amber-50 px-2 py-0.5 rounded-lg border border-amber-200">
                            {log.bloodSugar} mg/dL{' '}
                            <span className="text-[10px] text-amber-700 font-normal">
                              ({log.bloodSugarType})
                            </span>
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="p-4 text-rose-900 font-mono font-semibold">
                        {log.pulse ? `${log.pulse} bpm` : '-'}
                      </td>
                      <td className="p-4 text-slate-700 font-mono">
                        {log.weight ? `${log.weight} kg` : ''} {log.spo2 ? `• ${log.spo2}% SpO2` : ''}
                      </td>
                      <td className="p-4 text-slate-600 max-w-xs truncate">
                        {log.notes || '-'}
                      </td>
                      <td className="p-4 text-right">
                        <button
                          onClick={() => onDeleteVitalLog(log.id)}
                          className="text-slate-400 hover:text-red-700 p-1 transition-colors"
                          title="Delete entry"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: MEDICAL RECORDS & PRESCRIPTIONS (White Cards with Rose Accents) */}
      {activeTab === 'records' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredRecords.map((rec) => {
            const member = state.members.find((m) => m.id === rec.memberId);
            return (
              <div
                key={rec.id}
                className="bg-white border-2 border-rose-100 hover:border-rose-300 rounded-3xl p-5 shadow-lg flex flex-col justify-between transition-all"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-full bg-rose-50 text-rose-900 border border-rose-200">
                      {rec.type.replace('_', ' ')}
                    </span>
                    <span className="text-xs text-rose-900 font-mono font-semibold">{rec.date}</span>
                  </div>

                  <h4 className="font-extrabold text-base text-rose-950 mt-3">
                    {rec.title}
                  </h4>
                  <p className="text-xs text-slate-600 mt-0.5">
                    সদস্য: <span className="font-bold text-rose-900">{member?.name}</span>
                  </p>

                  <div className="mt-3 bg-rose-50/50 p-3 rounded-2xl border border-rose-200/80 text-xs space-y-1">
                    <p className="text-slate-700">
                      <span className="text-slate-500 font-medium">ডাক্তার / হাসপাতাল:</span> {rec.doctorOrHospital}
                    </p>
                    <p className="text-slate-700">
                      <span className="text-slate-500 font-medium">রোগ নির্ণয় / নোট:</span> {rec.diagnosisOrNotes}
                    </p>
                    <p className="text-rose-900 font-mono text-[11px] truncate flex items-center gap-1 pt-1 font-semibold">
                      <FileText className="w-3.5 h-3.5 shrink-0" />
                      {rec.fileName}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-rose-100 flex items-center justify-between">
                  <button
                    onClick={() => alert(`ডাউনলোড হচ্ছে: ${rec.fileName}`)}
                    className="text-xs font-bold text-rose-900 hover:text-rose-700 flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    ফাইল ডাউনলোড
                  </button>

                  <button
                    onClick={() => {
                      if (confirm('এই প্রেসক্রিপশন রেকর্ডটি মুছে ফেলবেন?')) {
                        onDeleteMedicalRecord(rec.id);
                      }
                    }}
                    className="text-slate-400 hover:text-red-700 p-1 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 3: EMERGENCY DOSSIER & DIRECT ALERT */}
      {activeTab === 'emergency' && (
        <div className="space-y-5">
          {/* Emergency Alert Bar with Kolka Accents */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-rose-900 via-red-900 to-rose-950 text-white border-2 border-rose-700 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-5 relative overflow-hidden">
            <div className="absolute top-0 right-0 pointer-events-none opacity-20">
              <KolkaCorner className="w-36 h-36" color="#ffffff" />
            </div>

            <div className="space-y-1 relative z-10 text-center sm:text-left">
              <h3 className="font-black text-lg text-white flex items-center gap-2 justify-center sm:justify-start">
                <Flame className="w-5 h-5 text-amber-300" />
                জরুরি এসওএস অ্যালার্ট ব্রডকাস্ট সিস্টেম
              </h3>
              <p className="text-xs text-rose-100 max-w-xl">
                একটি ক্লিকে পরিবারের সব সদস্যের ফোনে একযোগে লাইভ জিপিএস লোকেশন ও সাইরেন অ্যালার্ট সংকেত পাঠানো হয়।
              </p>
            </div>
            <button
              onClick={onOpenSOS}
              className="relative z-10 px-6 py-3.5 rounded-2xl bg-white hover:bg-rose-50 text-rose-950 font-black text-sm shadow-xl active:scale-95 transition-all whitespace-nowrap"
            >
              🚨 সবার ফোনে অ্যালার্ট পাঠান
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {state.members.map((m) => (
              <div key={m.id} className="p-5 rounded-3xl bg-white border-2 border-rose-100 hover:border-rose-300 shadow-md space-y-3 text-xs transition-all">
                <div className="flex items-center justify-between pb-2 border-b border-rose-100">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-rose-900 text-white flex items-center justify-center text-sm font-black shadow">
                      {m.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-black text-rose-950 text-sm">{m.name}</p>
                      <p className="text-slate-500 capitalize">{m.relationship} • {m.phone}</p>
                    </div>
                  </div>
                  <span className="font-black text-sm text-rose-900 bg-rose-50 px-3 py-1 rounded-xl border border-rose-200">
                    🩸 {m.bloodGroup}
                  </span>
                </div>

                <div className="space-y-1.5 pt-1">
                  <p className="text-slate-700">
                    <span className="text-slate-500 font-semibold">অ্যালার্জি:</span>{' '}
                    <span className="text-rose-800 font-bold">{m.allergies.join(', ') || 'কোনো অ্যালার্জি নেই'}</span>
                  </p>
                  <p className="text-slate-700">
                    <span className="text-slate-500 font-semibold">দীর্ঘস্থায়ী অবস্থা:</span>{' '}
                    <span className="text-amber-800 font-bold">{m.chronicConditions.join(', ') || 'সম্পূর্ণ সুস্থ'}</span>
                  </p>
                  <div className="flex items-center justify-between pt-2">
                    <span className="text-slate-600 font-medium">জরুরি অভিভাবক: {m.emergencyContactName}</span>
                    <a
                      href={`tel:${m.emergencyContactPhone.replace(/\s+/g, '')}`}
                      className="px-3 py-1.5 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold shadow-sm transition-all"
                    >
                      সরাসরি কল
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Record Vitals Modal in White and Deep Red */}
      {showVitalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white border-2 border-rose-300 rounded-3xl p-6 shadow-2xl space-y-4 my-6">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100">
              <h3 className="font-black text-lg text-rose-950">স্বাস্থ্য ভাইটাল ও সুগার রেকর্ড যুক্ত করুন</h3>
              <button onClick={() => setShowVitalModal(false)} className="p-1 rounded-full hover:bg-rose-100 text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveVital} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-rose-950 mb-1">পরিবারের সদস্য</label>
                <select
                  value={vitalMemberId}
                  onChange={(e) => setVitalMemberId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                >
                  {state.members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.relationship})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">তারিখ</label>
                  <input
                    type="date"
                    value={vitalDate}
                    onChange={(e) => setVitalDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">সময়</label>
                  <input
                    type="text"
                    value={vitalTime}
                    onChange={(e) => setVitalTime(e.target.value)}
                    placeholder="যেমন 08:30 AM"
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">BP সিস্টোলিক (High)</label>
                  <input
                    type="number"
                    value={bpSys}
                    onChange={(e) => setBpSys(e.target.value ? Number(e.target.value) : '')}
                    placeholder="যেমন 120"
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">BP ডায়াস্টোলিক (Low)</label>
                  <input
                    type="number"
                    value={bpDia}
                    onChange={(e) => setBpDia(e.target.value ? Number(e.target.value) : '')}
                    placeholder="যেমন 80"
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">ব্লাড সুগার (mg/dL)</label>
                  <input
                    type="number"
                    value={sugar}
                    onChange={(e) => setSugar(e.target.value ? Number(e.target.value) : '')}
                    placeholder="যেমন 110"
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">সুগারের ধরন</label>
                  <select
                    value={sugarType}
                    onChange={(e) => setSugarType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  >
                    <option value="fasting">ফাস্টিং (খাবার পূর্বে)</option>
                    <option value="post_prandial">পোস্ট-প্র্যান্ডিয়াল (খাওয়ার ২ ঘণ্টা পর)</option>
                    <option value="random">র‍্যান্ডম (যেকোনো সময়)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">পালস (bpm)</label>
                  <input
                    type="number"
                    value={pulse}
                    onChange={(e) => setPulse(e.target.value ? Number(e.target.value) : '')}
                    placeholder="72"
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">SpO2 (%)</label>
                  <input
                    type="number"
                    value={spo2}
                    onChange={(e) => setSpo2(e.target.value ? Number(e.target.value) : '')}
                    placeholder="98"
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">ওজন (kg)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={weight}
                    onChange={(e) => setWeight(e.target.value ? Number(e.target.value) : '')}
                    placeholder="70"
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-rose-950 mb-1">নোট / মন্তব্য</label>
                <input
                  type="text"
                  value={vitalNotes}
                  onChange={(e) => setVitalNotes(e.target.value)}
                  placeholder="যেমন সকালের হাঁটার পর"
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-rose-100">
                <button
                  type="button"
                  onClick={() => setShowVitalModal(false)}
                  className="px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-950 font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold shadow-md"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upload Medical Record Modal in White and Deep Red */}
      {showRecordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white border-2 border-rose-300 rounded-3xl p-6 shadow-2xl space-y-4 my-6">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100">
              <h3 className="font-black text-lg text-rose-950">নতুন প্রেসক্রিপশন ও রিপোর্ট আপলোড</h3>
              <button onClick={() => setShowRecordModal(false)} className="p-1 rounded-full hover:bg-rose-100 text-slate-500">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveRecord} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-rose-950 mb-1">পরিবারের সদস্য</label>
                <select
                  value={recMemberId}
                  onChange={(e) => setRecMemberId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                >
                  {state.members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.relationship})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-rose-950 mb-1">ফাইলের শিরোনাম</label>
                <input
                  type="text"
                  required
                  value={recTitle}
                  onChange={(e) => setRecTitle(e.target.value)}
                  placeholder="যেমন ডায়াবেটিস ফলোআপ প্রেসক্রিপশন"
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">নথির ধরন</label>
                  <select
                    value={recType}
                    onChange={(e) => setRecType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  >
                    <option value="prescription">প্রেসক্রিপশন</option>
                    <option value="lab_report">ল্যাব রিপোর্ট</option>
                    <option value="discharge_summary">হাসপাতাল ডিসচার্জ সামারি</option>
                    <option value="vaccination">টিকা কার্ড (Vaccination)</option>
                    <option value="other">অন্যান্য</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">তারিখ</label>
                  <input
                    type="date"
                    value={recDate}
                    onChange={(e) => setRecDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-rose-950 mb-1">ডাক্তার / হাসপাতাল</label>
                <input
                  type="text"
                  value={recDoctor}
                  onChange={(e) => setRecDoctor(e.target.value)}
                  placeholder="যেমন ডা. অম্লান ব্যানার্জী (কার্ডিওলজিস্ট)"
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block font-bold text-rose-950 mb-1">নোট বা রোগ নির্ণয়</label>
                <textarea
                  rows={2}
                  value={recNotes}
                  onChange={(e) => setRecNotes(e.target.value)}
                  placeholder="যেমন ৩ মাস পর আবার রক্ত পরীক্ষা করতে হবে"
                  className="w-full px-3 py-2 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block font-bold text-rose-950 mb-1">ফাইল সংযুক্তি (PDF / ছবি)</label>
                <input
                  type="file"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      setRecFileName(e.target.files[0].name);
                    }
                  }}
                  className="w-full text-xs text-slate-700 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-rose-900 file:text-white hover:file:bg-rose-800"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-rose-100">
                <button
                  type="button"
                  onClick={() => setShowRecordModal(false)}
                  className="px-4 py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-950 font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold shadow-md"
                >
                  আপলোড সম্পন্ন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
