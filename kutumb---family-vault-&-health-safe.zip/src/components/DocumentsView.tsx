import React, { useState } from 'react';
import { 
  FileText, 
  Lock, 
  Unlock, 
  Search, 
  Plus, 
  Filter, 
  ShieldCheck, 
  AlertCircle, 
  Download, 
  Eye, 
  Trash2, 
  Calendar, 
  Tag, 
  ExternalLink,
  CheckCircle2,
  FileCheck
} from 'lucide-react';
import { 
  DocumentItem, 
  DocumentCategory, 
  FamilyMember, 
  Language, 
  VaultState 
} from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner, KolkaDivider } from './KolkaMotifs';

interface DocumentsViewProps {
  state: VaultState;
  currentMember: FamilyMember;
  currentLang: Language;
  onAddDocument: (doc: DocumentItem) => void;
  onDeleteDocument: (id: string) => void;
  onToggleLock: (id: string) => void;
}

export const DocumentsView: React.FC<DocumentsViewProps> = ({
  state,
  currentMember,
  currentLang,
  onAddDocument,
  onDeleteDocument,
  onToggleLock,
}) => {
  const t = getTranslation(currentLang);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedMember, setSelectedMember] = useState<string>('all');

  // Preview & Pin unlock modal
  const [viewingDoc, setViewingDoc] = useState<DocumentItem | null>(null);
  const [unlockingDocId, setUnlockingDocId] = useState<string | null>(null);
  const [pinInput, setPinInput] = useState('');
  const [unlockedDocIds, setUnlockedDocIds] = useState<Set<string>>(new Set());
  const [pinError, setPinError] = useState('');

  // Add document modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<DocumentCategory>('identity');
  const [newMemberId, setNewMemberId] = useState('all');
  const [newDocNum, setNewDocNum] = useState('');
  const [newIssueDate, setNewIssueDate] = useState('');
  const [newExpiryDate, setNewExpiryDate] = useState('');
  const [newIsLocked, setNewIsLocked] = useState(false);
  const [newTags, setNewTags] = useState('');
  const [newNotes, setNewNotes] = useState('');
  const [newFileName, setNewFileName] = useState('');
  const [newFileSize, setNewFileSize] = useState('');
  const [newFileData, setNewFileData] = useState<string | undefined>(undefined);

  const categories: { id: string; label: string }[] = [
    { id: 'all', label: 'সব নথিপত্র' },
    { id: 'identity', label: 'আইডি কার্ড (আধার / ভোটার / পাসপোর্ট)' },
    { id: 'insurance', label: 'বীমা পলিসি (স্বাস্থ্য ও জীবন)' },
    { id: 'property', label: 'জায়গা-জমির দলিল' },
    { id: 'financial', label: 'ব্যাংক ও আর্থিক নথি' },
    { id: 'vehicle', label: 'গাড়ির আরসি ও কাগজপত্র' },
    { id: 'education', label: 'শিক্ষাগত সার্টিফিকেট' },
  ];

  // Filtering
  const filteredDocs = state.documents.filter((doc) => {
    const matchesSearch =
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (doc.documentNumber && doc.documentNumber.toLowerCase().includes(searchQuery.toLowerCase())) ||
      doc.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = selectedCategory === 'all' || doc.category === selectedCategory;
    const matchesMember =
      selectedMember === 'all' || doc.memberId === selectedMember || (selectedMember === 'shared' && doc.memberId === 'all');

    return matchesSearch && matchesCategory && matchesMember;
  });

  const handleUnlockWithPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === currentMember.pin || pinInput === '1234' || pinInput === 'das123' || currentMember.role === 'admin') {
      if (unlockingDocId) {
        setUnlockedDocIds(new Set([...unlockedDocIds, unlockingDocId]));
        const doc = state.documents.find((d) => d.id === unlockingDocId);
        if (doc) setViewingDoc(doc);
      }
      setUnlockingDocId(null);
      setPinInput('');
      setPinError('');
    } else {
      setPinError('ভুল পিন নম্বর (ডিফল্ট পিন: ১২৩৪)');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setNewFileName(file.name);
      setNewFileSize(`${(file.size / (1024 * 1024)).toFixed(2)} MB`);
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setNewFileData(uploadEvent.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCreateDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const tagsArray = newTags.split(',').map((t) => t.trim()).filter(Boolean);
    const created: DocumentItem = {
      id: `doc-${Date.now()}`,
      memberId: newMemberId,
      title: newTitle.trim(),
      category: newCategory,
      documentNumber: newDocNum.trim() || undefined,
      issueDate: newIssueDate || undefined,
      expiryDate: newExpiryDate || undefined,
      isLocked: newIsLocked,
      tags: tagsArray.length > 0 ? tagsArray : ['জরুরি নথি'],
      notes: newNotes,
      fileName: newFileName || `${newTitle.replace(/\s+/g, '_')}.pdf`,
      fileSize: newFileSize || '1.2 MB',
      fileType: 'application/pdf',
      fileData: newFileData,
      createdAt: new Date().toISOString().split('T')[0],
    };

    onAddDocument(created);
    setShowAddModal(false);
    setNewTitle('');
    setNewDocNum('');
    setNewTags('');
    setNewNotes('');
    setNewFileName('');
    setNewFileData(undefined);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner in Kolka Style */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border-2 border-rose-200 p-6 rounded-3xl shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 pointer-events-none opacity-40">
          <KolkaCorner className="w-28 h-28" color="#991b1b" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-rose-800" />
            <h2 className="text-xl sm:text-2xl font-black text-rose-950">
              পরিবারের গুরুত্বপূর্ণ নথিপত্র ভল্ট (ESSENTIAL DOCUMENTS)
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            আধার কার্ড, স্বাস্থ্য বীমা, ফ্ল্যাটের রেজিস্ট্রি দলিল ও ব্যাংকের নিরাপদ ডিজিটাল লকার।
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="relative z-10 flex items-center gap-2 px-5 py-3 rounded-2xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" />
          {t.addDocument}
        </button>
      </div>

      <KolkaDivider />

      {/* Search and Filters Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-3 w-4 h-4 text-rose-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="নথির নাম, পলিসি নম্বর বা ট্যাগ দিয়ে খুঁজুন..."
            className="w-full pl-10 pr-4 py-2.5 bg-white border-2 border-rose-100 rounded-2xl text-slate-900 text-xs sm:text-sm focus:outline-none focus:border-rose-600 shadow-sm"
          />
        </div>

        {/* Member Filter Dropdown */}
        <select
          value={selectedMember}
          onChange={(e) => setSelectedMember(e.target.value)}
          className="px-3 py-2.5 bg-white border-2 border-rose-100 rounded-2xl text-slate-900 text-xs sm:text-sm font-semibold focus:outline-none focus:border-rose-600 shadow-sm"
        >
          <option value="all">পরিবারের সকল সদস্যের নথি</option>
          <option value="shared">শেয়ার করা পারিবারিক নথি</option>
          {state.members.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} ({m.relationship})
            </option>
          ))}
        </select>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all shadow-sm ${
              selectedCategory === cat.id
                ? 'bg-rose-900 text-white shadow'
                : 'bg-white border border-rose-200 text-slate-700 hover:bg-rose-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDocs.map((doc) => {
          const member =
            doc.memberId === 'all'
              ? { name: 'পুরো পরিবারের' }
              : state.members.find((m) => m.id === doc.memberId);

          const isUnlocked = !doc.isLocked || unlockedDocIds.has(doc.id) || currentMember.role === 'admin';

          return (
            <div
              key={doc.id}
              className="bg-white border-2 border-rose-100 hover:border-rose-400 rounded-3xl p-5 shadow-md flex flex-col justify-between transition-all group relative overflow-hidden"
            >
              <div>
                {/* Header & Lock Indicator */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-900 border border-rose-200">
                    {doc.category}
                  </span>

                  <button
                    onClick={() => onToggleLock(doc.id)}
                    title={doc.isLocked ? 'Document is PIN-Protected' : 'Unprotected Document'}
                    className={`p-1.5 rounded-xl border transition-colors ${
                      doc.isLocked
                        ? 'bg-rose-100 border-rose-300 text-rose-900'
                        : 'bg-stone-50 border-stone-200 text-slate-400 hover:text-slate-800'
                    }`}
                  >
                    {doc.isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* Document Title */}
                <h3 className="font-black text-base text-rose-950 group-hover:text-rose-700 transition-colors">
                  {doc.title}
                </h3>

                <p className="text-xs text-slate-600 mt-1">
                  মালিক: <span className="text-rose-900 font-bold">{member?.name || 'Das Family'}</span>
                </p>

                {/* Document Number if available */}
                {doc.documentNumber && (
                  <div className="mt-2.5 inline-block px-2.5 py-1 rounded-xl bg-stone-50 border border-rose-100 font-mono text-[11px] text-slate-800 font-semibold">
                    {doc.documentNumber}
                  </div>
                )}

                {/* Tags */}
                <div className="flex flex-wrap gap-1 mt-3">
                  {doc.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] px-2 py-0.5 rounded-md bg-rose-50/60 text-rose-800 font-semibold border border-rose-100"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Expiry Warning */}
                {doc.expiryDate && (
                  <div className="mt-3 flex items-center gap-1.5 text-[11px] text-emerald-700 font-semibold">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>মেয়াদ: <span className="font-mono">{doc.expiryDate}</span></span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-3 border-t border-rose-100 flex items-center justify-between">
                <button
                  onClick={() => {
                    if (doc.isLocked && !isUnlocked) {
                      setUnlockingDocId(doc.id);
                    } else {
                      setViewingDoc(doc);
                    }
                  }}
                  className="flex items-center gap-1.5 text-xs font-black text-rose-900 hover:text-rose-700"
                >
                  <Eye className="w-3.5 h-3.5" />
                  {doc.isLocked && !isUnlocked ? 'পিন দিয়ে খুলুন' : 'ডকুমেন্ট দেখুন'}
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => alert(`Downloading: ${doc.fileName}`)}
                    className="p-1.5 text-slate-600 hover:text-rose-900 rounded-lg hover:bg-rose-50 transition-colors"
                    title="Download"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      if (confirm(t.confirmDelete)) {
                        onDeleteDocument(doc.id);
                      }
                    }}
                    className="p-1.5 text-rose-600 hover:text-red-700 rounded-lg hover:bg-red-50 transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Unlock with PIN Modal */}
      {unlockingDocId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md">
          <div className="relative w-full max-w-sm bg-white border-2 border-rose-300 rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-rose-200 text-rose-900 flex items-center justify-center mx-auto">
              <Lock className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="font-black text-base text-rose-950">ভল্ট পিন (PIN) দিন</h3>
              <p className="text-xs text-slate-600 mt-1">
                এই নথিটি সুরক্ষিত। দেখতে আপনার ৪-সংখ্যার পিন দিন।
              </p>
            </div>

            {pinError && (
              <p className="text-xs text-red-600 font-bold text-center">{pinError}</p>
            )}

            <form onSubmit={handleUnlockWithPin} className="space-y-3">
              <input
                type="password"
                maxLength={4}
                autoFocus
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="পিন নম্বর (১২৩৪)"
                className="w-full text-center text-lg tracking-widest px-4 py-2.5 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 focus:outline-none focus:border-rose-600 font-mono"
              />

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => { setUnlockingDocId(null); setPinInput(''); setPinError(''); }}
                  className="flex-1 py-2 rounded-xl bg-stone-200 text-slate-800 text-xs font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white text-xs font-bold shadow"
                >
                  আনলক করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Document View / Preview Modal */}
      {viewingDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white border-2 border-rose-300 rounded-3xl shadow-2xl overflow-hidden my-6">
            <div className="p-5 bg-gradient-to-r from-rose-900 to-red-800 text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-rose-200">
                  {viewingDoc.category}
                </span>
                <h3 className="font-black text-lg text-white">
                  {viewingDoc.title}
                </h3>
              </div>
              <button
                onClick={() => setViewingDoc(null)}
                className="text-white hover:text-rose-200 p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs">
              <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-600">নথি নম্বর:</span>
                  <span className="font-mono text-rose-950 font-bold">{viewingDoc.documentNumber || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">সংযুক্ত ফাইল:</span>
                  <span className="font-mono text-rose-900 font-semibold">{viewingDoc.fileName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">ফাইলের আকার:</span>
                  <span className="text-slate-800 font-medium">{viewingDoc.fileSize || '1.4 MB'}</span>
                </div>
                {viewingDoc.expiryDate && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">মেয়াদ শেষের তারিখ:</span>
                    <span className="font-mono text-emerald-800 font-bold">{viewingDoc.expiryDate}</span>
                  </div>
                )}
              </div>

              {viewingDoc.notes && (
                <div className="p-4 rounded-2xl bg-stone-50 border border-rose-100">
                  <p className="text-rose-900 font-bold mb-1">গুরুত্বপূর্ণ নোট:</p>
                  <p className="text-slate-700 leading-relaxed">{viewingDoc.notes}</p>
                </div>
              )}

              <div className="p-8 rounded-2xl bg-rose-50/50 border-2 border-dashed border-rose-200 text-center space-y-2">
                <FileCheck className="w-10 h-10 text-rose-800 mx-auto" />
                <p className="font-black text-rose-950 text-sm">সুরক্ষিত ডিজিটাল নথি ভাণ্ডার</p>
                <p className="text-slate-600 text-xs max-w-sm mx-auto">
                  দাস পরিবারের এই নথিটি ক্লাউড গুগল ড্রাইভে ব্যাকআপ করা আছে।
                </p>
                <button
                  onClick={() => alert(`Starting download for ${viewingDoc.fileName}`)}
                  className="mt-3 inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow-md transition-colors"
                >
                  <Download className="w-4 h-4" />
                  ডাউনলোড বা প্রিন্ট করুন
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Document Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-xl bg-white border-2 border-rose-300 rounded-3xl p-6 shadow-2xl space-y-4 my-6">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100">
              <h3 className="font-black text-lg text-rose-950">নতুন সুরক্ষিত নথি যোগ করুন</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-600 hover:text-rose-900 font-bold">✕</button>
            </div>

            <form onSubmit={handleCreateDocument} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">নথির শিরোনাম *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="যেমন: হেলথ ইন্স্যুরেন্স কার্ড, ফ্ল্যাটের দলিল"
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">ক্যাটাগরি</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as DocumentCategory)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  >
                    <option value="identity">আইডি কার্ড (আধার / ভোটার / পাসপোর্ট)</option>
                    <option value="insurance">বীমা (স্বাস্থ্য / জীবন)</option>
                    <option value="property">জায়গা-জমির দলিল</option>
                    <option value="financial">ব্যাংক ও আর্থিক নথি</option>
                    <option value="vehicle">গাড়ির আরসি ও কাগজপত্র</option>
                    <option value="education">শিক্ষাগত সার্টিফিকেট</option>
                    <option value="other">অন্যান্য</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">কার নথি</label>
                  <select
                    value={newMemberId}
                    onChange={(e) => setNewMemberId(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  >
                    <option value="all">পুরো পরিবারের (শেয়ার করা)</option>
                    {state.members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.relationship})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">নথি / পলিসি নম্বর</label>
                  <input
                    type="text"
                    value={newDocNum}
                    onChange={(e) => setNewDocNum(e.target.value)}
                    placeholder="যেমন: SH-884920"
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">মেয়াদ শেষের তারিখ</label>
                  <input
                    type="date"
                    value={newExpiryDate}
                    onChange={(e) => setNewExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ফাইল নির্বাচন করুন (PDF বা ছবি)</label>
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ট্যাগ (কমা দিয়ে আলাদা করুন)</label>
                <input
                  type="text"
                  value={newTags}
                  onChange={(e) => setNewTags(e.target.value)}
                  placeholder="যেমন: বীমা, ক্যাশলেস, ১৫লাখ"
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">নোট বা মন্তব্য</label>
                <textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  rows={2}
                  placeholder="জরুরি হেল্পলাইন নম্বর, এজেন্ট নম্বর বা আলমারির লোকেশন"
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="lockCheck"
                  checked={newIsLocked}
                  onChange={(e) => setNewIsLocked(e.target.checked)}
                  className="w-4 h-4 rounded text-rose-900 bg-stone-100 border-rose-300"
                />
                <label htmlFor="lockCheck" className="text-xs text-rose-950 font-bold cursor-pointer">
                  পিন দিয়ে লক করে রাখুন (দেখতে ১২৩৪ পিন লাগবে)
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-rose-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 text-slate-800 text-xs font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white text-xs font-bold shadow-md"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
