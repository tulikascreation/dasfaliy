import React from 'react';
import { AlertTriangle, MapPin, Phone, Volume2, CheckCircle2 } from 'lucide-react';
import { EmergencyAlert } from '../types';

interface ActiveEmergencyBannerProps {
  alert: EmergencyAlert;
  onOpenSOS: () => void;
  onResolve: () => void;
}

export const ActiveEmergencyBanner: React.FC<ActiveEmergencyBannerProps> = ({
  alert,
  onOpenSOS,
  onResolve,
}) => {
  return (
    <div className="bg-red-600 text-white px-4 py-3 shadow-2xl border-b-2 border-red-700 animate-pulse sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-white/20 animate-ping">
            <AlertTriangle className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm uppercase tracking-wide bg-white text-red-700 px-2 py-0.5 rounded-full text-xs">
                🚨 FAMILY EMERGENCY ACTIVE
              </span>
              <span className="text-xs text-red-100 font-mono">
                {alert.timestamp}
              </span>
            </div>
            <p className="text-xs sm:text-sm font-bold text-white mt-0.5">
              {alert.triggeredByName} has triggered an SOS alert! Immediate response requested.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSOS}
            className="px-4 py-1.5 rounded-xl bg-white hover:bg-slate-100 text-red-700 font-black text-xs shadow-md transition-all active:scale-95"
          >
            View Live GPS &amp; Dispatch
          </button>
          <button
            onClick={onResolve}
            className="px-3 py-1.5 rounded-xl bg-red-800/80 hover:bg-red-900 text-white font-semibold text-xs border border-red-400/40 transition-colors"
          >
            Resolve ✓
          </button>
        </div>
      </div>
    </div>
  );
};
