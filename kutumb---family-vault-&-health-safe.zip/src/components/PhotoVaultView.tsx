import React, { useState } from 'react';
import { 
  FolderPlus, 
  Image as ImageIcon, 
  Upload, 
  Folder, 
  Calendar, 
  User, 
  X, 
  Download, 
  Trash2, 
  ArrowLeft,
  Tag,
  Maximize2
} from 'lucide-react';
import { 
  PhotoFolder, 
  PhotoItem, 
  FamilyMember, 
  Language, 
  VaultState 
} from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner, KolkaDivider } from './KolkaMotifs';

interface PhotoVaultViewProps {
  state: VaultState;
  currentLang: Language;
  onAddFolder: (folder: PhotoFolder) => void;
  onAddPhoto: (photo: PhotoItem) => void;
  onDeletePhoto: (id: string) => void;
  onDeleteFolder: (id: string) => void;
}

export const PhotoVaultView: React.FC<PhotoVaultViewProps> = ({
  state,
  currentLang,
  onAddFolder,
  onAddPhoto,
  onDeletePhoto,
  onDeleteFolder,
}) => {
  const t = getTranslation(currentLang);
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoItem | null>(null);

  // Modals
  const [showAddFolderModal, setShowAddFolderModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // New folder state
  const [folderName, setFolderName] = useState('');
  const [folderDesc, setFolderDesc] = useState('');
  const [folderColor, setFolderColor] = useState('bg-rose-900');

  // New photo state
  const [photoTitle, setPhotoTitle] = useState('');
  const [photoTargetFolder, setPhotoTargetFolder] = useState(state.photoFolders[0]?.id || '');
  const [photoDate, setPhotoDate] = useState(new Date().toISOString().split('T')[0]);
  const [photoCaption, setPhotoCaption] = useState('');
  const [taggedMembers, setTaggedMembers] = useState<string[]>([]);
  const [photoUrl, setPhotoUrl] = useState('');

  const currentFolder = state.photoFolders.find((f) => f.id === activeFolderId);
  const folderPhotos = activeFolderId
    ? state.photos.filter((p) => p.folderId === activeFolderId)
    : state.photos;

  const handleCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!folderName.trim()) return;

    const newFolder: PhotoFolder = {
      id: `folder-${Date.now()}`,
      name: folderName.trim(),
      description: folderDesc.trim() || undefined,
      color: folderColor,
      createdAt: new Date().toISOString().split('T')[0],
    };

    onAddFolder(newFolder);
    setShowAddFolderModal(false);
    setFolderName('');
    setFolderDesc('');
    setActiveFolderId(newFolder.id);
  };

  const handlePhotoFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (uploadEvent) => {
        setPhotoUrl(uploadEvent.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSavePhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!photoTitle.trim()) return;

    const fallbackImage =
      photoUrl ||
      'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1200&q=80';

    const newPhoto: PhotoItem = {
      id: `photo-${Date.now()}`,
      folderId: photoTargetFolder || activeFolderId || state.photoFolders[0]?.id,
      title: photoTitle.trim(),
      url: fallbackImage,
      date: photoDate,
      taggedMemberIds: taggedMembers,
      caption: photoCaption,
      fileSize: '1.8 MB',
    };

    onAddPhoto(newPhoto);
    setShowUploadModal(false);
    setPhotoTitle('');
    setPhotoCaption('');
    setPhotoUrl('');
    setTaggedMembers([]);
  };

  const toggleTagMember = (memberId: string) => {
    if (taggedMembers.includes(memberId)) {
      setTaggedMembers(taggedMembers.filter((id) => id !== memberId));
    } else {
      setTaggedMembers([...taggedMembers, memberId]);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner in Kolka Style */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border-2 border-rose-200 p-6 rounded-3xl shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 pointer-events-none opacity-40">
          <KolkaCorner className="w-28 h-28" color="#991b1b" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-6 h-6 text-rose-800" />
            <h2 className="text-xl sm:text-2xl font-black text-rose-950">
              নিবেদিত ফটো ও প্রেসক্রিপশন স্টোরেজ (DEDICATED PHOTO VAULT)
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            আলাদা ফোল্ডারে পারিবারিক স্মৃতি, প্রেসক্রিপশন, দুর্গোৎসব ও আইডি কার্ডের ছবি।
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-3">
          <button
            onClick={() => setShowAddFolderModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white hover:bg-rose-50 text-rose-950 font-bold text-xs sm:text-sm border-2 border-rose-200 transition-all active:scale-95 shadow-sm"
          >
            <FolderPlus className="w-4 h-4 text-rose-800" />
            নতুন অ্যালবাম
          </button>

          <button
            onClick={() => {
              if (activeFolderId) setPhotoTargetFolder(activeFolderId);
              setShowUploadModal(true);
            }}
            className="flex items-center gap-2 px-5 py-3 rounded-2xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
          >
            <Upload className="w-4 h-4" />
            ছবি আপলোড
          </button>
        </div>
      </div>

      <KolkaDivider />

      {/* If inside a dedicated folder: Header with back button */}
      {activeFolderId && currentFolder && (
        <div className="flex items-center justify-between bg-white p-4 rounded-2xl border-2 border-rose-200 shadow-md">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveFolderId(null)}
              className="p-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-900 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <div>
              <h3 className="font-black text-base text-rose-950 flex items-center gap-2">
                <Folder className="w-4 h-4 text-rose-800" />
                {currentFolder.name}
              </h3>
              <p className="text-xs text-slate-500">
                {folderPhotos.length}টি ছবি সংরক্ষিত {currentFolder.description && `• ${currentFolder.description}`}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              if (confirm('Delete this photo folder?')) {
                onDeleteFolder(currentFolder.id);
                setActiveFolderId(null);
              }
            }}
            className="p-2 text-rose-600 hover:text-red-700 transition-colors"
            title="Delete Folder"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Dedicated Folders Grid (shown if on main photo page) */}
      {!activeFolderId && (
        <div className="space-y-3">
          <h3 className="text-sm font-black text-rose-950 uppercase tracking-wider flex items-center gap-2">
            <span>✿</span> নিবেদিত স্টোরেজ ফোল্ডারসমূহ
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {state.photoFolders.map((folder) => {
              const count = state.photos.filter((p) => p.folderId === folder.id).length;
              const previewPhoto = state.photos.find((p) => p.folderId === folder.id);

              return (
                <div
                  key={folder.id}
                  onClick={() => setActiveFolderId(folder.id)}
                  className="bg-white border-2 border-rose-100 hover:border-rose-400 rounded-3xl p-5 shadow-md cursor-pointer group transition-all relative overflow-hidden flex flex-col justify-between"
                >
                  <div>
                    {/* Folder Icon Pill */}
                    <div className="flex items-center justify-between mb-3">
                      <div className="p-2.5 rounded-2xl bg-rose-900 text-white shadow-md group-hover:scale-110 transition-transform">
                        <Folder className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-black text-rose-900 bg-rose-50 px-2.5 py-0.5 rounded-lg border border-rose-200">
                        {count}টি ছবি
                      </span>
                    </div>

                    <h4 className="font-black text-base text-rose-950 group-hover:text-rose-700 transition-colors">
                      {folder.name}
                    </h4>

                    {folder.description && (
                      <p className="text-xs text-slate-500 mt-1 line-clamp-2">
                        {folder.description}
                      </p>
                    )}
                  </div>

                  {/* Thumbnail preview if any */}
                  {previewPhoto && (
                    <div className="mt-3 h-24 rounded-2xl overflow-hidden bg-stone-100 border border-rose-100">
                      <img
                        src={previewPhoto.url}
                        alt={folder.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Photos Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-black text-rose-950 uppercase tracking-wider flex items-center gap-2">
            <span>✿</span> {activeFolderId ? 'এই ফোল্ডারের ছবিসমূহ' : 'সাম্প্রতিক ছবিসমূহ'}
          </h3>
          <span className="text-xs text-rose-900 font-bold bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
            {folderPhotos.length} {t.totalPhotos}
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {folderPhotos.map((photo) => {
            const folder = state.photoFolders.find((f) => f.id === photo.folderId);
            return (
              <div
                key={photo.id}
                onClick={() => setSelectedPhoto(photo)}
                className="bg-white border-2 border-rose-100 hover:border-rose-300 rounded-3xl overflow-hidden shadow-md cursor-pointer group transition-all flex flex-col justify-between"
              >
                {/* Photo Image Aspect */}
                <div className="relative aspect-[4/3] bg-stone-100 overflow-hidden">
                  <img
                    src={photo.url}
                    alt={photo.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-rose-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                    <span className="text-white text-xs font-bold flex items-center gap-1">
                      <Maximize2 className="w-3.5 h-3.5" /> বড় করে দেখুন
                    </span>
                  </div>
                </div>

                {/* Caption & Info */}
                <div className="p-3.5 space-y-1">
                  <span className="text-[10px] font-bold text-rose-800 uppercase tracking-wide">
                    {folder?.name || 'অ্যালবাম'}
                  </span>
                  <h4 className="font-black text-sm text-rose-950 truncate">
                    {photo.title}
                  </h4>
                  <p className="text-[11px] text-slate-500 truncate">
                    {photo.date} {photo.caption && `• ${photo.caption}`}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Lightbox / Fullscreen Modal */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-rose-950/80 backdrop-blur-md">
          <div className="relative max-w-4xl w-full bg-white border-2 border-rose-300 rounded-3xl overflow-hidden shadow-2xl">
            <div className="p-4 bg-gradient-to-r from-rose-900 to-red-800 text-white flex items-center justify-between">
              <div>
                <h3 className="font-black text-base text-white">{selectedPhoto.title}</h3>
                <p className="text-xs text-rose-200">তারিখ: {selectedPhoto.date}</p>
              </div>
              <button
                onClick={() => setSelectedPhoto(null)}
                className="p-1.5 rounded-full hover:bg-white/10 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="max-h-[60vh] bg-stone-900 flex items-center justify-center overflow-hidden">
              <img
                src={selectedPhoto.url}
                alt={selectedPhoto.title}
                className="max-h-[60vh] max-w-full object-contain"
              />
            </div>

            <div className="p-4 sm:p-5 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                {selectedPhoto.caption && (
                  <p className="text-xs text-slate-800 font-medium">{selectedPhoto.caption}</p>
                )}
                {/* Tagged members */}
                {selectedPhoto.taggedMemberIds.length > 0 && (
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    <span className="text-[10px] text-slate-500 uppercase font-bold">ট্যাগ করা:</span>
                    {selectedPhoto.taggedMemberIds.map((id) => {
                      const m = state.members.find((member) => member.id === id);
                      return (
                        <span
                          key={id}
                          className="px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-900 border border-rose-200 text-[10px] font-bold"
                        >
                          {m?.name || 'Member'}
                        </span>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => alert('Downloading photo asset...')}
                  className="px-4 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white text-xs font-bold flex items-center gap-1.5 shadow"
                >
                  <Download className="w-3.5 h-3.5" />
                  ডাউনলোড
                </button>
                <button
                  onClick={() => {
                    if (confirm('Delete this photo?')) {
                      onDeletePhoto(selectedPhoto.id);
                      setSelectedPhoto(null);
                    }
                  }}
                  className="p-2 rounded-xl text-rose-600 hover:text-red-700 hover:bg-rose-50"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Create New Album Folder Modal */}
      {showAddFolderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-white border-2 border-rose-300 rounded-3xl p-6 shadow-2xl space-y-4">
            <h3 className="font-black text-lg text-rose-950">নতুন নিবেদিত ফটো ফোল্ডার তৈরি করুন</h3>
            <form onSubmit={handleCreateFolder} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ফোল্ডারের নাম *</label>
                <input
                  type="text"
                  required
                  value={folderName}
                  onChange={(e) => setFolderName(e.target.value)}
                  placeholder="যেমন: দার্জিলিং ভ্রমণ ২০২৬, পুজোর ছবি"
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">বিবরণ</label>
                <textarea
                  value={folderDesc}
                  onChange={(e) => setFolderDesc(e.target.value)}
                  placeholder="এই ফোল্ডারে কী কী ছবি সংরক্ষিত থাকবে?"
                  rows={2}
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-rose-100">
                <button
                  type="button"
                  onClick={() => setShowAddFolderModal(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 text-slate-800 text-xs font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow-md"
                >
                  ফোল্ডার তৈরি করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Upload Photo Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-lg bg-white border-2 border-rose-300 rounded-3xl p-6 shadow-2xl space-y-4 my-6">
            <h3 className="font-black text-lg text-rose-950">ফোল্ডারে ছবি আপলোড করুন</h3>
            <form onSubmit={handleSavePhoto} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">কোন ফোল্ডারে রাখবেন *</label>
                <select
                  value={photoTargetFolder}
                  onChange={(e) => setPhotoTargetFolder(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                >
                  {state.photoFolders.map((f) => (
                    <option key={f.id} value={f.id}>
                      📁 {f.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ছবির শিরোনাম *</label>
                <input
                  type="text"
                  required
                  value={photoTitle}
                  onChange={(e) => setPhotoTitle(e.target.value)}
                  placeholder="যেমন: দুর্গাপূজার অঞ্জলি, প্রেসক্রিপশনের ভাউচার"
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ছবি নির্বাচন করুন</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoFileUpload}
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">তারিখ</label>
                <input
                  type="date"
                  value={photoDate}
                  onChange={(e) => setPhotoDate(e.target.value)}
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">পরিবারের সদস্যদের ট্যাগ করুন</label>
                <div className="flex flex-wrap gap-1.5">
                  {state.members.map((m) => {
                    const isTagged = taggedMembers.includes(m.id);
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => toggleTagMember(m.id)}
                        className={`px-3 py-1 rounded-xl text-xs font-bold border transition-colors ${
                          isTagged
                            ? 'bg-rose-900 text-white border-rose-900 shadow-sm'
                            : 'bg-stone-50 text-slate-700 border-rose-200 hover:bg-rose-50'
                        }`}
                      >
                        {m.name.split(' ')[0]} {isTagged && '✓'}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">ক্যাপশন / স্মৃতি</label>
                <textarea
                  value={photoCaption}
                  onChange={(e) => setPhotoCaption(e.target.value)}
                  rows={2}
                  placeholder="এই মুহূর্ত বা প্রেসক্রিপশন সম্পর্কিত কোনো তথ্য"
                  className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-rose-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl bg-stone-200 text-slate-800 text-xs font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow-md"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
