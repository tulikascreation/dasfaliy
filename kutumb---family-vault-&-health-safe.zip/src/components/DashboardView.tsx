import React from 'react';
import { 
  Users, 
  Heart, 
  FileText, 
  Image as ImageIcon, 
  Cloud, 
  AlertTriangle, 
  Clock, 
  CheckCircle, 
  Plus, 
  ArrowUpRight, 
  ShieldCheck, 
  Activity, 
  Calendar, 
  Lock, 
  ChevronRight, 
  Radio, 
  Phone, 
  Flame, 
  MapPin,
  Sparkles
} from 'lucide-react';
import { VaultState, FamilyMember, Language } from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner, KolkaDivider, KolkaBadge } from './KolkaMotifs';

interface DashboardViewProps {
  state: VaultState;
  currentMember: FamilyMember;
  currentLang: Language;
  onNavigateTab: (tab: string) => void;
  onOpenSOS: () => void;
  onOpenDriveModal: () => void;
  onTriggerBackup: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  state,
  currentMember,
  currentLang,
  onNavigateTab,
  onOpenSOS,
  onOpenDriveModal,
  onTriggerBackup,
}) => {
  const t = getTranslation(currentLang);

  // STRICT REQUIREMENT: Only registered persons are visible in the app
  const registeredMembers = state.members.filter((m) => m.isRegistered !== false);
  const totalMembers = registeredMembers.length;
  const totalDocs = state.documents.length;
  const totalPhotos = state.photos.length;
  const recentVitals = state.vitals.slice(0, 3);
  const recentDocs = state.documents.slice(0, 4);

  return (
    <div className="space-y-6">
      
      {/* Traditional Bengali Kolka Hero Banner (White Background with Deep Crimson Red Filigree) */}
      <div className="relative overflow-hidden rounded-3xl bg-white border-2 border-rose-300 p-6 sm:p-8 shadow-xl shadow-rose-950/5">
        {/* Kolka Corner Filigree Top-Right & Bottom-Left */}
        <div className="absolute top-0 right-0 pointer-events-none opacity-80 rotate-90">
          <KolkaCorner className="w-32 h-32 sm:w-44 sm:h-44" color="#991b1b" />
        </div>
        <div className="absolute bottom-0 left-0 pointer-events-none opacity-80 -rotate-90">
          <KolkaCorner className="w-28 h-28 sm:w-36 sm:h-36" color="#991b1b" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 border border-rose-200 text-rose-900 text-xs font-black tracking-wide">
              <span className="text-rose-700">✿</span> দাস পরিবার আলপনা ভল্ট (DAS FAMILY)
            </div>
            <h1 className="text-2xl sm:text-4xl font-black text-rose-950 tracking-tight">
              নমস্কার, <span className="text-rose-700">{currentMember.name}</span>
            </h1>
            <p className="text-sm text-slate-700 max-w-xl leading-relaxed">
              পরিবারের সকল জরুরি নথিপত্র, প্রেসক্রিপশন ও স্বাস্থ্য সংক্রান্ত তথ্য এখানে সম্পূর্ণ নিরাপদ। জরুরি মুহূর্তে একটি ক্লিকেই সবার ফোনে অ্যালার্ট পাঠান।
            </p>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenSOS}
              className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-red-600 via-rose-700 to-red-700 hover:from-red-500 hover:to-rose-600 text-white font-black text-sm shadow-xl shadow-red-700/30 ring-2 ring-red-400 active:scale-95 transition-all"
            >
              <Flame className="w-5 h-5 text-amber-200 animate-bounce" />
              🚨 সবার ফোনে অ্যালার্ট পাঠান
            </button>
            <button
              onClick={onTriggerBackup}
              className="flex items-center gap-2 px-4 py-3 rounded-2xl bg-white hover:bg-rose-50 border-2 border-rose-300 text-rose-950 font-bold text-xs sm:text-sm shadow-sm active:scale-95 transition-all"
            >
              <Cloud className="w-4 h-4 text-rose-700" />
              ড্রাইভে ব্যাকআপ
            </button>
          </div>
        </div>
      </div>

      <KolkaDivider />

      {/* 4 Primary Stats Cards (Pure White with Crimson Red Accents) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Family Members */}
        <div 
          onClick={() => onNavigateTab('members')}
          className="bg-white border-2 border-rose-100 hover:border-rose-400 p-5 rounded-3xl cursor-pointer group transition-all hover:shadow-lg hover:shadow-rose-900/5 relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-900 uppercase tracking-wider">সদস্যবৃন্দ</span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-800 group-hover:scale-110 transition-transform">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-rose-950">{totalMembers}</span>
            <span className="text-xs text-rose-700 font-semibold">সদস্য প্রোফাইল</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-600 flex items-center gap-1 group-hover:text-rose-800 transition-colors">
            প্রধান: মিলন দাস <ChevronRight className="w-3 h-3" />
          </p>
        </div>

        {/* Emergency SOS Ready Card */}
        <div 
          onClick={onOpenSOS}
          className="bg-gradient-to-br from-rose-900 to-red-950 text-white border-2 border-red-700 p-5 rounded-3xl cursor-pointer group transition-all hover:shadow-xl hover:shadow-rose-900/20 relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-rose-200 uppercase tracking-wider">জরুরি এসওএস</span>
            <div className="p-2 rounded-xl bg-white/20 text-white group-hover:scale-110 transition-transform animate-pulse">
              <Radio className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-white">{state.members.length}</span>
            <span className="text-xs text-rose-200 font-bold">ফোন প্রস্তুত</span>
          </div>
          <p className="mt-1 text-[11px] text-amber-300 flex items-center gap-1 font-bold">
            প্রেস করে অ্যালার্ট পাঠান <ChevronRight className="w-3 h-3" />
          </p>
        </div>

        {/* Essential Documents */}
        <div 
          onClick={() => onNavigateTab('documents')}
          className="bg-white border-2 border-rose-100 hover:border-rose-400 p-5 rounded-3xl cursor-pointer group transition-all hover:shadow-lg hover:shadow-rose-900/5 relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-900 uppercase tracking-wider">নথিপত্র</span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-800 group-hover:scale-110 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-rose-950">{totalDocs}</span>
            <span className="text-xs text-rose-700 font-semibold">সুরক্ষিত ফাইল</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-600 flex items-center gap-1 group-hover:text-rose-800 transition-colors">
            আইডি, বীমা ও দলিল <ChevronRight className="w-3 h-3" />
          </p>
        </div>

        {/* Dedicated Photos */}
        <div 
          onClick={() => onNavigateTab('photos')}
          className="bg-white border-2 border-rose-100 hover:border-rose-400 p-5 rounded-3xl cursor-pointer group transition-all hover:shadow-lg hover:shadow-rose-900/5 relative overflow-hidden"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-rose-900 uppercase tracking-wider">ফটো স্টোরেজ</span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-800 group-hover:scale-110 transition-transform">
              <ImageIcon className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl sm:text-3xl font-black text-rose-950">{totalPhotos}</span>
            <span className="text-xs text-rose-700 font-semibold">{state.photoFolders.length}টি ফোল্ডারে</span>
          </div>
          <p className="mt-1 text-[11px] text-slate-600 flex items-center gap-1 group-hover:text-rose-800 transition-colors">
            প্রেসক্রিপশন ও পারিবারিক স্মৃতি <ChevronRight className="w-3 h-3" />
          </p>
        </div>
      </div>

      {/* DAS FAMILY AI ASSISTANT SHOWCASE BANNER (EVERYONE IN FAMILY CAN USE) */}
      <div 
        onClick={() => onNavigateTab('ai')}
        className="bg-white border-2 border-rose-300 rounded-3xl p-5 sm:p-6 shadow-md hover:shadow-xl hover:border-rose-700 cursor-pointer transition-all relative overflow-hidden group"
      >
        <div className="absolute top-0 right-0 pointer-events-none opacity-40">
          <KolkaCorner className="w-24 h-24" color="#991b1b" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-50 text-rose-900 border border-rose-200 text-xs font-black">
              <Sparkles className="w-3.5 h-3.5 text-rose-700 animate-spin-slow" />
              <span>পারিবারিক স্মার্ট এআই সহায়ক • পরিবারের সকলের জন্য উন্মুক্ত</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-rose-950 flex items-center gap-2 group-hover:text-rose-700 transition-colors">
              সুস্বাস্থ্যবিধি, চিঠি ও আবেদন পত্র, ঐতিহ্যবাহী রান্না এবং শিশু শিক্ষা
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
              বরিষ্ঠদের স্বাস্থ্যবিধি ও রক্তচাপ পরামর্শ, দুর্গাপূজার ভোগ ও রান্না, স্কুলের ছুটির দরখাস্ত, ছোটদের মজার বিজ্ঞান কুইজ—সবকিছু এক ক্লিকেই বাংলায় জানুন ও উচ্চস্বরে শুনুন।
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button className="px-5 py-2.5 rounded-2xl bg-rose-900 group-hover:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>এআই ওপেন করুন</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* GOOGLE PLAY STORE & MOBILE APP INSTALL BANNER */}
      <div
        onClick={() => onNavigateTab('playstore')}
        className="bg-gradient-to-r from-emerald-50 via-white to-rose-50 border-2 border-emerald-300 rounded-3xl p-5 sm:p-6 shadow-md hover:shadow-xl hover:border-emerald-600 cursor-pointer transition-all relative overflow-hidden group"
      >
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-4">
            <img
              src="/icon.svg"
              alt="DAS FAMILY App Icon"
              className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl shadow-md border-2 border-rose-800 shrink-0"
            />
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 text-[11px] font-black">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>Google Play Store & PWA Ready • com.dasfamily.smartvault</span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-rose-950 group-hover:text-emerald-800 transition-colors">
                গুগল প্লে স্টোর রিলিজ সেন্টার ও মোবাইল অ্যাপ ইনস্টল
              </h3>
              <p className="text-xs text-slate-600 max-w-2xl">
                ১-ক্লিকে আপনার ফোনে DAS FAMILY অ্যাপটি ইনস্টল করুন অথবা Google Play Console-এ আপলোডের জন্য প্রস্তুতকৃত <code className="font-bold text-rose-900">.AAB / .APK</code> এবং <code className="font-bold text-rose-900">assetlinks.json</code> ফাইল ডাউনলোড করুন।
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button className="px-5 py-2.5 rounded-2xl bg-emerald-700 group-hover:bg-emerald-600 text-white font-black text-xs sm:text-sm shadow-md transition-all flex items-center gap-2">
              <span>📲 প্লে স্টোর ও অ্যাপ সেন্টার</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Two Columns: Emergency Broadcast & Quick Documents */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 spans): Emergency Alert Hub & Vitals */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Emergency Alert Broadcast Station Card in Crimson Red with White Kolka Details */}
          <div className="bg-gradient-to-br from-rose-900 via-red-900 to-rose-950 text-white rounded-3xl p-6 sm:p-7 shadow-2xl shadow-rose-950/20 border-2 border-rose-700 relative overflow-hidden">
            
            {/* White Kolka motif in corner */}
            <div className="absolute top-0 right-0 pointer-events-none opacity-20">
              <KolkaCorner className="w-40 h-40" color="#ffffff" />
            </div>

            <div className="relative z-10 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-rose-700/60">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 rounded-2xl bg-white text-rose-900 shadow-lg">
                    <Flame className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <h3 className="font-black text-base sm:text-lg text-white flex items-center gap-2">
                      পারিবারিক জরুরি এসওএস স্টেশন
                    </h3>
                    <p className="text-xs text-rose-200">এই বোতাম টিপলে একই সাথে পরিবারের সবার ফোনে অ্যালার্ট যাবে</p>
                  </div>
                </div>

                <span className="inline-flex items-center gap-1.5 text-xs text-amber-200 font-bold bg-white/10 px-3 py-1 rounded-full border border-white/20">
                  <span className="w-2 h-2 rounded-full bg-amber-300 animate-ping" />
                  লাইভ জিপিএস সক্রিয়
                </span>
              </div>

              {/* Big Alert Trigger Banner */}
              <div className="p-5 rounded-2xl bg-white/10 border border-white/20 flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-sm">
                <div className="space-y-1 text-center sm:text-left">
                  <h4 className="font-black text-base text-white">
                    🚨 সবার ফোনে তাৎক্ষণিক অ্যালার্ট পাঠান
                  </h4>
                  <p className="text-xs text-rose-100">
                    লাইভ জিপিএস লোকেশন ম্যাপ, সাইরেন অ্যালার্ম ও হোয়াটসঅ্যাপ/এসএমএস মেসেজ সব সদস্যের কাছে যাবে।
                  </p>
                </div>

                <button
                  onClick={onOpenSOS}
                  className="w-full sm:w-auto px-7 py-3.5 rounded-2xl bg-white hover:bg-rose-50 text-rose-950 font-black text-sm tracking-wide shadow-2xl active:scale-95 transition-all whitespace-nowrap flex items-center justify-center gap-2"
                >
                  <Radio className="w-4 h-4 text-red-600 animate-bounce" />
                  অ্যালার্ট পাঠান
                </button>
              </div>

              {/* Quick Family Phone Grid (Registered Members) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                {registeredMembers.slice(0, 3).map((m) => (
                  <div key={m.id} className="p-3 rounded-2xl bg-white/10 border border-white/15 flex items-center justify-between text-xs backdrop-blur-sm">
                    <div>
                      <p className="font-bold text-white flex items-center gap-1">
                        {m.name.split(' ')[0]}
                        <span className="text-[10px] text-amber-300">({m.bloodGroup})</span>
                        <span className="text-[9px] bg-white/20 px-1 py-0.2 rounded text-emerald-200">নিবন্ধিত</span>
                      </p>
                      <p className="text-[10px] text-rose-200 font-mono">{m.phone}</p>
                    </div>
                    <a
                      href={`tel:${m.phone.replace(/\s+/g, '')}`}
                      className="p-1.5 rounded-xl bg-white text-rose-900 hover:bg-rose-100 shadow transition-colors"
                      title="Direct Call"
                    >
                      <Phone className="w-3.5 h-3.5" />
                    </a>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Vitals Summary Widget (White with Crimson Red Accent) */}
          <div className="bg-white border-2 border-rose-100 rounded-3xl p-5 sm:p-6 shadow-lg">
            <div className="flex items-center justify-between pb-4 border-b border-rose-100">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-rose-50 text-rose-800">
                  <Heart className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-base text-rose-950">সাম্প্রতিক স্বাস্থ্য রিপোর্ট ও সুগার লগ</h3>
                  <p className="text-xs text-slate-500">রক্তচাপ, সুগার ও পালস পর্যবেক্ষণ</p>
                </div>
              </div>
              <button
                onClick={() => onNavigateTab('health')}
                className="text-xs font-bold text-rose-800 hover:text-rose-900 flex items-center gap-1"
              >
                নতুন রেকর্ড <Plus className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
              {recentVitals.map((log) => {
                const member = state.members.find(m => m.id === log.memberId);
                return (
                  <div key={log.id} className="p-3.5 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-black text-rose-950">{member?.name}</span>
                      <span className="text-rose-800 font-mono text-[11px]">{log.date}</span>
                    </div>
                    <div className="flex items-center gap-4 text-xs">
                      {log.bpSystolic && (
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">BP</p>
                          <p className="font-black text-sm text-rose-900">{log.bpSystolic}/{log.bpDiastolic} <span className="text-[10px] text-slate-500">mmHg</span></p>
                        </div>
                      )}
                      {log.bloodSugar && (
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Sugar ({log.bloodSugarType})</p>
                          <p className="font-black text-sm text-amber-700">{log.bloodSugar} <span className="text-[10px] text-slate-500">mg/dL</span></p>
                        </div>
                      )}
                      {log.pulse && (
                        <div>
                          <p className="text-[10px] text-slate-500 uppercase font-semibold">Pulse</p>
                          <p className="font-black text-sm text-rose-700">{log.pulse} <span className="text-[10px] text-slate-500">bpm</span></p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (1 span): Cloud Status & Recent Documents */}
        <div className="space-y-6">
          
          {/* Google Drive Status Widget (White Surface with Deep Crimson Trims) */}
          <div className="bg-white border-2 border-rose-200 rounded-3xl p-5 sm:p-6 shadow-lg">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-2xl bg-rose-50 text-rose-800 border border-rose-200">
                <Cloud className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-sm text-rose-950">গুগল ড্রাইভ ব্যাকআপ</h3>
                <span className="inline-flex items-center gap-1.5 text-xs text-emerald-700 font-bold">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                  স্বয়ংক্রিয় সিঙ্ক চালু
                </span>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-700 bg-rose-50/60 p-3.5 rounded-2xl border border-rose-200">
              <div className="flex justify-between">
                <span className="text-slate-500">অ্যাকাউন্ট:</span>
                <span className="font-mono text-rose-950 font-semibold">milon8727@gmail.com</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">ফোল্ডার:</span>
                <span className="font-bold text-rose-900 truncate max-w-[150px]">DAS FAMILY VAULT</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">সর্বশেষ ব্যাকআপ:</span>
                <span className="text-slate-700 font-mono text-[11px]">{state.driveSync.lastSyncTime || 'আজ'}</span>
              </div>
            </div>

            <button
              onClick={onOpenDriveModal}
              className="mt-4 w-full py-2.5 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
            >
              ক্লাউড ব্যাকআপ নিয়ন্ত্রণ
            </button>
          </div>

          {/* Quick Access to Documents (White Surface with Crimson Red Borders) */}
          <div className="bg-white border-2 border-rose-100 rounded-3xl p-5 sm:p-6 shadow-lg">
            <div className="flex items-center justify-between pb-3 border-b border-rose-100">
              <h3 className="font-black text-sm text-rose-950 flex items-center gap-2">
                <FileText className="w-4 h-4 text-rose-800" />
                জরুরি নথিপত্র
              </h3>
              <button
                onClick={() => onNavigateTab('documents')}
                className="text-xs text-rose-800 font-bold hover:underline"
              >
                সব দেখুন
              </button>
            </div>

            <div className="mt-3 space-y-2.5">
              {recentDocs.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => onNavigateTab('documents')}
                  className="p-3 rounded-2xl bg-stone-50 hover:bg-rose-50/80 border border-rose-200/80 cursor-pointer flex items-center justify-between text-xs transition-colors"
                >
                  <div className="truncate pr-2">
                    <p className="font-bold text-slate-900 truncate flex items-center gap-1.5">
                      {doc.isLocked && <Lock className="w-3 h-3 text-rose-700 shrink-0" />}
                      {doc.title}
                    </p>
                    <p className="text-[10px] text-slate-500 capitalize">{doc.category} • {doc.fileName}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-rose-600 shrink-0" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
