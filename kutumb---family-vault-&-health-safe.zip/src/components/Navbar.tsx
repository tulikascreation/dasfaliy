import React from 'react';
import { Shield, Cloud, Lock, Users, AlertTriangle, Globe, Sparkles, Smartphone, WifiOff } from 'lucide-react';
import { FamilyMember, Language, DriveSyncState } from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner } from './KolkaMotifs';
import { usePWAInstall, useOnlineStatus } from '../hooks/usePWAInstall';

interface NavbarProps {
  currentMember: FamilyMember;
  onOpenMemberSwitcher: () => void;
  onOpenMyProfile: () => void;
  onOpenSOS: () => void;
  onOpenDriveModal: () => void;
  onOpenAI: () => void;
  onOpenPlayStore: () => void;
  onLogout: () => void;
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  driveSync: DriveSyncState;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentMember,
  onOpenMemberSwitcher,
  onOpenMyProfile,
  onOpenSOS,
  onOpenDriveModal,
  onOpenAI,
  onOpenPlayStore,
  onLogout,
  currentLang,
  onLanguageChange,
  driveSync,
}) => {
  const t = getTranslation(currentLang);
  const isAdmin = currentMember.role === 'admin';
  const { isInstalled } = usePWAInstall();
  const isOnline = useOnlineStatus();

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b-2 border-rose-200 text-slate-900 shadow-md">
      {/* Decorative Traditional Red Kolka Border Ribbon */}
      <div className="h-1.5 w-full bg-gradient-to-r from-rose-900 via-red-700 to-rose-900" />

      {/* Offline Status Banner */}
      {!isOnline && (
        <div className="bg-amber-500 text-rose-950 text-xs font-black py-1 px-4 text-center flex items-center justify-center gap-2">
          <WifiOff className="w-3.5 h-3.5" />
          <span>অফলাইন মোড চালু আছে — দাস পরিবার ভল্ট ইন্টারনেট ছাড়াই কাজ করছে</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Brand Logo & Name with Kolka Crest */}
          <div className="flex items-center gap-3">
            <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-2xl bg-gradient-to-tr from-rose-900 to-red-800 p-0.5 shadow-md shadow-rose-900/20">
              <div className="w-full h-full bg-rose-950 rounded-[14px] flex items-center justify-center relative overflow-hidden">
                <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                  {/* Bengali Paisley / Kolka Icon */}
                  <path d="M12 2C8.5 7 5 11 5 15.5C5 19.1 7.9 22 11.5 22C15.1 22 18 19.1 18 15.5C18 13.5 17 11.5 15.5 10C14 8.5 14 6 15 4C14 3 13 2 12 2ZM11.5 19C9.6 19 8 17.4 8 15.5C8 13 10 10.5 11.5 8.5C13 10.5 15 13 15 15.5C15 17.4 13.4 19 11.5 19Z" />
                </svg>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-xl sm:text-2xl tracking-wider text-rose-950">
                  {t.appTitle}
                </span>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-black tracking-wider bg-rose-100 text-rose-900 border border-rose-300">
                  পারিবারিক ভল্ট
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-rose-800 font-medium hidden sm:block truncate max-w-xs md:max-w-md">
                {t.vaultSubtitle}
              </p>
            </div>
          </div>

          {/* Quick Actions & Status */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Google Play Store & Install App Button */}
            <button
              onClick={onOpenPlayStore}
              title="গুগল প্লে স্টোর ও মোবাইল অ্যাপ ইনস্টল"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black bg-emerald-50 hover:bg-emerald-100 border-2 border-emerald-300 text-emerald-950 transition-all hover:scale-105 active:scale-95 shadow-sm cursor-pointer"
            >
              <Smartphone className="w-4 h-4 text-emerald-700" />
              <span className="hidden md:inline">
                {isInstalled ? 'প্লে স্টোর রেডি' : '📲 প্লে স্টোর / অ্যাপ'}
              </span>
            </button>

            {/* Google Drive Sync Indicator */}
            <button
              onClick={onOpenDriveModal}
              title="Google Drive Backup Status"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-950 transition-all hover:scale-105 active:scale-95 shadow-sm"
            >
              <div className="relative">
                <Cloud className="w-4 h-4 text-rose-700" />
                <span className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full ${driveSync.autoSyncEnabled ? 'bg-emerald-600 animate-pulse' : 'bg-amber-500'}`} />
              </div>
              <span className="hidden lg:inline text-rose-950 font-medium">
                ড্রাইভ ব্যাকআপ
              </span>
            </button>

            {/* Language Switcher */}
            <div className="relative group">
              <button
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 border border-rose-200 text-rose-900 transition-colors shadow-sm"
                title="Change Language"
              >
                <Globe className="w-3.5 h-3.5 text-rose-800" />
                <span className="uppercase tracking-wider">{currentLang}</span>
              </button>
              <div className="absolute right-0 mt-2 w-36 bg-white border border-rose-200 rounded-xl shadow-xl py-1 hidden group-hover:block group-focus-within:block z-50">
                <button
                  onClick={() => onLanguageChange('bn')}
                  className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-rose-50 ${currentLang === 'bn' ? 'text-rose-900 font-bold bg-rose-50/60' : 'text-slate-700'}`}
                >
                  বাংলা (Bengali) {currentLang === 'bn' && '✓'}
                </button>
                <button
                  onClick={() => onLanguageChange('en')}
                  className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-rose-50 ${currentLang === 'en' ? 'text-rose-900 font-bold bg-rose-50/60' : 'text-slate-700'}`}
                >
                  English {currentLang === 'en' && '✓'}
                </button>
                <button
                  onClick={() => onLanguageChange('hi')}
                  className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-rose-50 ${currentLang === 'hi' ? 'text-rose-900 font-bold bg-rose-50/60' : 'text-slate-700'}`}
                >
                  हिन्दी (Hindi) {currentLang === 'hi' && '✓'}
                </button>
              </div>
            </div>

            {/* Family AI Assistant Button */}
            <button
              onClick={onOpenAI}
              className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs sm:text-sm font-black bg-rose-900 hover:bg-rose-800 text-white shadow-md shadow-rose-950/20 border border-rose-700 hover:scale-105 active:scale-95 transition-all"
              title="দাস পরিবার এআই সহায়ক (সবার জন্য)"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
              <span className="hidden sm:inline">এআই সহায়ক</span>
              <span className="sm:hidden">এআই</span>
            </button>

            {/* Emergency SOS Pulse Button (Deep Crimson & White) */}
            <button
              onClick={onOpenSOS}
              className="flex items-center gap-1.5 px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-black bg-gradient-to-r from-red-600 via-rose-700 to-red-700 hover:from-red-500 hover:to-rose-600 text-white shadow-lg shadow-red-700/30 ring-2 ring-red-400 animate-pulse hover:animate-none transition-all active:scale-95"
              title="সবার ফোনে অ্যালার্ট পাঠান"
            >
              <AlertTriangle className="w-4 h-4 text-white" />
              <span className="tracking-wide">🚨 SOS অ্যালার্ট</span>
            </button>

            {/* Active Member Pill */}
            <div className="flex items-center gap-1 bg-rose-50/90 rounded-2xl border border-rose-200 p-1 shadow-sm">
              <button
                onClick={onOpenMyProfile}
                className="flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-xl hover:bg-rose-100 transition-all text-left group"
                title={t.myProfile}
              >
                <div className="w-7 h-7 rounded-lg bg-rose-900 text-white flex items-center justify-center text-xs font-black shadow">
                  {currentMember.name.charAt(0)}
                </div>
                <div className="hidden sm:block">
                  <p className="text-xs font-black text-rose-950 leading-tight flex items-center gap-1 group-hover:text-rose-700">
                    {currentMember.name.split(' ')[0]}
                    {isAdmin && <span className="text-[10px] text-amber-600 font-bold">👑</span>}
                  </p>
                  <p className="text-[10px] text-rose-800 capitalize flex items-center gap-1">
                    {currentMember.relationship} • <span className="text-rose-600 font-semibold hover:underline">তথ্য পরিবর্তন</span>
                  </p>
                </div>
              </button>

              <button
                onClick={onOpenMemberSwitcher}
                className="p-1.5 rounded-xl hover:bg-rose-100 text-rose-700 transition-colors"
                title={t.switchMember}
              >
                <Users className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Logout/Lock button */}
            <button
              onClick={onLogout}
              className="p-2 rounded-xl text-rose-700 hover:text-rose-950 hover:bg-rose-100 transition-colors"
              title={t.logout}
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
