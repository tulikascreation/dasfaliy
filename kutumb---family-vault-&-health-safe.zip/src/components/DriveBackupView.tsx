import React, { useState } from 'react';
import { 
  Cloud, 
  CheckCircle2, 
  Download, 
  Upload, 
  RefreshCw, 
  ShieldCheck, 
  Folder, 
  Clock, 
  Mail, 
  FileCheck,
  HardDrive
} from 'lucide-react';
import { VaultState, Language } from '../types';
import { getTranslation } from '../utils/translations';
import { exportVaultBackup } from '../utils/storage';
import { KolkaCorner, KolkaDivider } from './KolkaMotifs';

interface DriveBackupViewProps {
  state: VaultState;
  currentLang: Language;
  onTriggerBackup: () => void;
  onRestoreState: (restored: VaultState) => void;
  onToggleAutoSync: (enabled: boolean) => void;
  onUpdateFrequency: (freq: 'realtime' | 'daily' | 'weekly') => void;
}

export const DriveBackupView: React.FC<DriveBackupViewProps> = ({
  state,
  currentLang,
  onTriggerBackup,
  onRestoreState,
  onToggleAutoSync,
  onUpdateFrequency,
}) => {
  const t = getTranslation(currentLang);
  const [isExporting, setIsExporting] = useState(false);
  const [restoreSuccess, setRestoreSuccess] = useState(false);
  const [restoreError, setRestoreError] = useState('');

  const handleDownloadBackup = () => {
    setIsExporting(true);
    exportVaultBackup(state);
    setTimeout(() => setIsExporting(false), 800);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    setRestoreError('');
    setRestoreSuccess(false);
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        if (!parsed.familyName || !Array.isArray(parsed.members)) {
          throw new Error('Invalid backup archive structure');
        }
        onRestoreState(parsed);
        setRestoreSuccess(true);
        setTimeout(() => setRestoreSuccess(false), 4000);
      } catch (err: any) {
        setRestoreError('Failed to parse backup file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner in Kolka Style */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border-2 border-rose-200 p-6 rounded-3xl shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 pointer-events-none opacity-40">
          <KolkaCorner className="w-28 h-28" color="#991b1b" />
        </div>

        <div className="relative z-10">
          <div className="flex items-center gap-2">
            <Cloud className="w-6 h-6 text-rose-800" />
            <h2 className="text-xl sm:text-2xl font-black text-rose-950">
              গুগল ড্রাইভ স্বয়ংক্রিয় ক্লাউড ব্যাকআপ (GOOGLE DRIVE SYNC)
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 mt-1 max-w-2xl">
            আপনার পরিবারের মেডিকেল প্রেসক্রিপশন ও সব গুরুত্বপূর্ণ নথিপত্র নিরাপদে গুগল ড্রাইভে স্বয়ংক্রিয়ভাবে ব্যাকআপ হয়ে থাকবে।
          </p>
        </div>

        <button
          onClick={onTriggerBackup}
          disabled={state.driveSync.isSyncing}
          className="relative z-10 flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${state.driveSync.isSyncing ? 'animate-spin' : ''}`} />
          {state.driveSync.isSyncing ? 'সিঙ্ক হচ্ছে...' : 'এখন ব্যাকআপ নিন'}
        </button>
      </div>

      <KolkaDivider />

      {/* Main Cloud Drive Sync Configuration Card */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column (2 spans): Drive Connection Status */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border-2 border-rose-100 rounded-3xl p-6 shadow-md space-y-5">
            <div className="flex items-center justify-between border-b border-rose-100 pb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-center justify-center">
                  <Cloud className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-base text-rose-950">গুগল ড্রাইভ ক্লাউড ইন্টিগ্রেশন</h3>
                  <p className="text-xs text-slate-500">গুগল ক্লাউড এপিআই দ্বারা সুরক্ষিত</p>
                </div>
              </div>

              <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 text-xs font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
                সংযুক্ত আছে
              </span>
            </div>

            {/* Sync Settings Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-1">
                <span className="text-slate-500 block text-[11px] uppercase font-bold">সংযুক্ত জিমেইল অ্যাকাউন্ট</span>
                <span className="font-mono text-rose-950 text-sm font-bold flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-rose-800" />
                  {state.driveSync.accountEmail || 'milon8727@gmail.com'}
                </span>
                <p className="text-[10px] text-slate-500">গুগল ওয়ার্কস্পেস ড্রাইভ ব্যাকআপ</p>
              </div>

              <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-1">
                <span className="text-slate-500 block text-[11px] uppercase font-bold">ড্রাইভ ফোল্ডার</span>
                <span className="font-bold text-rose-900 text-sm flex items-center gap-1.5">
                  <Folder className="w-3.5 h-3.5 text-rose-800" />
                  DAS FAMILY VAULT
                </span>
                <p className="text-[10px] text-slate-500">সমস্ত ব্যাকআপ ফাইল ও ফটো ফোল্ডার</p>
              </div>

              <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-1">
                <span className="text-slate-500 block text-[11px] uppercase font-bold">সর্বশেষ ক্লাউড ব্যাকআপ</span>
                <span className="font-mono text-emerald-800 text-sm font-bold flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-700" />
                  {state.driveSync.lastSyncTime || 'আজ'}
                </span>
                <p className="text-[10px] text-slate-500">সকল ৫ জন সদস্যের তথ্য সুরক্ষিত</p>
              </div>

              <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-200/80 space-y-1">
                <span className="text-slate-500 block text-[11px] uppercase font-bold">মোট সিঙ্ক হওয়া ফাইল</span>
                <span className="font-bold text-rose-950 text-sm flex items-center gap-1.5">
                  <FileCheck className="w-3.5 h-3.5 text-rose-800" />
                  {state.driveSync.syncedFilesCount + state.documents.length + state.photos.length}টি আইটেম
                </span>
                <p className="text-[10px] text-slate-500">১০০% আপ-টু-ডেট</p>
              </div>
            </div>

            {/* Auto-Sync Toggle & Frequency */}
            <div className="pt-2 border-t border-rose-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <input
                  type="checkbox"
                  id="autoSync"
                  checked={state.driveSync.autoSyncEnabled}
                  onChange={(e) => onToggleAutoSync(e.target.checked)}
                  className="w-5 h-5 rounded text-rose-900 bg-stone-100 border-rose-300 cursor-pointer"
                />
                <label htmlFor="autoSync" className="text-xs text-rose-950 font-bold cursor-pointer">
                  গুগল ড্রাইভে স্বয়ংক্রিয় অটো-ব্যাকআপ চালু রাখুন
                </label>
              </div>

              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-600 font-semibold">ফ্রিকোয়েন্সি:</span>
                {(['realtime', 'daily', 'weekly'] as const).map((freq) => (
                  <button
                    key={freq}
                    onClick={() => onUpdateFrequency(freq)}
                    className={`px-3 py-1 rounded-xl capitalize font-bold transition-colors ${
                      state.driveSync.syncFrequency === freq
                        ? 'bg-rose-900 text-white font-bold'
                        : 'bg-stone-100 text-slate-600 hover:bg-stone-200'
                    }`}
                  >
                    {freq}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Drive Security & Encryption Banner */}
          <div className="p-5 rounded-3xl bg-rose-50/60 border border-rose-200 flex items-start gap-4">
            <div className="p-3 rounded-2xl bg-white border border-rose-200 text-rose-900 shadow-sm shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h4 className="font-black text-sm text-rose-950">সম্পূর্ণ পারিবারিক গোপনীয়তা ও সুরক্ষা</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                দাস পরিবারের কোনো তথ্য বাইরে কোথাও যায় না। সবকিছু সরাসরি আপনার ব্যক্তিগত গুগল ড্রাইভে সম্পূর্ণ সুরক্ষিত থাকে।
              </p>
            </div>
          </div>
        </div>

        {/* Right Column (1 span): Manual Export & Restore */}
        <div className="space-y-6">
          
          {/* Download JSON Backup */}
          <div className="bg-white border-2 border-rose-100 rounded-3xl p-6 shadow-md space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-rose-50 text-rose-800 border border-rose-200">
                <HardDrive className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-sm text-rose-950">অফলাইন ব্যাকআপ ফাইল</h3>
                <p className="text-xs text-slate-500">আপনার মোবাইল বা পেনড্রাইভে কপি রাখুন</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              একটি ক্লিকেই সব সদস্যের প্রোফাইল, প্রেসক্রিপশন ও ডকুমেন্টের তথ্য <code className="text-rose-900 font-bold">.json</code> ফাইল আকারে ডাউনলোড করুন।
            </p>

            <button
              onClick={handleDownloadBackup}
              disabled={isExporting}
              className="w-full py-3 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
            >
              <Download className="w-4 h-4" />
              {isExporting ? 'তৈরি হচ্ছে...' : 'অফলাইন ব্যাকআপ ডাউনলোড (.json)'}
            </button>
          </div>

          {/* Restore / Import Backup */}
          <div className="bg-white border-2 border-rose-100 rounded-3xl p-6 shadow-md space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-3 rounded-2xl bg-rose-50 text-rose-800 border border-rose-200">
                <Upload className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-sm text-rose-950">ব্যাকআপ ফাইল থেকে রিস্টোর</h3>
                <p className="text-xs text-slate-500">আগের ফাইল থেকে তথ্য ফেরত আনুন</p>
              </div>
            </div>

            {restoreSuccess && (
              <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                ভল্ট সফলভাবে রিস্টোর হয়েছে!
              </div>
            )}

            <label className="w-full py-3 px-4 rounded-xl bg-stone-100 hover:bg-stone-200 text-rose-950 font-bold text-xs border border-rose-200 flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-sm">
              <Upload className="w-4 h-4 text-rose-900" />
              <span>ব্যাকআপ ফাইল নির্বাচন করুন (.json)</span>
              <input
                type="file"
                accept=".json"
                onChange={handleRestoreFile}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>
    </div>
  );
};
