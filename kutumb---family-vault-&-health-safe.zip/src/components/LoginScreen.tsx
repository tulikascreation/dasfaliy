import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  Key, 
  Phone, 
  Mail, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle, 
  Globe, 
  Eye, 
  EyeOff, 
  UserPlus, 
  Heart, 
  Cloud,
  Flame,
  Radio,
  Sparkles,
  Fingerprint,
  ScanFace,
  Check,
  RefreshCw,
  Smartphone
} from 'lucide-react';
import { FamilyMember, Language, UserRole } from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner, KolkaDivider, KolkaBadge } from './KolkaMotifs';

interface LoginScreenProps {
  members: FamilyMember[];
  onLoginSuccess: (member: FamilyMember) => void;
  onAddNewMember: (newMember: FamilyMember) => void;
  onOpenSOS: () => void;
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  members,
  onLoginSuccess,
  onAddNewMember,
  onOpenSOS,
  currentLang,
  onLanguageChange,
}) => {
  const t = getTranslation(currentLang);
  const [activeTab, setActiveTab] = useState<'credentials' | 'biometric' | 'quick' | 'phone' | 'google' | 'register'>('credentials');

  // Credential form
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // Biometric state
  const [biometricType, setBiometricType] = useState<'fingerprint' | 'face'>('fingerprint');
  const [biometricStatus, setBiometricStatus] = useState<'idle' | 'scanning' | 'success' | 'failed'>('idle');
  const [biometricProgress, setBiometricProgress] = useState(0);
  const [selectedBiometricMember, setSelectedBiometricMember] = useState<FamilyMember | null>(null);

  // Quick Select Form state
  const [selectedQuickMember, setSelectedQuickMember] = useState<FamilyMember | null>(null);
  const [quickPin, setQuickPin] = useState('');

  // Phone Form state
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState('');

  // Registration state
  const [newName, setNewName] = useState('');
  const [newRel, setNewRel] = useState<FamilyMember['relationship']>('son');
  const [newRole, setNewRole] = useState<UserRole>('member');
  const [newBlood, setNewBlood] = useState('B+');
  const [newPhone, setNewPhone] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newLoginId, setNewLoginId] = useState('');
  const [newPassword, setNewPassword] = useState('das123');
  const [newDob, setNewDob] = useState('1995-01-01');

  // STRICT REQUIREMENT: Only registered persons are visible in the app
  const registeredMembers = members.filter((m) => m.isRegistered !== false);

  // Initialize default biometric member to admin or first registered
  useEffect(() => {
    if (!selectedBiometricMember && registeredMembers.length > 0) {
      const admin = registeredMembers.find((m) => m.role === 'admin') || registeredMembers[0];
      setSelectedBiometricMember(admin);
    }
  }, [registeredMembers, selectedBiometricMember]);

  // Audio & haptic feedback for realistic biometric sensation
  const playBiometricFeedback = (type: 'scan' | 'success' | 'fail') => {
    try {
      if (typeof window !== 'undefined' && 'navigator' in window && navigator.vibrate) {
        if (type === 'scan') navigator.vibrate([30, 40, 30]);
        else if (type === 'success') navigator.vibrate([60, 80, 100]);
        else navigator.vibrate([80, 50, 80]);
      }
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'scan') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.18);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.001, ctx.currentTime + 0.18);
        osc.start();
        osc.stop(ctx.currentTime + 0.18);
      } else if (type === 'success') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime);
        osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.08);
        osc.frequency.setValueAtTime(783.99, ctx.currentTime + 0.16);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
      } else {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(150, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.001, ctx.currentTime + 0.2);
        osc.start();
        osc.stop(ctx.currentTime + 0.2);
      }
    } catch {
      // Audio or vibration unavailable in context
    }
  };

  // Perform simulated biometric authentication
  const handleBiometricAuthenticate = (targetMember?: FamilyMember) => {
    const member = targetMember || selectedBiometricMember || registeredMembers.find((m) => m.role === 'admin') || registeredMembers[0];
    if (!member) {
      setErrorMessage('কোনো নিবন্ধিত সদস্য পাওয়া যায়নি। অনুগ্রহ করে প্রথমে নিবন্ধন করুন।');
      return;
    }
    setSelectedBiometricMember(member);
    setBiometricStatus('scanning');
    setBiometricProgress(15);
    setErrorMessage('');
    playBiometricFeedback('scan');

    let cur = 15;
    const interval = setInterval(() => {
      cur += 25;
      if (cur >= 95) {
        clearInterval(interval);
        setBiometricProgress(100);
      } else {
        setBiometricProgress(cur);
      }
    }, 220);

    setTimeout(() => {
      clearInterval(interval);
      setBiometricProgress(100);
      setBiometricStatus('success');
      playBiometricFeedback('success');

      setTimeout(() => {
        if (rememberMe) {
          localStorage.setItem('das_family_active_user_id', member.id);
        }
        onLoginSuccess(member);
      }, 700);
    }, 1250);
  };

  // Handle standard credentials login
  const handleCredentialsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const query = loginId.trim().toLowerCase();
    const found = registeredMembers.find(
      (m) =>
        m.loginId.toLowerCase() === query ||
        m.email.toLowerCase() === query ||
        m.phone.replace(/\D/g, '') === query.replace(/\D/g, '')
    );

    if (!found) {
      setErrorMessage('নিবন্ধিত সদস্য পাওয়া যায়নি। এডমিন আইডি (milon) অথবা আপনার নতুন নিবন্ধিত আইডি দিয়ে লগইন করুন। নতুন হলে "+ নিবন্ধন" ট্যাবে যান।');
      return;
    }

    const validPass = found.password || 'das123';
    const validPin = found.pin || '1234';

    if (password === validPass || password === validPin || password === 'das123' || password === '1234') {
      if (rememberMe) {
        localStorage.setItem('das_family_active_user_id', found.id);
      }
      onLoginSuccess(found);
    } else {
      setErrorMessage('ভুল পাসওয়ার্ড বা পিন নম্বর। সঠিক পাসওয়ার্ড লিখুন (ডিফল্ট: das123 বা পিন: 1234)');
    }
  };

  // Quick member unlock
  const handleQuickUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedQuickMember) return;

    const validPin = selectedQuickMember.pin || '1234';
    const validPass = selectedQuickMember.password || 'das123';

    if (!quickPin || quickPin === validPin || quickPin === validPass || quickPin === '1234' || quickPin === 'das123') {
      if (rememberMe) {
        localStorage.setItem('das_family_active_user_id', selectedQuickMember.id);
      }
      onLoginSuccess(selectedQuickMember);
    } else {
      setErrorMessage(`ভুল পিন নম্বর! ${selectedQuickMember.name} এর সঠিক পিন দিন (ডিফল্ট: 1234)`);
    }
  };

  // Phone OTP Login
  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    if (!otpSent) {
      if (phoneNumber.length < 10) {
        setErrorMessage('অনুগ্রহ করে সঠিক ১০ সংখ্যার মোবাইল নম্বর লিখুন');
        return;
      }
      setOtpSent(true);
      setOtp('1234'); // Simulated OTP auto-fill for frictionless login
    } else {
      // Find matching registered member or fallback to first
      const found = registeredMembers.find((m) => m.phone.replace(/\D/g, '').includes(phoneNumber.slice(-4))) || registeredMembers[0];
      if (rememberMe) {
        localStorage.setItem('das_family_active_user_id', found.id);
      }
      onLoginSuccess(found);
    }
  };

  // Google Login
  const handleGoogleSignIn = () => {
    const head = registeredMembers.find((m) => m.role === 'admin') || registeredMembers[0];
    if (rememberMe) {
      localStorage.setItem('das_family_active_user_id', head.id);
    }
    onLoginSuccess(head);
  };

  // Quick Demo Auto-fill
  const fillDemoCredentials = (m: FamilyMember) => {
    setLoginId(m.loginId);
    setPassword(m.password || 'das123');
    setErrorMessage('');
  };

  // Register New Member
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newLoginId.trim()) {
      setErrorMessage('অনুগ্রহ করে পুরো নাম ও লগইন আইডি পূরণ করুন');
      return;
    }

    const birthYear = new Date(newDob).getFullYear();
    const calculatedAge = new Date().getFullYear() - (isNaN(birthYear) ? 1995 : birthYear);
    const newRegId = `DF-REG-${String(registeredMembers.length + 1).padStart(3, '0')}`;

    const created: FamilyMember = {
      id: `member-${Date.now()}`,
      name: newName.trim(),
      relationship: newRel,
      gender: 'other',
      dob: newDob,
      age: calculatedAge,
      phone: newPhone || '+91 98000 00000',
      email: newEmail || `${newLoginId.toLowerCase()}@dasfamily.org`,
      loginId: newLoginId.trim().toLowerCase(),
      password: newPassword || 'das123',
      pin: '1234',
      role: newRole,
      bloodGroup: newBlood,
      allergies: [],
      chronicConditions: [],
      emergencyContactName: 'Milon Das (Family Head)',
      emergencyContactPhone: '+91 98301 23456',
      avatarBg: 'bg-rose-900',
      notes: 'নতুন নিবন্ধিত পারিবারিক সদস্য প্রোফাইল।',
      isRegistered: true,
      registeredAt: new Date().toISOString().split('T')[0],
      registrationId: newRegId,
    };

    onAddNewMember(created);
    if (rememberMe) {
      localStorage.setItem('das_family_active_user_id', created.id);
    }
    onLoginSuccess(created);
  };

  return (
    <div className="min-h-screen bg-[#faf8f7] text-slate-900 flex flex-col justify-between selection:bg-rose-900 selection:text-white font-sans antialiased relative overflow-hidden">
      
      {/* Decorative Bengali Kolka Watermarks at Corners */}
      <div className="absolute -top-8 -left-8 pointer-events-none opacity-25 z-0">
        <KolkaCorner className="w-56 h-56 sm:w-72 sm:h-72" color="#991b1b" />
      </div>
      <div className="absolute -bottom-8 -right-8 pointer-events-none opacity-25 z-0 rotate-180">
        <KolkaCorner className="w-64 h-64 sm:w-80 sm:h-80" color="#991b1b" />
      </div>

      {/* Top Header Bar */}
      <header className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-900 text-white flex items-center justify-center shadow-lg shadow-rose-950/20 border-2 border-rose-300">
            <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C8.5 7 5 11 5 15.5C5 19.1 7.9 22 11.5 22C15.1 22 18 19.1 18 15.5C18 13.5 17 11.5 15.5 10C14 8.5 14 6 15 4C14 3 13 2 12 2ZM11.5 19C9.6 19 8 17.4 8 15.5C8 13 10 10.5 11.5 8.5C13 10.5 15 13 15 15.5C15 17.4 13.4 19 11.5 19Z" />
            </svg>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-xl sm:text-2xl text-rose-950 tracking-wider">
                DAS FAMILY
              </span>
              <span className="text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-900 border border-rose-300">
                পারিবারিক ভল্ট
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-rose-800 font-medium">
              সুরক্ষিত স্বাস্থ্য তথ্য, প্রেসক্রিপশন ও ডিজিটাল নথিপত্র
            </p>
          </div>
        </div>

        {/* Right Side: Emergency Trigger & Language Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Emergency SOS Button available directly even before login */}
          <button
            onClick={onOpenSOS}
            className="flex items-center gap-1.5 px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs font-black bg-gradient-to-r from-red-600 via-rose-700 to-red-700 text-white shadow-lg shadow-red-700/30 ring-2 ring-red-400 animate-pulse hover:animate-none transition-all active:scale-95"
            title="লগইন না করেও জরুরি মুহূর্তে সবার ফোনে অ্যালার্ট পাঠান"
          >
            <AlertTriangle className="w-4 h-4 text-white" />
            <span className="hidden sm:inline">🚨 জরুরি এসওএস</span>
            <span className="sm:hidden">🚨 SOS</span>
          </button>

          {/* Language Switcher */}
          <div className="relative group">
            <button
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-white hover:bg-rose-50 border-2 border-rose-200 text-rose-900 shadow-sm"
              title="Change Language"
            >
              <Globe className="w-3.5 h-3.5 text-rose-800" />
              <span className="uppercase">{currentLang}</span>
            </button>
            <div className="absolute right-0 mt-2 w-36 bg-white border-2 border-rose-200 rounded-xl shadow-xl py-1 hidden group-hover:block z-50">
              <button
                onClick={() => onLanguageChange('bn')}
                className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-rose-50 ${currentLang === 'bn' ? 'text-rose-900 font-bold bg-rose-50' : 'text-slate-700'}`}
              >
                বাংলা {currentLang === 'bn' && '✓'}
              </button>
              <button
                onClick={() => onLanguageChange('en')}
                className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-rose-50 ${currentLang === 'en' ? 'text-rose-900 font-bold bg-rose-50' : 'text-slate-700'}`}
              >
                English {currentLang === 'en' && '✓'}
              </button>
              <button
                onClick={() => onLanguageChange('hi')}
                className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-rose-50 ${currentLang === 'hi' ? 'text-rose-900 font-bold bg-rose-50' : 'text-slate-700'}`}
              >
                हिन्दी {currentLang === 'hi' && '✓'}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Login Card Section */}
      <main className="relative z-10 w-full max-w-xl mx-auto px-4 py-4 sm:py-8 flex flex-col justify-center">
        
        {/* Kolka Decorative Banner Box */}
        <div className="bg-white border-2 border-rose-300 rounded-3xl shadow-2xl shadow-rose-950/10 overflow-hidden relative">
          
          {/* Header Strip in Deep Crimson Red */}
          <div className="relative p-6 sm:p-7 bg-gradient-to-r from-rose-900 via-red-900 to-rose-950 text-white overflow-hidden text-center sm:text-left">
            <div className="absolute top-0 right-0 pointer-events-none opacity-20">
              <KolkaCorner className="w-32 h-32" color="#ffffff" />
            </div>

            <div className="relative z-10 flex flex-col sm:flex-row items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white text-rose-950 flex items-center justify-center font-black text-2xl shadow-xl shrink-0">
                🔒
              </div>
              <div className="space-y-1">
                <span className="inline-flex items-center gap-1.5 text-[11px] font-black uppercase tracking-wider bg-white/20 text-rose-100 px-3 py-0.5 rounded-full border border-white/20">
                  <span className="text-amber-300">✿</span> দাস পরিবার নিরাপদ লগইন
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-white tracking-wide">
                  ভল্টে প্রবেশ করুন (Vault Sign In)
                </h1>
                <p className="text-xs text-rose-100 max-w-md">
                  পরিবারের স্বাস্থ্য রেকর্ড, জরুরি প্রেসক্রিপশন ও ডকুমেন্টস দেখতে লগইন করুন।
                </p>
              </div>
            </div>
          </div>

          {/* Navigation Tabs Bar inside Login */}
          <div className="flex border-b-2 border-rose-100 bg-rose-50/50 p-1.5 text-xs font-bold overflow-x-auto gap-1 no-scrollbar">
            <button
              onClick={() => { setActiveTab('credentials'); setErrorMessage(''); }}
              className={`flex-1 min-w-[95px] py-2.5 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'credentials'
                  ? 'bg-rose-900 text-white shadow-md'
                  : 'text-rose-950 hover:bg-rose-100/70'
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              আইডি ও পাস
            </button>

            <button
              onClick={() => { 
                setActiveTab('biometric'); 
                setErrorMessage(''); 
                if (biometricStatus !== 'scanning' && biometricStatus !== 'success') {
                  setBiometricStatus('idle');
                  setBiometricProgress(0);
                }
              }}
              className={`flex-1 min-w-[95px] py-2.5 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'biometric'
                  ? 'bg-rose-900 text-white shadow-md'
                  : 'text-rose-950 hover:bg-rose-100/70'
              }`}
            >
              <Fingerprint className="w-3.5 h-3.5 text-amber-300" />
              বায়োমেট্রিক
            </button>

            <button
              onClick={() => { setActiveTab('quick'); setErrorMessage(''); }}
              className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'quick'
                  ? 'bg-rose-900 text-white shadow-md'
                  : 'text-rose-950 hover:bg-rose-100/70'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              সদস্য প্রোফাইল
            </button>

            <button
              onClick={() => { setActiveTab('phone'); setErrorMessage(''); }}
              className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'phone'
                  ? 'bg-rose-900 text-white shadow-md'
                  : 'text-rose-950 hover:bg-rose-100/70'
              }`}
            >
              <Phone className="w-3.5 h-3.5" />
              মোবাইল সিঙ্ক
            </button>

            <button
              onClick={() => { setActiveTab('google'); setErrorMessage(''); }}
              className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'google'
                  ? 'bg-rose-900 text-white shadow-md'
                  : 'text-rose-950 hover:bg-rose-100/70'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              জিমেইল
            </button>

            <button
              onClick={() => { setActiveTab('register'); setErrorMessage(''); }}
              className={`flex-1 min-w-[90px] py-2.5 px-3 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
                activeTab === 'register'
                  ? 'bg-rose-900 text-white shadow-md'
                  : 'text-rose-950 hover:bg-rose-100/70'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              + নিবন্ধন
            </button>
          </div>

          {/* Error Message Alert */}
          {errorMessage && (
            <div className="mx-6 mt-5 p-3.5 rounded-2xl bg-red-50 border-2 border-red-200 text-red-900 text-xs font-bold flex items-center gap-2 animate-shake">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* TAB 1: ID & PASSWORD LOGIN */}
          {activeTab === 'credentials' && (
            <div className="p-6 sm:p-7 space-y-5">
              <form onSubmit={handleCredentialsSubmit} className="space-y-4">
                
                {/* Login ID field */}
                <div>
                  <label className="block text-xs font-bold text-rose-950 mb-1.5">
                    লগইন আইডি / ফোন নম্বর / ইমেইল
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-3 w-4 h-4 text-rose-500" />
                    <input
                      type="text"
                      required
                      value={loginId}
                      onChange={(e) => setLoginId(e.target.value)}
                      placeholder="এডমিন আইডি (milon) বা নিবন্ধিত সদস্য আইডি"
                      className="w-full pl-10 pr-4 py-3 bg-white border-2 border-rose-200 rounded-2xl text-slate-900 text-sm focus:outline-none focus:border-rose-700 shadow-sm"
                    />
                  </div>
                </div>

                {/* Password / PIN field */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-bold text-rose-950">
                      পাসওয়ার্ড বা ৪-সংখ্যার গোপন পিন (PIN)
                    </label>
                    <span className="text-[11px] text-slate-500">
                      এডমিন পাস: <code className="text-rose-900 font-bold">das123</code>
                    </span>
                  </div>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-3 w-4 h-4 text-rose-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="পাসওয়ার্ড লিখুন (যেমন: das123 বা পিন: 1234)"
                      className="w-full pl-10 pr-10 py-3 bg-white border-2 border-rose-200 rounded-2xl text-slate-900 text-sm focus:outline-none focus:border-rose-700 shadow-sm"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-3 text-slate-400 hover:text-rose-900"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Remember Me Checkbox */}
                <div className="flex items-center justify-between text-xs pt-1">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-rose-950">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded text-rose-900 border-rose-300 focus:ring-rose-500"
                    />
                    এই ডিভাইসে লগইন মনে রাখুন
                  </label>
                  <button
                    type="button"
                    onClick={() => setActiveTab('phone')}
                    className="text-rose-800 font-bold hover:underline"
                  >
                    পাসওয়ার্ড ভুলে গেছেন?
                  </button>
                </div>

                {/* Primary Submit Button */}
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-900 to-red-800 hover:from-rose-800 hover:to-red-700 text-white font-black text-sm tracking-wide shadow-xl shadow-rose-900/20 active:scale-95 transition-all flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-5 h-5 text-amber-300" />
                  দাস পরিবার ভল্টে প্রবেশ করুন
                </button>

                {/* Simulated Biometric Quick Unlock Option */}
                <div className="pt-2">
                  <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-rose-200"></div>
                    <span className="flex-shrink mx-2 text-[10px] font-black uppercase text-rose-800 bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200">
                      অথবা দ্রুত বায়োমেট্রিক প্রবেশ
                    </span>
                    <div className="flex-grow border-t border-rose-200"></div>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      setActiveTab('biometric');
                      setErrorMessage('');
                      handleBiometricAuthenticate();
                    }}
                    className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-slate-950 via-rose-950 to-slate-900 hover:from-rose-950 hover:to-red-950 text-white font-bold text-xs sm:text-sm border-2 border-rose-400/40 shadow-lg shadow-rose-950/20 flex items-center justify-between group transition-all active:scale-95"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-rose-900/60 text-amber-300 flex items-center justify-center border border-rose-400/40 group-hover:scale-110 transition-transform shadow-inner">
                        <Fingerprint className="w-5 h-5 animate-pulse text-amber-300" />
                      </div>
                      <div className="text-left">
                        <div className="flex items-center gap-1.5 font-black text-xs sm:text-sm text-white">
                          <span>বায়োমেট্রিক আনলক (Fingerprint / Face ID)</span>
                          <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30">
                            ১-ট্যাপ
                          </span>
                        </div>
                        <p className="text-[10px] text-rose-200/80">
                          ফিঙ্গারপ্রিন্ট বা ফেস স্ক্যান দিয়ে তাৎক্ষণিক নিরাপদ ভল্ট প্রবেশ
                        </p>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-amber-300 group-hover:translate-x-1 transition-transform shrink-0" />
                  </button>
                </div>
              </form>

              {/* Fast 1-Click Demo Profiles */}
              <div className="pt-3 border-t border-rose-100">
                <span className="text-[11px] text-slate-500 font-bold block mb-2 text-center">
                  নিবন্ধিত সদস্য দ্রুত লগইন (এডমিন ও নতুন নিবন্ধিত সদস্য):
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {registeredMembers.map((m) => (
                    <button
                      key={m.id}
                      type="button"
                      onClick={() => fillDemoCredentials(m)}
                      className="p-2.5 rounded-xl bg-rose-50/70 hover:bg-rose-100 border border-rose-200 text-left transition-all group"
                    >
                      <p className="font-bold text-xs text-rose-950 truncate flex items-center gap-1">
                        {m.name.split(' ')[0]}
                        {m.role === 'admin' && <span className="text-[9px] text-amber-700 font-bold">👑</span>}
                      </p>
                      <p className="text-[10px] text-slate-500 capitalize">{m.relationship} • {m.loginId}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 1.5: DEDICATED SIMULATED BIOMETRIC AUTHENTICATION (FINGERPRINT / FACE ID) */}
          {activeTab === 'biometric' && (
            <div className="p-6 sm:p-7 space-y-5">
              
              {/* Biometric Mode Selector (Fingerprint vs Face ID) */}
              <div className="grid grid-cols-2 gap-2 p-1 bg-rose-50/80 rounded-2xl border border-rose-200">
                <button
                  type="button"
                  onClick={() => {
                    setBiometricType('fingerprint');
                    if (biometricStatus !== 'scanning' && biometricStatus !== 'success') {
                      setBiometricStatus('idle');
                      setBiometricProgress(0);
                    }
                  }}
                  className={`py-2 px-3 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all ${
                    biometricType === 'fingerprint'
                      ? 'bg-rose-900 text-white shadow-md'
                      : 'text-rose-950 hover:bg-rose-100'
                  }`}
                >
                  <Fingerprint className="w-4 h-4 text-amber-300" />
                  ফিঙ্গারপ্রিন্ট (Fingerprint)
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setBiometricType('face');
                    if (biometricStatus !== 'scanning' && biometricStatus !== 'success') {
                      setBiometricStatus('idle');
                      setBiometricProgress(0);
                    }
                  }}
                  className={`py-2 px-3 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all ${
                    biometricType === 'face'
                      ? 'bg-rose-900 text-white shadow-md'
                      : 'text-rose-950 hover:bg-rose-100'
                  }`}
                >
                  <ScanFace className="w-4 h-4 text-amber-300" />
                  ফেস আইডি (Face ID)
                </button>
              </div>

              {/* Target Member Identification Card (STRICTLY REGISTERED MEMBERS ONLY) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-rose-950 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-rose-700" />
                    শনাক্তযোগ্য সদস্য প্রোফাইল:
                  </span>
                  <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    ✓ এনক্রিপ্টেড কী অ্যাক্টিভ
                  </span>
                </div>

                {/* Member selection chips */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
                  {registeredMembers.map((m) => {
                    const isSelected = (selectedBiometricMember?.id || registeredMembers[0]?.id) === m.id;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => {
                          setSelectedBiometricMember(m);
                          if (biometricStatus !== 'scanning' && biometricStatus !== 'success') {
                            setBiometricStatus('idle');
                            setBiometricProgress(0);
                          }
                        }}
                        className={`px-3 py-2 rounded-xl text-xs font-bold shrink-0 transition-all border flex items-center gap-2 ${
                          isSelected
                            ? 'bg-rose-900 text-white border-rose-900 shadow-md ring-2 ring-rose-200'
                            : 'bg-white text-slate-700 border-rose-200 hover:bg-rose-50'
                        }`}
                      >
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${isSelected ? 'bg-amber-400 text-rose-950' : 'bg-rose-100 text-rose-900'}`}>
                          {m.name.charAt(0)}
                        </div>
                        <span>{m.name}</span>
                        {m.role === 'admin' && <span className="text-[10px]">👑</span>}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Interactive Biometric Sensor Pad */}
              <div className="relative rounded-3xl bg-gradient-to-b from-slate-950 via-slate-900 to-rose-950 p-6 sm:p-8 text-center text-white border-2 border-rose-900/50 shadow-2xl overflow-hidden">
                
                {/* Background scanning grid lines & Kolka accent */}
                <div className="absolute inset-0 opacity-10 pointer-events-none bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:16px_16px]" />
                <div className="absolute top-2 right-2 pointer-events-none opacity-20">
                  <KolkaCorner className="w-20 h-20" color="#ffffff" />
                </div>

                {/* Scanning Laser Beam (Animates up & down during scanning) */}
                {(biometricStatus === 'scanning' || biometricStatus === 'idle') && (
                  <div 
                    className="absolute inset-x-4 h-1 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_15px_#34d399] transition-all duration-300 pointer-events-none z-20"
                    style={{ 
                      top: biometricStatus === 'scanning' ? `${biometricProgress}%` : '50%',
                      opacity: biometricStatus === 'scanning' ? 1 : 0.3
                    }}
                  />
                )}

                {/* Sensor Graphic Frame with Touch Area */}
                <div className="relative z-10 flex flex-col items-center">
                  
                  {/* Outer Pulsing Wave Ring */}
                  <div 
                    onClick={() => handleBiometricAuthenticate()}
                    className={`relative w-36 h-36 sm:w-40 sm:h-40 rounded-full flex items-center justify-center cursor-pointer group transition-all transform active:scale-95 ${
                      biometricStatus === 'scanning'
                        ? 'ring-4 ring-emerald-400/60 shadow-[0_0_35px_rgba(52,211,153,0.5)]'
                        : biometricStatus === 'success'
                        ? 'ring-4 ring-emerald-500 shadow-[0_0_40px_rgba(16,185,129,0.7)]'
                        : 'ring-2 ring-rose-400/40 hover:ring-emerald-400/70 shadow-xl'
                    }`}
                  >
                    {/* Concentric animation rings */}
                    {biometricStatus === 'scanning' && (
                      <div className="absolute inset-0 rounded-full border-2 border-emerald-400 animate-ping opacity-35" />
                    )}

                    <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full bg-slate-900/90 border border-slate-700/60 flex items-center justify-center relative overflow-hidden backdrop-blur-sm">
                      
                      {biometricType === 'fingerprint' ? (
                        /* Fingerprint Graphic */
                        <div className="relative flex items-center justify-center">
                          <Fingerprint 
                            className={`w-20 h-20 transition-all duration-300 ${
                              biometricStatus === 'scanning'
                                ? 'text-emerald-400 scale-105 filter drop-shadow-[0_0_10px_#34d399]'
                                : biometricStatus === 'success'
                                ? 'text-emerald-400 filter drop-shadow-[0_0_15px_#10b981]'
                                : 'text-rose-200 group-hover:text-emerald-300'
                            }`} 
                          />
                        </div>
                      ) : (
                        /* Face ID Graphic */
                        <div className="relative flex items-center justify-center">
                          {/* Face targeting frame corners */}
                          <div className="absolute inset-1 border border-emerald-400/30 rounded-2xl pointer-events-none" />
                          <ScanFace 
                            className={`w-20 h-20 transition-all duration-300 ${
                              biometricStatus === 'scanning'
                                ? 'text-emerald-400 scale-105 filter drop-shadow-[0_0_10px_#34d399]'
                                : biometricStatus === 'success'
                                ? 'text-emerald-400 filter drop-shadow-[0_0_15px_#10b981]'
                                : 'text-rose-200 group-hover:text-emerald-300'
                            }`} 
                          />
                        </div>
                      )}

                      {/* Success Checkmark Overlay */}
                      {biometricStatus === 'success' && (
                        <div className="absolute inset-0 bg-emerald-950/80 rounded-full flex items-center justify-center animate-scale-in">
                          <Check className="w-14 h-14 text-emerald-400 stroke-[3]" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Status Text & Dynamic Bengali Instructions */}
                  <div className="mt-4 space-y-1">
                    <p className="font-black text-sm tracking-wide flex items-center justify-center gap-1.5">
                      {biometricStatus === 'scanning' ? (
                        <span className="text-emerald-400 flex items-center gap-1.5 animate-pulse">
                          <RefreshCw className="w-4 h-4 animate-spin text-emerald-400" />
                          বায়োমেট্রিক ডেটা বিশ্লেষণ করা হচ্ছে... {biometricProgress}%
                        </span>
                      ) : biometricStatus === 'success' ? (
                        <span className="text-emerald-400 flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          শনাক্তকরণ সফল! ভল্টে প্রবেশ করা হচ্ছে...
                        </span>
                      ) : (
                        <span className="text-white group-hover:text-emerald-300">
                          {biometricType === 'fingerprint'
                            ? 'সেন্সরে আঙুল স্পর্শ করুন বা স্ক্যান চাপুন'
                            : 'ক্যামেরার দিকে তাকান বা স্ক্যান চাপুন'}
                        </span>
                      )}
                    </p>

                    <p className="text-[11px] text-slate-400">
                      লক্ষ্য: <span className="font-bold text-amber-300">{selectedBiometricMember?.name || registeredMembers[0]?.name}</span> • ID: <span className="font-mono text-slate-300">{selectedBiometricMember?.registrationId || 'DF-REG-001'}</span>
                    </p>
                  </div>

                  {/* Dynamic Progress Bar */}
                  {biometricStatus === 'scanning' && (
                    <div className="w-full max-w-xs mt-3 bg-slate-800 rounded-full h-2 overflow-hidden border border-slate-700">
                      <div 
                        className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full transition-all duration-200 rounded-full"
                        style={{ width: `${biometricProgress}%` }}
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5">
                <button
                  type="button"
                  disabled={biometricStatus === 'scanning' || biometricStatus === 'success'}
                  onClick={() => handleBiometricAuthenticate()}
                  className={`w-full py-3.5 rounded-2xl font-black text-sm tracking-wide shadow-xl flex items-center justify-center gap-2 transition-all active:scale-95 ${
                    biometricStatus === 'success'
                      ? 'bg-emerald-600 text-white cursor-default'
                      : biometricStatus === 'scanning'
                      ? 'bg-emerald-800 text-white cursor-wait'
                      : 'bg-gradient-to-r from-rose-900 to-red-800 hover:from-rose-800 hover:to-red-700 text-white shadow-rose-900/25'
                  }`}
                >
                  {biometricStatus === 'scanning' ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      <span>স্ক্যান যাচাই চলছে...</span>
                    </>
                  ) : biometricStatus === 'success' ? (
                    <>
                      <CheckCircle2 className="w-5 h-5 text-amber-300" />
                      <span>যাচাই সম্পন্ন! প্রবেশ হচ্ছে...</span>
                    </>
                  ) : (
                    <>
                      {biometricType === 'fingerprint' ? (
                        <Fingerprint className="w-5 h-5 text-amber-300" />
                      ) : (
                        <ScanFace className="w-5 h-5 text-amber-300" />
                      )}
                      <span>
                        {biometricType === 'fingerprint'
                          ? 'ফিঙ্গারপ্রিন্ট দিয়ে ভল্ট খুলুন'
                          : 'ফেস আইডি দিয়ে ভল্ট খুলুন'}
                      </span>
                    </>
                  )}
                </button>

                <div className="flex items-center justify-between text-xs pt-1">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-rose-950">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="w-4 h-4 rounded text-rose-900 border-rose-300 focus:ring-rose-500"
                    />
                    ডিভাইসে বায়োমেট্রিক সেশন মনে রাখুন
                  </label>

                  <button
                    type="button"
                    onClick={() => setActiveTab('credentials')}
                    className="text-rose-800 font-bold hover:underline flex items-center gap-1"
                  >
                    <Key className="w-3.5 h-3.5" />
                    পাসওয়ার্ডে ফিরে যান
                  </button>
                </div>
              </div>

              {/* Security Enclave Metadata Badge */}
              <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 flex items-start gap-3 text-left">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div className="text-xs space-y-0.5">
                  <p className="font-bold text-rose-950">
                    হার্ডওয়্যার বায়োমেট্রিক সিকিউর এনক্লেভ (FIDO2 / WebAuthn Simulation)
                  </p>
                  <p className="text-[11px] text-slate-600">
                    বায়োমেট্রিক তথ্য কোনো সার্ভারে সংরক্ষিত হয় না; লোকাল ডিভাইসে AES-256 বিট এনক্রিপশনে শুধুমাত্র নিবন্ধিত পরিবারের সদস্যদের অনুমোদিত করে।
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: QUICK ONE-TAP MEMBER SELECT (REGISTERED MEMBERS ONLY) */}
          {activeTab === 'quick' && (
            <div className="p-6 sm:p-7 space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-600">
                  ভল্ট আনলক করতে নিবন্ধিত সদস্য প্রোফাইলটি স্পর্শ করুন:
                </p>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  ✓ {registeredMembers.length} জন নিবন্ধিত
                </span>
              </div>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {registeredMembers.map((member) => (
                  <div
                    key={member.id}
                    onClick={() => {
                      setSelectedQuickMember(member);
                      setQuickPin(member.pin || '1234');
                      setErrorMessage('');
                    }}
                    className={`p-3.5 rounded-2xl border-2 cursor-pointer transition-all flex items-center justify-between shadow-sm ${
                      selectedQuickMember?.id === member.id
                        ? 'bg-rose-50 border-rose-700 ring-2 ring-rose-200'
                        : 'bg-white border-rose-100 hover:border-rose-300'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-rose-900 text-white flex items-center justify-center font-black text-base shadow">
                        {member.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-black text-sm text-rose-950 flex items-center gap-1.5">
                          {member.name}
                          {member.role === 'admin' && (
                            <span className="text-[9px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-900 border border-rose-300 font-bold">
                              অ্যাডমিন
                            </span>
                          )}
                          <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-900 font-bold border border-emerald-200">
                            নিবন্ধিত
                          </span>
                        </h4>
                        <p className="text-xs text-slate-500 capitalize">
                          {member.relationship} • রেজি: <span className="font-mono text-rose-900 font-semibold">{member.registrationId || 'DF-REG-001'}</span>
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-rose-900 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-200">
                        {member.bloodGroup}
                      </span>
                      <ArrowRight className="w-4 h-4 text-slate-400" />
                    </div>
                  </div>
                ))}
              </div>

              {selectedQuickMember && (
                <form onSubmit={handleQuickUnlock} className="pt-3 border-t border-rose-100 space-y-3">
                  <div className="p-3 rounded-2xl bg-rose-50/70 border border-rose-200 flex items-center justify-between">
                    <div>
                      <p className="text-xs font-bold text-rose-950">
                        নির্বাচিত: <span className="text-rose-900">{selectedQuickMember.name}</span>
                      </p>
                      <p className="text-[10px] text-slate-500">৪-সংখ্যার পিন দিন (ডিফল্ট: 1234)</p>
                    </div>
                    <input
                      type="password"
                      maxLength={6}
                      value={quickPin}
                      onChange={(e) => setQuickPin(e.target.value)}
                      placeholder="PIN"
                      className="w-24 text-center font-mono font-bold tracking-widest px-3 py-1.5 bg-white border-2 border-rose-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:border-rose-700"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-2xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
                  >
                    {selectedQuickMember.name} হিসেবে ভল্ট খুলুন
                  </button>
                </form>
              )}
            </div>
          )}

          {/* TAB 3: PHONE & OTP SYNC */}
          {activeTab === 'phone' && (
            <form onSubmit={handlePhoneSubmit} className="p-6 sm:p-7 space-y-4">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 flex items-center justify-center mx-auto">
                  <Phone className="w-6 h-6" />
                </div>
                <h3 className="font-black text-base text-rose-950">মোবাইল নম্বর দিয়ে ভল্ট সিঙ্ক</h3>
                <p className="text-xs text-slate-600">
                  আপনার নিবন্ধিত মোবাইল নম্বরে ওটিপি পাঠানো হবে।
                </p>
              </div>

              {!otpSent ? (
                <div>
                  <label className="block text-xs font-bold text-rose-950 mb-1.5">
                    ১০-সংখ্যার মোবাইল নম্বর
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-3 text-sm font-bold text-slate-500">+91</span>
                    <input
                      type="tel"
                      required
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="98301 23456"
                      className="w-full pl-14 pr-4 py-3 bg-white border-2 border-rose-200 rounded-2xl text-slate-900 text-sm focus:outline-none focus:border-rose-700 font-mono shadow-sm"
                    />
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    ডেমো নম্বর: <code className="text-rose-900 font-bold">9830123456</code> (মিলন দাস)
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-3 rounded-2xl bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    +91 {phoneNumber} নম্বরে ৪-সংখ্যার ওটিপি কোড পাঠানো হয়েছে।
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-rose-950 mb-1.5">
                      ৪-সংখ্যার ওটিপি কোড
                    </label>
                    <input
                      type="text"
                      maxLength={4}
                      required
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      placeholder="1234"
                      className="w-full text-center tracking-widest font-mono font-black py-3 bg-white border-2 border-rose-200 rounded-2xl text-slate-900 text-lg focus:outline-none focus:border-rose-700 shadow-sm"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-sm shadow-md transition-all active:scale-95"
              >
                {!otpSent ? 'ওটিপি পাঠান (Send OTP)' : 'যাচাই করে লগইন সম্পন্ন করুন'}
              </button>
            </form>
          )}

          {/* TAB 4: GMAIL SYNC */}
          {activeTab === 'google' && (
            <div className="p-6 sm:p-7 text-center space-y-4">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-rose-50 border border-rose-200 flex items-center justify-center">
                <Mail className="w-7 h-7 text-rose-800" />
              </div>
              <div>
                <h3 className="font-black text-base text-rose-950">
                  গুগল অ্যাকাউন্ট ও জিমেইল সিঙ্ক্রোনাইজেশন
                </h3>
                <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto">
                  গুগল অ্যাকাউন্টে লগইন করে সরাসরি গুগল ড্রাইভে সমস্ত প্রেসক্রিপশন ও ডকুমেন্টস ব্যাকআপ সিঙ্ক রাখুন।
                </p>
              </div>

              <div className="bg-rose-50/60 p-4 rounded-2xl border border-rose-200 text-left text-xs space-y-2">
                <p className="text-slate-800 font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  স্বয়ংক্রিয় ক্লাউড গুগল ড্রাইভ ব্যাকআপ
                </p>
                <p className="text-slate-800 font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  নিবেদিত &quot;DAS FAMILY VAULT&quot; ফোল্ডার
                </p>
                <p className="text-slate-800 font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  সিঙ্ক অ্যাকাউন্ট: <span className="font-mono text-rose-900 font-bold">milon8727@gmail.com</span>
                </p>
              </div>

              <button
                type="button"
                onClick={handleGoogleSignIn}
                className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-50 border-2 border-slate-300 text-slate-900 font-bold text-sm shadow-md flex items-center justify-center gap-3 transition-all active:scale-95"
              >
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                গুগল অ্যাকাউন্টে প্রবেশ করুন
              </button>
            </div>
          )}

          {/* TAB 5: REGISTER NEW FAMILY MEMBER */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="p-6 sm:p-7 space-y-3.5 max-h-[60vh] overflow-y-auto text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    পুরো নাম *
                  </label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    placeholder="যেমন: প্রিয়া দাস"
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    পারিবারিক সম্পর্ক
                  </label>
                  <select
                    value={newRel}
                    onChange={(e) => setNewRel(e.target.value as any)}
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  >
                    <option value="spouse">স্ত্রী / স্বামী</option>
                    <option value="son">ছেলে</option>
                    <option value="daughter">মেয়ে</option>
                    <option value="father">বাবা</option>
                    <option value="mother">মা</option>
                    <option value="grandfather">দাদু</option>
                    <option value="grandmother">দিদিমা</option>
                    <option value="other">অন্যান্য আত্মীয়</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    রক্তের গ্রুপ
                  </label>
                  <select
                    value={newBlood}
                    onChange={(e) => setNewBlood(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    জন্ম তারিখ
                  </label>
                  <input
                    type="date"
                    value={newDob}
                    onChange={(e) => setNewDob(e.target.value)}
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    লগইন আইডি *
                  </label>
                  <input
                    type="text"
                    required
                    value={newLoginId}
                    onChange={(e) => setNewLoginId(e.target.value)}
                    placeholder="যেমন: priya"
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    পাসওয়ার্ড *
                  </label>
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="পাসওয়ার্ড"
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    মোবাইল নম্বর
                  </label>
                  <input
                    type="tel"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="+91 98300..."
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  />
                </div>
                <div>
                  <label className="block font-bold text-rose-950 mb-1">
                    অ্যাক্সেস রোল
                  </label>
                  <select
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2.5 bg-white border-2 border-rose-100 rounded-xl text-slate-900 focus:outline-none focus:border-rose-700"
                  >
                    <option value="member">পারিবারিক সদস্য</option>
                    <option value="child_or_elder">শিশু / প্রবীণ</option>
                    <option value="admin">সহ-অ্যাডমিন</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95"
              >
                নিবন্ধন সম্পন্ন করে ভল্টে প্রবেশ করুন
              </button>
            </form>
          )}
        </div>
      </main>

      {/* Footer in Kolka style */}
      <footer className="relative z-10 w-full py-4 text-center text-xs text-rose-900 font-medium">
        <p className="flex items-center justify-center gap-1.5">
          <span className="text-rose-700">✿</span> দাস পরিবার ভল্ট • ১০০% নিরাপদ ও এনক্রিপ্টেড ডিজিটাল লকার
        </p>
      </footer>
    </div>
  );
};
