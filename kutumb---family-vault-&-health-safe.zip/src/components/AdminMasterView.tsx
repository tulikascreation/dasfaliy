import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Users, 
  Lock, 
  Key, 
  Eye, 
  EyeOff, 
  Edit3, 
  Heart, 
  FileText, 
  Phone, 
  Mail, 
  AlertCircle, 
  CheckCircle2, 
  UserCheck, 
  ArrowRight,
  Stethoscope
} from 'lucide-react';
import { VaultState, FamilyMember, Language, UserRole } from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner, KolkaDivider } from './KolkaMotifs';

interface AdminMasterViewProps {
  state: VaultState;
  currentMember: FamilyMember;
  currentLang: Language;
  onSelectMember: (m: FamilyMember) => void;
  onUpdateMember: (m: FamilyMember) => void;
  onAddNewMember: (m: FamilyMember) => void;
  onOpenEditModal: (m: FamilyMember) => void;
}

export const AdminMasterView: React.FC<AdminMasterViewProps> = ({
  state,
  currentMember,
  currentLang,
  onSelectMember,
  onUpdateMember,
  onAddNewMember,
  onOpenEditModal,
}) => {
  const t = getTranslation(currentLang);
  const [revealedPasswords, setRevealedPasswords] = useState<Record<string, boolean>>({});
  const [selectedDossierMember, setSelectedDossierMember] = useState<FamilyMember | null>(null);
  const [roleChangeSuccess, setRoleChangeSuccess] = useState<string | null>(null);

  const isAdmin = currentMember.role === 'admin';
  // STRICT REQUIREMENT: Only registered persons are visible in the app
  const registeredMembers = state.members.filter((m) => m.isRegistered !== false);

  const togglePasswordReveal = (memberId: string) => {
    setRevealedPasswords((prev) => ({
      ...prev,
      [memberId]: !prev[memberId],
    }));
  };

  const handleRoleToggle = (member: FamilyMember, newRole: UserRole) => {
    const updated = { ...member, role: newRole };
    onUpdateMember(updated);
    setRoleChangeSuccess(`Role updated to ${newRole} for ${member.name}`);
    setTimeout(() => setRoleChangeSuccess(null), 3000);
  };

  if (!isAdmin) {
    return (
      <div className="bg-white border-2 border-red-300 rounded-3xl p-8 text-center space-y-4 max-w-lg mx-auto my-12 shadow-xl">
        <div className="w-16 h-16 rounded-3xl bg-red-50 border border-red-200 text-red-700 flex items-center justify-center mx-auto">
          <Lock className="w-8 h-8" />
        </div>
        <div>
          <h3 className="font-black text-xl text-rose-950">অ্যাডমিন মাস্টার অ্যাক্সেস সীমাবদ্ধ</h3>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            {t.onlyAdminAccess}। বর্তমানে লগইন আছেন <span className="font-bold text-rose-900">{currentMember.name}</span> হিসেবে।
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Admin Master Header Banner in Kolka Style */}
      <div className="relative overflow-hidden rounded-3xl bg-white border-2 border-rose-300 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 pointer-events-none opacity-40">
          <KolkaCorner className="w-32 h-32" color="#991b1b" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-100 border border-rose-300 text-rose-950 text-xs font-black uppercase tracking-wider">
              👑 {t.adminBadge} - সম্পূর্ণ পারিবারিক নিয়ন্ত্রণ
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-rose-950 tracking-tight">
              দাস পরিবার মাস্টার অ্যাডমিন কন্ট্রোল প্যানেল
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl">
              ফ্যামিলি অ্যাডমিন হিসেবে আপনি পরিবারের সকল {state.members.length} জন সদস্যের পাসওয়ার্ড, গোপন পিন (PIN), মেডিকেল রেকর্ড ও লক করা ডকুমেন্টস দেখতে পারবেন।
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-right">
              <span className="text-[10px] text-slate-500 uppercase font-bold block">অ্যাডমিন প্রোফাইল</span>
              <span className="font-black text-sm text-rose-900">{currentMember.name}</span>
            </div>
          </div>
        </div>

        {roleChangeSuccess && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-300 text-emerald-800 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            {roleChangeSuccess}
          </div>
        )}
      </div>

      <KolkaDivider />

      {/* Master Members Full Detail Table (White with Deep Crimson Red Header) */}
      <div className="bg-white border-2 border-rose-200 rounded-3xl overflow-hidden shadow-xl">
        <div className="p-5 sm:p-6 border-b border-rose-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-black text-base sm:text-lg text-rose-950 flex items-center gap-2">
              <Users className="w-5 h-5 text-rose-800" />
              সকল সদস্যের পূর্ণ গোপনীয় তথ্য ভাণ্ডার (Admin Master Dossier)
            </h3>
            <p className="text-xs text-slate-500">
              সদস্যদের লগইন আইডি, পাসওয়ার্ড, পিন নম্বর, রক্তের গ্রুপ ও জরুরি ফোন নম্বর
            </p>
          </div>
          <span className="text-xs font-black text-rose-900 bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200">
            {registeredMembers.length} জন নিবন্ধিত সদস্যের প্রোফাইল
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-rose-900 text-white font-bold uppercase text-[10px] tracking-wider">
              <tr>
                <th className="p-4">নাম ও সম্পর্ক</th>
                <th className="p-4">লগইন আইডি ও পাসওয়ার্ড</th>
                <th className="p-4">৪-সংখ্যার পিন (PIN)</th>
                <th className="p-4">রক্তের গ্রুপ ও অ্যালার্জি</th>
                <th className="p-4">যোগাযোগ নম্বর</th>
                <th className="p-4">জরুরি যোগাযোগ</th>
                <th className="p-4 text-right">মাস্টার অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-rose-100">
              {registeredMembers.map((m) => {
                const isPassVisible = !!revealedPasswords[m.id];

                return (
                  <tr key={m.id} className="hover:bg-rose-50/50 transition-colors">
                    
                    {/* Name & Role */}
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-rose-900 text-white flex items-center justify-center text-sm font-black shadow">
                          {m.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-black text-sm text-rose-950">{m.name}</span>
                            {m.role === 'admin' && (
                              <span className="text-[9px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-900 font-black border border-rose-300">
                                অ্যাডমিন
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-500 capitalize font-medium">
                            {m.relationship} • {m.age} বছর ({m.gender})
                          </p>
                        </div>
                      </div>
                    </td>

                    {/* Login ID & Password */}
                    <td className="p-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-500 font-semibold">আইডি:</span>
                          <span className="font-mono text-rose-950 font-bold bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                            {m.loginId}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-500 font-semibold">পাস:</span>
                          <span className="font-mono text-rose-900 bg-stone-50 px-2 py-0.5 rounded border border-rose-100 font-bold">
                            {isPassVisible ? m.password || 'das123' : '••••••••'}
                          </span>
                          <button
                            onClick={() => togglePasswordReveal(m.id)}
                            className="text-slate-500 hover:text-rose-900 p-0.5"
                            title="Reveal Password"
                          >
                            {isPassVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </td>

                    {/* PIN */}
                    <td className="p-4">
                      <span className="font-mono font-black text-rose-900 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200">
                        {m.pin || '1234'}
                      </span>
                    </td>

                    {/* Blood & Allergies */}
                    <td className="p-4">
                      <div className="space-y-1">
                        <span className="inline-block px-2.5 py-0.5 rounded font-black text-xs bg-red-100 text-red-900 border border-red-200">
                          {m.bloodGroup}
                        </span>
                        {m.allergies.length > 0 ? (
                          <p className="text-[10px] text-red-700 truncate max-w-[130px] font-semibold">
                            ⚠️ {m.allergies.join(', ')}
                          </p>
                        ) : (
                          <p className="text-[10px] text-slate-400">অ্যালার্জি নেই</p>
                        )}
                      </div>
                    </td>

                    {/* Phone & Email */}
                    <td className="p-4 text-slate-700 space-y-0.5">
                      <div className="flex items-center gap-1.5 font-mono text-[11px] font-bold">
                        <Phone className="w-3 h-3 text-rose-700 shrink-0" />
                        <span className="truncate max-w-[120px]">{m.phone}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                        <Mail className="w-3 h-3 text-rose-700 shrink-0" />
                        <span className="truncate max-w-[140px]">{m.email}</span>
                      </div>
                    </td>

                    {/* Emergency Contact */}
                    <td className="p-4">
                      <p className="font-bold text-slate-900">{m.emergencyContactName}</p>
                      <p className="text-[11px] text-slate-500 font-mono">{m.emergencyContactPhone}</p>
                    </td>

                    {/* Action buttons */}
                    <td className="p-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => setSelectedDossierMember(m)}
                          className="px-2.5 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-950 text-xs font-bold border border-rose-200 flex items-center gap-1 transition-colors"
                          title="View Full Dossier"
                        >
                          <Eye className="w-3.5 h-3.5 text-rose-800" />
                          পূর্ণ তথ্য
                        </button>

                        <button
                          onClick={() => onOpenEditModal(m)}
                          className="p-1.5 rounded-xl bg-stone-100 hover:bg-rose-50 text-rose-900 text-xs border border-rose-200 transition-colors"
                          title="Edit Personal Information"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        {m.id !== currentMember.id && (
                          <button
                            onClick={() => onSelectMember(m)}
                            className="px-2.5 py-1.5 rounded-xl bg-rose-900 hover:bg-rose-800 text-white text-xs font-bold transition-colors shadow-sm"
                            title="Switch to this Member's Session"
                          >
                            সুইচ
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Member Full Dossier Modal */}
      {selectedDossierMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white border-2 border-rose-300 rounded-3xl shadow-2xl overflow-hidden my-6">
            
            <div className="p-5 sm:p-6 bg-gradient-to-r from-rose-900 to-red-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white text-rose-900 flex items-center justify-center text-xl font-black shadow-lg">
                  {selectedDossierMember.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-black text-lg text-white">
                    {selectedDossierMember.name} - পূর্ণ পারিবারিক ডসিয়ার
                  </h3>
                  <p className="text-xs text-rose-200">
                    ফ্যামিলি অ্যাডমিন মাস্টার অ্যাক্সেস
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedDossierMember(null)}
                className="text-white hover:text-rose-200 p-1"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto text-xs">
              {/* Credentials & Access */}
              <div className="p-4 rounded-2xl bg-rose-50/70 border border-rose-200 space-y-2">
                <h4 className="font-black text-rose-900 uppercase text-[10px] tracking-wider">লগইন ও পাসওয়ার্ড বিবরণ</h4>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <span className="text-slate-500 block text-[10px]">লগইন আইডি</span>
                    <span className="font-mono text-rose-950 font-black">{selectedDossierMember.loginId}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">পাসওয়ার্ড</span>
                    <span className="font-mono text-rose-900 font-black">{selectedDossierMember.password || 'das123'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">৪-সংখ্যার পিন</span>
                    <span className="font-mono text-rose-900 font-black">{selectedDossierMember.pin || '1234'}</span>
                  </div>
                </div>
              </div>

              {/* Personal & Medical Info */}
              <div className="p-4 rounded-2xl bg-stone-50 border border-rose-100 space-y-2">
                <h4 className="font-black text-rose-900 uppercase text-[10px] tracking-wider">স্বাস্থ্য পরিচয়</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-slate-500 block text-[10px]">রক্তের গ্রুপ</span>
                    <span className="font-black text-red-700 text-sm">{selectedDossierMember.bloodGroup}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">বীমা পলিসি নম্বর</span>
                    <span className="font-mono text-slate-800 font-bold">{selectedDossierMember.insurancePolicyNo || 'পারিবারিক ফ্লোটারের অন্তর্ভুক্ত'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">অ্যালার্জি</span>
                    <span className="text-red-700 font-bold">{selectedDossierMember.allergies.join(', ') || 'নেই'}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">শারীরিক সমস্যা</span>
                    <span className="text-amber-800 font-bold">{selectedDossierMember.chronicConditions.join(', ') || 'সুস্থ'}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-stone-50 border-t border-rose-100 flex justify-between">
              <button
                onClick={() => {
                  const m = selectedDossierMember;
                  setSelectedDossierMember(null);
                  onOpenEditModal(m);
                }}
                className="px-4 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs shadow"
              >
                প্রোফাইল পরিবর্তন করুন
              </button>

              <button
                onClick={() => setSelectedDossierMember(null)}
                className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-slate-800 text-xs font-bold"
              >
                বন্ধ করুন
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
