import React, { useState } from 'react';
import { X, Phone, AlertCircle, Heart, ShieldAlert, User, Check, Share2, Copy } from 'lucide-react';
import { FamilyMember, Language } from '../types';
import { getTranslation } from '../utils/translations';

interface EmergencySOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  members: FamilyMember[];
  currentLang: Language;
}

export const EmergencySOSModal: React.FC<EmergencySOSModalProps> = ({
  isOpen,
  onClose,
  members,
  currentLang,
}) => {
  const t = getTranslation(currentLang);
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleShareOrCopy = () => {
    const text = `🚨 DAS FAMILY EMERGENCY MEDICAL CARD 🚨\n\n` +
      members.map(m => (
        `👤 ${m.name} (${m.relationship.toUpperCase()})\n` +
        `• Blood Group: ${m.bloodGroup}\n` +
        `• Phone: ${m.phone}\n` +
        `• Allergies: ${m.allergies.join(', ') || 'None'}\n` +
        `• Conditions: ${m.chronicConditions.join(', ') || 'None'}\n` +
        `• Emergency Contact: ${m.emergencyContactName} (${m.emergencyContactPhone})\n` +
        `• Doctor: ${m.primaryDoctorName} (${m.primaryDoctorPhone})`
      )).join('\n\n-------------------------\n\n') +
      `\n\n🚑 National Ambulance: 108 | Emergency Services: 112`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-slate-900 border-2 border-red-500/50 rounded-2xl sm:rounded-3xl shadow-2xl shadow-red-900/30 overflow-hidden my-6">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 p-4 sm:p-6 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-sm">
              <ShieldAlert className="w-7 h-7 sm:w-8 sm:h-8 text-white animate-bounce" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black tracking-wide flex items-center gap-2">
                {t.sosEmergency} - DAS FAMILY
              </h2>
              <p className="text-xs sm:text-sm text-red-100 font-medium">
                {t.sosSubtitle}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Quick Emergency Helplines Bar */}
        <div className="bg-slate-950 px-4 sm:px-6 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
              Fast Dial Helplines:
            </span>
            <a
              href="tel:108"
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-red-500/20 text-red-300 border border-red-500/30 rounded-lg font-bold hover:bg-red-500/30 transition-all"
            >
              <Phone className="w-3.5 h-3.5 text-red-400" />
              Ambulance: 108
            </a>
            <a
              href="tel:1066"
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-sky-500/20 text-sky-300 border border-sky-500/30 rounded-lg font-bold hover:bg-sky-500/30 transition-all"
            >
              <Phone className="w-3.5 h-3.5 text-sky-400" />
              Apollo Emergency: 1066
            </a>
            <a
              href="tel:112"
              className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg font-bold hover:bg-amber-500/30 transition-all"
            >
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              National Emergency: 112
            </a>
          </div>

          <button
            onClick={handleShareOrCopy}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-amber-400" />}
            {copied ? 'Copied to Clipboard!' : 'Copy SOS Cards'}
          </button>
        </div>

        {/* Member Cards Grid */}
        <div className="p-4 sm:p-6 max-h-[65vh] overflow-y-auto space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {members.map((member) => (
              <div
                key={member.id}
                className="bg-slate-800/80 border border-slate-700/80 rounded-2xl p-4 shadow-lg hover:border-red-500/40 transition-all"
              >
                {/* Member Title */}
                <div className="flex items-start justify-between gap-3 border-b border-slate-700/60 pb-3 mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-11 h-11 rounded-xl ${member.avatarBg || 'bg-amber-600'} flex items-center justify-center font-bold text-lg text-white shadow`}>
                      {member.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-white flex items-center gap-2">
                        {member.name}
                        <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700 text-slate-300 capitalize font-medium">
                          {member.relationship}
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400">
                        Age: {member.age} yrs • DOB: {member.dob}
                      </p>
                    </div>
                  </div>
                  
                  {/* Blood Group Badge */}
                  <div className="flex flex-col items-center bg-red-500/20 border border-red-500/40 rounded-xl px-2.5 py-1">
                    <span className="text-[10px] text-red-300 font-bold uppercase tracking-wider">Blood</span>
                    <span className="text-base font-black text-red-400">{member.bloodGroup}</span>
                  </div>
                </div>

                {/* Medical Details */}
                <div className="space-y-2 text-xs">
                  {/* Allergies */}
                  <div className="flex items-start gap-2">
                    <span className="text-slate-400 font-medium min-w-[70px]">Allergies:</span>
                    <div className="flex flex-wrap gap-1">
                      {member.allergies.length > 0 ? (
                        member.allergies.map((allergy, i) => (
                          <span key={i} className="px-2 py-0.5 rounded bg-red-950/60 border border-red-800/50 text-red-300 font-semibold">
                            ⚠️ {allergy}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-500">None reported</span>
                      )}
                    </div>
                  </div>

                  {/* Conditions */}
                  <div className="flex items-start gap-2">
                    <span className="text-slate-400 font-medium min-w-[70px]">Conditions:</span>
                    <div className="flex flex-wrap gap-1">
                      {member.chronicConditions.length > 0 ? (
                        member.chronicConditions.map((cond, i) => (
                          <span key={i} className="px-2 py-0.5 rounded bg-amber-950/60 border border-amber-800/50 text-amber-300 font-semibold">
                            {cond}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-500">Healthy / None</span>
                      )}
                    </div>
                  </div>

                  {/* Emergency Contact */}
                  <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between">
                    <div>
                      <p className="text-[11px] text-slate-400 font-medium">Emergency Contact:</p>
                      <p className="font-semibold text-slate-200">{member.emergencyContactName}</p>
                    </div>
                    {member.emergencyContactPhone && (
                      <a
                        href={`tel:${member.emergencyContactPhone.replace(/\s+/g, '')}`}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-600/30 rounded-lg font-bold text-xs transition-colors"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        Call
                      </a>
                    )}
                  </div>

                  {/* Primary Doctor */}
                  {member.primaryDoctorName && (
                    <div className="flex items-center justify-between bg-slate-900/60 p-2 rounded-xl border border-slate-700/40">
                      <div>
                        <p className="text-[10px] text-slate-400 uppercase font-semibold">Family Doctor:</p>
                        <p className="font-medium text-slate-200">{member.primaryDoctorName}</p>
                      </div>
                      {member.primaryDoctorPhone && (
                        <a
                          href={`tel:${member.primaryDoctorPhone.replace(/\s+/g, '')}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-sky-500/20 text-sky-400 border border-sky-500/30 hover:bg-sky-500/30 rounded-lg text-xs font-semibold"
                        >
                          <Phone className="w-3 h-3" />
                          Doc
                        </a>
                      )}
                    </div>
                  )}

                  {/* Insurance Policy */}
                  {member.insurancePolicyNo && (
                    <div className="text-[11px] text-slate-400">
                      Policy No: <span className="font-mono text-slate-300 font-semibold">{member.insurancePolicyNo}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-sm transition-colors"
          >
            Close Emergency View
          </button>
        </div>
      </div>
    </div>
  );
};
