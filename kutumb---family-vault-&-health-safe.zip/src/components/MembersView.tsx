import React, { useState } from 'react';
import { 
  Users, 
  UserPlus, 
  Phone, 
  Mail, 
  Heart, 
  AlertTriangle, 
  ShieldCheck, 
  Calendar, 
  Edit3, 
  Trash2, 
  Lock,
  Stethoscope
} from 'lucide-react';
import { FamilyMember, Language, UserRole } from '../types';
import { getTranslation } from '../utils/translations';
import { KolkaCorner, KolkaDivider } from './KolkaMotifs';

interface MembersViewProps {
  members: FamilyMember[];
  currentMember: FamilyMember;
  currentLang: Language;
  onSelectMember: (m: FamilyMember) => void;
  onUpdateMember: (m: FamilyMember) => void;
  onAddNewMember: (m: FamilyMember) => void;
  onDeleteMember: (id: string) => void;
}

export const MembersView: React.FC<MembersViewProps> = ({
  members,
  currentMember,
  currentLang,
  onSelectMember,
  onUpdateMember,
  onAddNewMember,
  onDeleteMember,
}) => {
  const t = getTranslation(currentLang);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // Form states for add / edit
  const [name, setName] = useState('');
  const [rel, setRel] = useState<FamilyMember['relationship']>('son');
  const [gender, setGender] = useState<FamilyMember['gender']>('male');
  const [dob, setDob] = useState('2000-01-01');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('das123');
  const [pin, setPin] = useState('1234');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [allergiesText, setAllergiesText] = useState('');
  const [conditionsText, setConditionsText] = useState('');
  const [emContactName, setEmContactName] = useState('Milon Das');
  const [emContactPhone, setEmContactPhone] = useState('+91 98301 23456');
  const [doctorName, setDoctorName] = useState('Dr. Debabrata Sen');
  const [doctorPhone, setDoctorPhone] = useState('+91 94330 11223');
  const [insuranceNo, setInsuranceNo] = useState('');
  const [role, setRole] = useState<UserRole>('member');
  const [notes, setNotes] = useState('');

  // STRICT REQUIREMENT: Only registered persons are visible in the app
  const registeredMembers = members.filter((m) => m.isRegistered !== false);

  const openEdit = (member: FamilyMember) => {
    setEditingMember(member);
    setName(member.name);
    setRel(member.relationship);
    setGender(member.gender);
    setDob(member.dob);
    setPhone(member.phone);
    setEmail(member.email);
    setLoginId(member.loginId);
    setPassword(member.password || 'das123');
    setPin(member.pin || '1234');
    setBloodGroup(member.bloodGroup);
    setAllergiesText(member.allergies.join(', '));
    setConditionsText(member.chronicConditions.join(', '));
    setEmContactName(member.emergencyContactName);
    setEmContactPhone(member.emergencyContactPhone);
    setDoctorName(member.primaryDoctorName || '');
    setDoctorPhone(member.primaryDoctorPhone || '');
    setInsuranceNo(member.insurancePolicyNo || '');
    setRole(member.role);
    setNotes(member.notes || '');
  };

  const handleSaveMember = (e: React.FormEvent) => {
    e.preventDefault();
    const allergies = allergiesText.split(',').map(s => s.trim()).filter(Boolean);
    const conditions = conditionsText.split(',').map(s => s.trim()).filter(Boolean);
    const birthYear = new Date(dob).getFullYear();
    const calculatedAge = new Date().getFullYear() - (isNaN(birthYear) ? 2000 : birthYear);

    if (editingMember) {
      const updated: FamilyMember = {
        ...editingMember,
        name,
        relationship: rel,
        gender,
        dob,
        age: calculatedAge,
        phone,
        email,
        loginId,
        password,
        pin,
        bloodGroup,
        allergies,
        chronicConditions: conditions,
        emergencyContactName: emContactName,
        emergencyContactPhone: emContactPhone,
        primaryDoctorName: doctorName,
        primaryDoctorPhone: doctorPhone,
        insurancePolicyNo: insuranceNo,
        role,
        notes,
        isRegistered: true,
        registrationId: editingMember.registrationId || `DF-REG-${String(registeredMembers.length).padStart(3, '0')}`,
        registeredAt: editingMember.registeredAt || new Date().toISOString().split('T')[0],
      };
      onUpdateMember(updated);
      setEditingMember(null);
    } else {
      const newRegId = `DF-REG-${String(registeredMembers.length + 1).padStart(3, '0')}`;
      const created: FamilyMember = {
        id: `member-${Date.now()}`,
        name,
        relationship: rel,
        gender,
        dob,
        age: calculatedAge,
        phone: phone || '+91 98000 00000',
        email: email || `${loginId.toLowerCase()}@dasfamily.org`,
        loginId: loginId.trim().toLowerCase(),
        password: password || 'das123',
        pin: pin || '1234',
        bloodGroup,
        allergies,
        chronicConditions: conditions,
        emergencyContactName: emContactName,
        emergencyContactPhone: emContactPhone,
        primaryDoctorName: doctorName,
        primaryDoctorPhone: doctorPhone,
        insurancePolicyNo: insuranceNo,
        role,
        avatarBg: 'bg-rose-900',
        notes,
        // Enforce registration status
        isRegistered: true,
        registeredAt: new Date().toISOString().split('T')[0],
        registrationId: newRegId,
      };
      onAddNewMember(created);
      setShowAddModal(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* View Header with White & Crimson Kolka Design and Registration Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border-2 border-rose-200 p-6 rounded-3xl shadow-lg relative overflow-hidden">
        <div className="absolute top-0 right-0 pointer-events-none opacity-40">
          <KolkaCorner className="w-28 h-28" color="#991b1b" />
        </div>

        <div className="relative z-10 space-y-1.5">
          <div className="flex items-center gap-2">
            <Users className="w-6 h-6 text-rose-800" />
            <h2 className="text-xl sm:text-2xl font-black text-rose-950">
              পরিবারের নিবন্ধিত সদস্য তালিকা (DAS FAMILY ROSTER)
            </h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-600">
            নিরাপত্তা নির্দেশিকা: অ্যাপে শুধুমাত্র অফিসিয়ালি নিবন্ধিত ও ভেরিফায়েড সদস্য দৃশ্যমান ({registeredMembers.length} জন নিবন্ধিত)।
          </p>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            <span>🔒 শুধুমাত্র নিবন্ধিত সদস্য সুরক্ষা সক্রিয় (Registered Members Only)</span>
          </div>
        </div>

        <button
          onClick={() => {
            setEditingMember(null);
            setName('');
            setLoginId('');
            setPassword('das123');
            setShowAddModal(true);
          }}
          className="relative z-10 flex items-center gap-2 px-5 py-3 rounded-2xl bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs sm:text-sm shadow-md transition-all active:scale-95 shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          {t.addMember}
        </button>
      </div>

      <KolkaDivider />

      {/* Family Members Grid (Strictly Registered Persons Only) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {registeredMembers.map((member) => {
          const isCurrent = member.id === currentMember.id;
          return (
            <div
              key={member.id}
              className={`bg-white border-2 rounded-3xl p-5 shadow-lg transition-all relative flex flex-col justify-between ${
                isCurrent ? 'border-rose-700 ring-4 ring-rose-200 shadow-xl' : 'border-rose-100 hover:border-rose-300'
              }`}
            >
              <div>
                {/* Active Pill & Verified Registered Badge */}
                <div className="flex items-center justify-between mb-3">
                  <span className="inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 border border-emerald-300 shadow-sm">
                    <ShieldCheck className="w-3 h-3 text-emerald-700" />
                    <span>ভেরিফায়েড নিবন্ধিত সদস্য</span>
                  </span>
                  {isCurrent && (
                    <span className="text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-900 text-white shadow">
                      বর্তমান লগইন
                    </span>
                  )}
                </div>

                {/* Profile Header */}
                <div className="flex items-start gap-3.5 mb-3">
                  <div className="w-13 h-13 rounded-2xl bg-rose-900 text-white flex items-center justify-center text-xl font-black shadow-md shrink-0">
                    {member.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="font-black text-base text-rose-950 flex items-center gap-2">
                      {member.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs px-2.5 py-0.5 rounded-md bg-rose-50 text-rose-900 font-bold border border-rose-200 capitalize">
                        {member.relationship}
                      </span>
                      <span className="text-xs text-slate-500 font-medium">
                        {member.age} বছর • {member.gender}
                      </span>
                    </div>
                    {/* Official Registration Number & Date */}
                    <p className="text-[10px] font-mono font-bold text-rose-800 mt-1">
                      রেজিস্ট্রেশন নং: <span className="bg-rose-50 px-1.5 py-0.5 rounded border border-rose-200">{member.registrationId || 'DF-REG-001'}</span>
                    </p>
                  </div>
                </div>

                {/* Blood Group & Role Bar */}
                <div className="flex items-center justify-between p-2.5 rounded-2xl bg-rose-50/70 border border-rose-200 mb-4 text-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-600 font-semibold">রক্তের গ্রুপ:</span>
                    <span className="font-black text-red-700 text-sm">{member.bloodGroup}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-600 font-semibold">মর্যাদা:</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      member.role === 'admin' 
                        ? 'bg-rose-900 text-white' 
                        : 'bg-white text-rose-900 border border-rose-200'
                    }`}>
                      {member.role === 'admin' ? '👑 অ্যাডমিন' : 'সদস্য'}
                    </span>
                  </div>
                </div>

                {/* Contact & Health Details */}
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-slate-700">
                    <Phone className="w-3.5 h-3.5 text-rose-700 shrink-0" />
                    <span className="font-mono">{member.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Mail className="w-3.5 h-3.5 text-rose-700 shrink-0" />
                    <span className="truncate">{member.email}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-700">
                    <Lock className="w-3.5 h-3.5 text-rose-800 shrink-0" />
                    <span>আইডি: <code className="text-rose-900 font-bold font-mono bg-rose-50 px-2 py-0.5 rounded">{member.loginId}</code></span>
                  </div>

                  {/* Allergies & Conditions Chips */}
                  <div className="pt-2 border-t border-rose-100 space-y-1.5">
                    <div>
                      <p className="text-[10px] text-slate-500 uppercase font-bold">অ্যালার্জি:</p>
                      <div className="flex flex-wrap gap-1 mt-0.5">
                        {member.allergies.length > 0 ? (
                          member.allergies.map((a, i) => (
                            <span key={i} className="px-2 py-0.5 rounded-md bg-red-100 text-red-900 text-[10px] font-bold border border-red-200">
                              ⚠️ {a}
                            </span>
                          ))
                        ) : (
                          <span className="text-slate-400 text-[11px]">নেই</span>
                        )}
                      </div>
                    </div>

                    <div>
                      <p className="text-[10px] text-slate-500 uppercase font-bold">শারীরিক কন্ডিশন:</p>
                      <div className="flex flex-wrap gap-1 mt-0.5">
                        {member.chronicConditions.length > 0 ? (
                          member.chronicConditions.map((c, i) => (
                            <span key={i} className="px-2 py-0.5 rounded-md bg-rose-50 text-rose-900 text-[10px] font-bold border border-rose-200">
                              {c}
                            </span>
                          ))
                        ) : (
                          <span className="text-slate-400 text-[11px]">সুস্থ</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Doctor Info */}
                  {member.primaryDoctorName && (
                    <div className="pt-2 border-t border-rose-100 flex items-center justify-between text-[11px] text-slate-600">
                      <div className="flex items-center gap-1.5">
                        <Stethoscope className="w-3.5 h-3.5 text-rose-800" />
                        <span className="truncate max-w-[170px] font-medium">{member.primaryDoctorName}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-5 pt-3 border-t border-rose-100 flex items-center justify-between gap-2">
                {(currentMember.role === 'admin' || isCurrent) ? (
                  <button
                    onClick={() => openEdit(member)}
                    className="flex-1 py-2 px-3 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-950 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors border border-rose-200"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-rose-800" />
                    {isCurrent ? 'আমার প্রোফাইল পরিবর্তন' : 'প্রোফাইল এডিট'}
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-400 italic py-1 px-2">
                    অ্যাডমিন দ্বারা নিয়ন্ত্রিত
                  </span>
                )}

                {!isCurrent && (
                  <button
                    onClick={() => onSelectMember(member)}
                    className="py-2 px-3 rounded-xl bg-rose-900 hover:bg-rose-800 text-white text-xs font-bold transition-colors shadow-sm"
                  >
                    সুইচ
                  </button>
                )}

                {currentMember.role === 'admin' && members.length > 1 && member.role !== 'admin' && (
                  <button
                    onClick={() => {
                      if (confirm(t.confirmDelete)) {
                        onDeleteMember(member.id);
                      }
                    }}
                    className="p-2 text-rose-700 hover:text-red-600 rounded-xl hover:bg-rose-50 transition-colors"
                    title="Delete member"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit / Add Member Modal in White & Crimson Kolka Theme */}
      {(showAddModal || editingMember) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-rose-950/60 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white border-2 border-rose-300 rounded-3xl shadow-2xl overflow-hidden my-6">
            <div className="p-5 bg-gradient-to-r from-rose-900 to-red-800 text-white flex items-center justify-between">
              <h3 className="font-black text-lg">
                {editingMember ? 'প্রোফাইল পরিবর্তন: ' + editingMember.name : 'পরিবারে নতুন সদস্য যোগ করুন'}
              </h3>
              <button
                onClick={() => { setShowAddModal(false); setEditingMember(null); }}
                className="text-white hover:text-rose-200 p-1"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveMember} className="p-5 sm:p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">পূর্ণ নাম *</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">সম্পর্ক</label>
                  <select
                    value={rel}
                    onChange={(e) => setRel(e.target.value as any)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  >
                    <option value="head">Family Head (প্রধান)</option>
                    <option value="spouse">Spouse (স্ত্রী/স্বামী)</option>
                    <option value="son">Son (পুত্র)</option>
                    <option value="daughter">Daughter (কন্যা)</option>
                    <option value="father">Father (পিতা)</option>
                    <option value="mother">Mother (মাতা)</option>
                    <option value="grandfather">Grandfather (দাদু/ঠাকুরদা)</option>
                    <option value="grandmother">Grandmother (দিদিমা/ঠাকুমা)</option>
                    <option value="other">Other (আত্মীয়)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">রক্তের গ্রুপ</label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs font-bold text-red-700 focus:outline-none focus:border-rose-600"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">জন্ম তারিখ</label>
                  <input
                    type="date"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">মর্যাদা (Role)</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  >
                    <option value="member">পারিবারিক সদস্য</option>
                    <option value="child_or_elder">শিশু / প্রবীণ</option>
                    <option value="admin">Co-Admin (অ্যাডমিন)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">মোবাইল নম্বর</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98300..."
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">ইমেইল (Gmail)</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@gmail.com"
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">লগইন আইডি *</label>
                  <input
                    type="text"
                    required
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs font-mono focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">পাসওয়ার্ড</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs focus:outline-none focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">৪-সংখ্যার গোপন পিন (PIN)</label>
                  <input
                    type="text"
                    maxLength={4}
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-rose-200 rounded-xl text-slate-900 text-xs font-mono tracking-widest focus:outline-none focus:border-rose-600"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-rose-100">
                <button
                  type="button"
                  onClick={() => { setShowAddModal(false); setEditingMember(null); }}
                  className="px-4 py-2 rounded-xl bg-stone-200 hover:bg-stone-300 text-slate-800 text-xs font-bold"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-900 hover:bg-rose-800 text-white text-xs font-bold shadow-md"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
