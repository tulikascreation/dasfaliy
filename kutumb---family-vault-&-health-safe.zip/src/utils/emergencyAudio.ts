// Web Audio API emergency siren synthesizer

let audioCtx: AudioContext | null = null;
let sirenOscillator: OscillatorNode | null = null;
let modulationOscillator: OscillatorNode | null = null;
let gainNode: GainNode | null = null;
let isSirenActive = false;

export const playEmergencySiren = () => {
  try {
    if (isSirenActive) return;
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    audioCtx = new AudioContextClass();
    
    // Main alarm oscillator
    sirenOscillator = audioCtx.createOscillator();
    sirenOscillator.type = 'sawtooth';
    sirenOscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // A5

    // Modulation oscillator to produce classic wailing police/ambulance frequency sweep
    modulationOscillator = audioCtx.createOscillator();
    modulationOscillator.type = 'sine';
    modulationOscillator.frequency.setValueAtTime(3.5, audioCtx.currentTime); // 3.5 sweeps per second

    const modulationGain = audioCtx.createGain();
    modulationGain.gain.setValueAtTime(450, audioCtx.currentTime); // +/- 450 Hz variation

    modulationOscillator.connect(modulationGain);
    modulationGain.connect(sirenOscillator.frequency);

    gainNode = audioCtx.createGain();
    gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime); // Safe but loud volume

    sirenOscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);

    sirenOscillator.start();
    modulationOscillator.start();
    isSirenActive = true;
  } catch (err) {
    console.warn('Audio siren playback not allowed or failed:', err);
  }
};

export const stopEmergencySiren = () => {
  try {
    if (sirenOscillator) {
      sirenOscillator.stop();
      sirenOscillator.disconnect();
      sirenOscillator = null;
    }
    if (modulationOscillator) {
      modulationOscillator.stop();
      modulationOscillator.disconnect();
      modulationOscillator = null;
    }
    if (gainNode) {
      gainNode.disconnect();
      gainNode = null;
    }
    if (audioCtx) {
      audioCtx.close();
      audioCtx = null;
    }
    isSirenActive = false;
  } catch (err) {
    console.warn('Error stopping siren:', err);
  }
};
