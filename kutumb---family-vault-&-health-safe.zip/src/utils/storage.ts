import { VaultState } from '../types';

const STORAGE_KEY = 'das_family_vault_v3';

export const INITIAL_VAULT_DATA: VaultState = {
  familyName: 'DAS FAMILY',
  familyHeadId: 'member-1',
  members: [
    {
      id: 'member-1',
      name: 'Milon Das',
      relationship: 'head',
      gender: 'male',
      dob: '1988-06-15',
      age: 38,
      phone: '+91 98301 23456',
      email: 'milon8727@gmail.com',
      loginId: 'milon',
      password: 'das123',
      pin: '1234',
      role: 'admin',
      bloodGroup: 'B+',
      allergies: ['Dust', 'Sulfa drugs'],
      chronicConditions: ['Mild Asthma'],
      emergencyContactName: 'Milon Das (Admin)',
      emergencyContactPhone: '+91 98301 23456',
      insurancePolicyNo: 'STAR-HEALTH-884920',
      primaryDoctorName: 'Dr. Debabrata Sen (MD Medicine)',
      primaryDoctorPhone: '+91 94330 11223',
      avatarBg: 'bg-emerald-600',
      notes: 'Family Head & Admin. Authorized to manage all documents and health profiles.',
      isRegistered: true,
      registeredAt: '2026-01-10',
      registrationId: 'DF-REG-001',
    },
  ],
  activeAlert: null,
  alertHistory: [],
  vitals: [
    {
      id: 'vit-1',
      memberId: 'member-1',
      date: '2026-09-30',
      time: '08:30 AM',
      bpSystolic: 120,
      bpDiastolic: 80,
      bloodSugar: 104,
      bloodSugarType: 'fasting',
      pulse: 72,
      spo2: 99,
      weight: 74.0,
      notes: 'রক্তচাপ ও সুগার লেভেল সম্পূর্ণ স্বাভাবিক।',
    },
    {
      id: 'vit-2',
      memberId: 'member-1',
      date: '2026-09-25',
      time: '07:15 PM',
      bpSystolic: 118,
      bpDiastolic: 78,
      pulse: 72,
      spo2: 99,
      weight: 74.2,
      notes: 'নিয়মিত ব্যায়াম পরবর্তী স্বাভাবিক পালস ও রক্তচাপ।',
    },
  ],
  medicalRecords: [
    {
      id: 'rec-1',
      memberId: 'member-1',
      title: 'Comprehensive Health & Lipid Profile',
      type: 'lab_report',
      date: '2026-07-20',
      doctorOrHospital: 'Suraksha Diagnostic Centre',
      diagnosisOrNotes: 'HbA1c: 5.6% (Normal), Total Cholesterol: 184 mg/dL. Overall good health.',
      fileName: 'Milon_Das_Lipid_Blood_2026.pdf',
      fileType: 'application/pdf',
    },
  ],
  documents: [
    {
      id: 'doc-1',
      memberId: 'member-1',
      title: 'Star Health Comprehensive Insurance Policy',
      category: 'insurance',
      documentNumber: 'SH-FLOATER-2024-884920',
      issueDate: '2024-04-01',
      expiryDate: '2027-03-31',
      isLocked: false,
      tags: ['Health Insurance', 'Cashless', '15 Lakhs Cover'],
      notes: 'TPA Helpline: 1800-425-2255. Primary Insured: Milon Das.',
      fileName: 'Star_Health_Family_Insurance_Card.pdf',
      fileSize: '1.4 MB',
      fileType: 'application/pdf',
      createdAt: '2024-04-01',
    },
    {
      id: 'doc-2',
      memberId: 'member-1',
      title: 'Milon Das - National ID / Aadhaar Card',
      category: 'identity',
      documentNumber: 'XXXX-XXXX-4821',
      issueDate: '2016-08-12',
      isLocked: true,
      tags: ['Aadhaar', 'Identity', 'Family Admin'],
      notes: 'Verified biometric record. Password protected.',
      fileName: 'Aadhaar_Milon_Das_Secured.pdf',
      fileSize: '840 KB',
      fileType: 'application/pdf',
      createdAt: '2024-01-10',
    },
    {
      id: 'doc-3',
      memberId: 'member-1',
      title: 'Residential Property Deed & Registered Sale Agreement',
      category: 'property',
      documentNumber: 'REG-WB-KOL-89240-2019',
      issueDate: '2019-11-20',
      isLocked: true,
      tags: ['Property Deed', 'Salt Lake Flat', 'Ancestral & Legal'],
      notes: 'Registered Sale Deed for Salt Lake property in name of Milon Das.',
      fileName: 'Salt_Lake_Apartment_SaleDeed.pdf',
      fileSize: '4.8 MB',
      fileType: 'application/pdf',
      createdAt: '2024-01-10',
    },
    {
      id: 'doc-4',
      memberId: 'member-1',
      title: 'Motor Insurance Policy - Hyundai Creta',
      category: 'vehicle',
      documentNumber: 'ICICI-LOMB-MOT-2025-771',
      issueDate: '2025-10-10',
      expiryDate: '2026-10-09',
      isLocked: false,
      tags: ['Car Insurance', 'Comprehensive', 'WB-02-AG-4921'],
      notes: 'Roadside assistance toll-free: 1800-2666.',
      fileName: 'Creta_Vehicle_Insurance_2026.pdf',
      fileSize: '650 KB',
      fileType: 'application/pdf',
      createdAt: '2025-10-10',
    },
  ],
  photoFolders: [
    {
      id: 'folder-1',
      name: 'Family Memories & Trips',
      description: 'Darjeeling vacation, beach holidays & family get-togethers',
      color: 'bg-emerald-700',
      createdAt: '2024-01-01',
    },
    {
      id: 'folder-2',
      name: 'Medical Prescriptions & Bills',
      description: 'Pharmacy bills, doctor receipts and printed prescriptions',
      color: 'bg-teal-700',
      createdAt: '2024-01-01',
    },
    {
      id: 'folder-3',
      name: 'Important ID Cards & Badges',
      description: 'Clear photo scans of Aadhaar, Voter, School & Senior Citizen Cards',
      color: 'bg-indigo-700',
      createdAt: '2024-01-01',
    },
    {
      id: 'folder-4',
      name: 'Festivals & Durga Puja',
      description: 'Puja celebrations, Diwali family dinners & birthday milestones',
      color: 'bg-amber-700',
      createdAt: '2024-01-01',
    },
  ],
  photos: [
    {
      id: 'photo-1',
      folderId: 'folder-1',
      title: 'Darjeeling Sunrise at Tiger Hill',
      url: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=1200&q=80',
      date: '2025-12-25',
      taggedMemberIds: ['member-1'],
      caption: 'Das family winter sunrise and Kanchenjunga view.',
      fileSize: '2.4 MB',
    },
    {
      id: 'photo-2',
      folderId: 'folder-4',
      title: 'Durga Puja Celebrations in Traditional Attire',
      url: 'https://images.unsplash.com/photo-1514222709107-a180c68d72b4?auto=format&fit=crop&w=1200&q=80',
      date: '2025-10-19',
      taggedMemberIds: ['member-1'],
      caption: 'Bijoya Dashami evening celebration.',
      fileSize: '3.1 MB',
    },
  ],
  driveSync: {
    isConnected: true,
    accountEmail: 'milon8727@gmail.com',
    lastSyncTime: '2026-10-01 21:30:00',
    autoSyncEnabled: true,
    syncFrequency: 'daily',
    folderName: 'Google Drive / DAS FAMILY VAULT',
    syncedFilesCount: 15,
    isSyncing: false,
  },
};

export const loadVaultData = (): VaultState => {
  try {
    // Clear legacy caches to guarantee only Admin exists initially
    try {
      localStorage.removeItem('das_family_vault_v1');
      localStorage.removeItem('das_family_vault_v2');
    } catch {}

    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_VAULT_DATA));
      return INITIAL_VAULT_DATA;
    }
    const parsed = JSON.parse(raw);
    const mergedMembers = (parsed.members || INITIAL_VAULT_DATA.members).map((m: any, idx: number) => ({
      ...m,
      isRegistered: m.isRegistered !== false, // default true unless explicitly false
      registrationId: m.registrationId || `DF-REG-${String(idx + 1).padStart(3, '0')}`,
      registeredAt: m.registeredAt || '2026-01-10',
    }));

    return { 
      ...INITIAL_VAULT_DATA, 
      ...parsed,
      members: mergedMembers,
    };
  } catch (err) {
    console.error('Error loading vault data:', err);
    return INITIAL_VAULT_DATA;
  }
};

export const saveVaultData = (state: VaultState): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (err) {
    console.error('Error saving vault data:', err);
  }
};

export const exportVaultBackup = (state: VaultState): void => {
  const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
    JSON.stringify(state, null, 2)
  )}`;
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', jsonString);
  const now = new Date().toISOString().split('T')[0];
  downloadAnchor.setAttribute('download', `Das_Family_Vault_Backup_${now}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
};
